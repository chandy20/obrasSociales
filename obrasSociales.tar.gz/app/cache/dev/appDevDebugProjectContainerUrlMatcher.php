<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appDevDebugProjectContainerUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($rawPathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($rawPathinfo);
        $context = $this->context;
        $request = $this->request;

        if (0 === strpos($pathinfo, '/_')) {
            // _wdt
            if (0 === strpos($pathinfo, '/_wdt') && preg_match('#^/_wdt/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_wdt')), array (  '_controller' => 'web_profiler.controller.profiler:toolbarAction',));
            }

            if (0 === strpos($pathinfo, '/_profiler')) {
                // _profiler_home
                if ('/_profiler' === rtrim($pathinfo, '/')) {
                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($rawPathinfo.'/', '_profiler_home');
                    }

                    return array (  '_controller' => 'web_profiler.controller.profiler:homeAction',  '_route' => '_profiler_home',);
                }

                if (0 === strpos($pathinfo, '/_profiler/search')) {
                    // _profiler_search
                    if ('/_profiler/search' === $pathinfo) {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchAction',  '_route' => '_profiler_search',);
                    }

                    // _profiler_search_bar
                    if ('/_profiler/search_bar' === $pathinfo) {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchBarAction',  '_route' => '_profiler_search_bar',);
                    }

                }

                // _profiler_purge
                if ('/_profiler/purge' === $pathinfo) {
                    return array (  '_controller' => 'web_profiler.controller.profiler:purgeAction',  '_route' => '_profiler_purge',);
                }

                // _profiler_info
                if (0 === strpos($pathinfo, '/_profiler/info') && preg_match('#^/_profiler/info/(?P<about>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_info')), array (  '_controller' => 'web_profiler.controller.profiler:infoAction',));
                }

                // _profiler_phpinfo
                if ('/_profiler/phpinfo' === $pathinfo) {
                    return array (  '_controller' => 'web_profiler.controller.profiler:phpinfoAction',  '_route' => '_profiler_phpinfo',);
                }

                // _profiler_search_results
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/search/results$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_search_results')), array (  '_controller' => 'web_profiler.controller.profiler:searchResultsAction',));
                }

                // _profiler
                if (preg_match('#^/_profiler/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler')), array (  '_controller' => 'web_profiler.controller.profiler:panelAction',));
                }

                // _profiler_router
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/router$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_router')), array (  '_controller' => 'web_profiler.controller.router:panelAction',));
                }

                // _profiler_exception
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception')), array (  '_controller' => 'web_profiler.controller.exception:showAction',));
                }

                // _profiler_exception_css
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception\\.css$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception_css')), array (  '_controller' => 'web_profiler.controller.exception:cssAction',));
                }

            }

            // _twig_error_test
            if (0 === strpos($pathinfo, '/_error') && preg_match('#^/_error/(?P<code>\\d+)(?:\\.(?P<_format>[^/]++))?$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_twig_error_test')), array (  '_controller' => 'twig.controller.preview_error:previewErrorPageAction',  '_format' => 'html',));
            }

        }

        // frontend_homepage
        if (0 === strpos($pathinfo, '/hello') && preg_match('#^/hello/(?P<name>[^/]++)$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'frontend_homepage')), array (  '_controller' => 'FrontendBundle\\Controller\\DefaultController::indexAction',));
        }

        if (0 === strpos($pathinfo, '/solicitudes')) {
            // solicitudes
            if ('/solicitudes' === $pathinfo) {
                return array (  '_controller' => 'FrontendBundle\\Controller\\SolicitudesController::indexAction',  '_route' => 'solicitudes',);
            }

            // solicitudes_show
            if (preg_match('#^/solicitudes/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'solicitudes_show')), array (  '_controller' => 'FrontendBundle\\Controller\\SolicitudesController::showAction',));
            }

            // solicitudes_edit
            if (preg_match('#^/solicitudes/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'solicitudes_edit')), array (  '_controller' => 'FrontendBundle\\Controller\\SolicitudesController::editAction',));
            }

            // solicitudes_delete
            if (preg_match('#^/solicitudes/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'solicitudes_delete')), array (  '_controller' => 'FrontendBundle\\Controller\\SolicitudesController::deleteAction',));
            }

            // solicitudes_new
            if ('/solicitudes/new' === $pathinfo) {
                return array (  '_controller' => 'FrontendBundle\\Controller\\SolicitudesController::newAction',  '_route' => 'solicitudes_new',);
            }

            if (0 === strpos($pathinfo, '/solicitudes/create')) {
                // solicitudes_create
                if ('/solicitudes/create' === $pathinfo) {
                    return array (  '_controller' => 'FrontendBundle\\Controller\\SolicitudesController::createAction',  '_route' => 'solicitudes_create',);
                }

                // solicitudes_update
                if ('/solicitudes/create' === $pathinfo) {
                    return array (  '_controller' => 'FrontendBundle\\Controller\\solicitudesController::updateAction',  '_route' => 'solicitudes_update',);
                }

            }

        }

        // homepage
        if ('' === rtrim($pathinfo, '/')) {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($rawPathinfo.'/', 'homepage');
            }

            return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::indexAction',  '_route' => 'homepage',);
        }

        if (0 === strpos($pathinfo, '/admin')) {
            // sonata_admin_redirect
            if ('/admin' === rtrim($pathinfo, '/')) {
                if (substr($pathinfo, -1) !== '/') {
                    return $this->redirect($rawPathinfo.'/', 'sonata_admin_redirect');
                }

                return array (  '_controller' => 'Symfony\\Bundle\\FrameworkBundle\\Controller\\RedirectController::redirectAction',  'route' => 'sonata_admin_dashboard',  'permanent' => 'true',  '_route' => 'sonata_admin_redirect',);
            }

            // sonata_admin_dashboard
            if ('/admin/dashboard' === $pathinfo) {
                return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CoreController::dashboardAction',  '_route' => 'sonata_admin_dashboard',);
            }

            if (0 === strpos($pathinfo, '/admin/core')) {
                // sonata_admin_retrieve_form_element
                if ('/admin/core/get-form-field-element' === $pathinfo) {
                    return array (  '_controller' => 'sonata.admin.controller.admin:retrieveFormFieldElementAction',  '_route' => 'sonata_admin_retrieve_form_element',);
                }

                // sonata_admin_append_form_element
                if ('/admin/core/append-form-field-element' === $pathinfo) {
                    return array (  '_controller' => 'sonata.admin.controller.admin:appendFormFieldElementAction',  '_route' => 'sonata_admin_append_form_element',);
                }

                // sonata_admin_short_object_information
                if (0 === strpos($pathinfo, '/admin/core/get-short-object-description') && preg_match('#^/admin/core/get\\-short\\-object\\-description(?:\\.(?P<_format>html|json))?$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'sonata_admin_short_object_information')), array (  '_controller' => 'sonata.admin.controller.admin:getShortObjectDescriptionAction',  '_format' => 'html',));
                }

                // sonata_admin_set_object_field_value
                if ('/admin/core/set-object-field-value' === $pathinfo) {
                    return array (  '_controller' => 'sonata.admin.controller.admin:setObjectFieldValueAction',  '_route' => 'sonata_admin_set_object_field_value',);
                }

            }

            // sonata_admin_search
            if ('/admin/search' === $pathinfo) {
                return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CoreController::searchAction',  '_route' => 'sonata_admin_search',);
            }

            // sonata_admin_retrieve_autocomplete_items
            if ('/admin/core/get-autocomplete-items' === $pathinfo) {
                return array (  '_controller' => 'sonata.admin.controller.admin:retrieveAutocompleteItemsAction',  '_route' => 'sonata_admin_retrieve_autocomplete_items',);
            }

            if (0 === strpos($pathinfo, '/admin/app')) {
                if (0 === strpos($pathinfo, '/admin/app/cantidadesbeneficio')) {
                    // admin_app_cantidadesbeneficio_list
                    if ('/admin/app/cantidadesbeneficio/list' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\CantidadesbeneficioAdminController::listAction',  '_sonata_admin' => 'app.admin.cantidadesbeneficio',  '_sonata_name' => 'admin_app_cantidadesbeneficio_list',  '_route' => 'admin_app_cantidadesbeneficio_list',);
                    }

                    // admin_app_cantidadesbeneficio_create
                    if ('/admin/app/cantidadesbeneficio/create' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\CantidadesbeneficioAdminController::createAction',  '_sonata_admin' => 'app.admin.cantidadesbeneficio',  '_sonata_name' => 'admin_app_cantidadesbeneficio_create',  '_route' => 'admin_app_cantidadesbeneficio_create',);
                    }

                    // admin_app_cantidadesbeneficio_batch
                    if ('/admin/app/cantidadesbeneficio/batch' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\CantidadesbeneficioAdminController::batchAction',  '_sonata_admin' => 'app.admin.cantidadesbeneficio',  '_sonata_name' => 'admin_app_cantidadesbeneficio_batch',  '_route' => 'admin_app_cantidadesbeneficio_batch',);
                    }

                    // admin_app_cantidadesbeneficio_edit
                    if (preg_match('#^/admin/app/cantidadesbeneficio/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_cantidadesbeneficio_edit')), array (  '_controller' => 'AppBundle\\Controller\\CantidadesbeneficioAdminController::editAction',  '_sonata_admin' => 'app.admin.cantidadesbeneficio',  '_sonata_name' => 'admin_app_cantidadesbeneficio_edit',));
                    }

                    // admin_app_cantidadesbeneficio_delete
                    if (preg_match('#^/admin/app/cantidadesbeneficio/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_cantidadesbeneficio_delete')), array (  '_controller' => 'AppBundle\\Controller\\CantidadesbeneficioAdminController::deleteAction',  '_sonata_admin' => 'app.admin.cantidadesbeneficio',  '_sonata_name' => 'admin_app_cantidadesbeneficio_delete',));
                    }

                    // admin_app_cantidadesbeneficio_show
                    if (preg_match('#^/admin/app/cantidadesbeneficio/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_cantidadesbeneficio_show')), array (  '_controller' => 'AppBundle\\Controller\\CantidadesbeneficioAdminController::showAction',  '_sonata_admin' => 'app.admin.cantidadesbeneficio',  '_sonata_name' => 'admin_app_cantidadesbeneficio_show',));
                    }

                    // admin_app_cantidadesbeneficio_export
                    if ('/admin/app/cantidadesbeneficio/export' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\CantidadesbeneficioAdminController::exportAction',  '_sonata_admin' => 'app.admin.cantidadesbeneficio',  '_sonata_name' => 'admin_app_cantidadesbeneficio_export',  '_route' => 'admin_app_cantidadesbeneficio_export',);
                    }

                }

                if (0 === strpos($pathinfo, '/admin/app/areas')) {
                    // admin_app_areas_list
                    if ('/admin/app/areas/list' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\AreasAdminController::listAction',  '_sonata_admin' => 'app.admin.areas',  '_sonata_name' => 'admin_app_areas_list',  '_route' => 'admin_app_areas_list',);
                    }

                    // admin_app_areas_create
                    if ('/admin/app/areas/create' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\AreasAdminController::createAction',  '_sonata_admin' => 'app.admin.areas',  '_sonata_name' => 'admin_app_areas_create',  '_route' => 'admin_app_areas_create',);
                    }

                    // admin_app_areas_batch
                    if ('/admin/app/areas/batch' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\AreasAdminController::batchAction',  '_sonata_admin' => 'app.admin.areas',  '_sonata_name' => 'admin_app_areas_batch',  '_route' => 'admin_app_areas_batch',);
                    }

                    // admin_app_areas_edit
                    if (preg_match('#^/admin/app/areas/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_areas_edit')), array (  '_controller' => 'AppBundle\\Controller\\AreasAdminController::editAction',  '_sonata_admin' => 'app.admin.areas',  '_sonata_name' => 'admin_app_areas_edit',));
                    }

                    // admin_app_areas_delete
                    if (preg_match('#^/admin/app/areas/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_areas_delete')), array (  '_controller' => 'AppBundle\\Controller\\AreasAdminController::deleteAction',  '_sonata_admin' => 'app.admin.areas',  '_sonata_name' => 'admin_app_areas_delete',));
                    }

                    // admin_app_areas_show
                    if (preg_match('#^/admin/app/areas/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_areas_show')), array (  '_controller' => 'AppBundle\\Controller\\AreasAdminController::showAction',  '_sonata_admin' => 'app.admin.areas',  '_sonata_name' => 'admin_app_areas_show',));
                    }

                    // admin_app_areas_export
                    if ('/admin/app/areas/export' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\AreasAdminController::exportAction',  '_sonata_admin' => 'app.admin.areas',  '_sonata_name' => 'admin_app_areas_export',  '_route' => 'admin_app_areas_export',);
                    }

                }

                if (0 === strpos($pathinfo, '/admin/app/c')) {
                    if (0 === strpos($pathinfo, '/admin/app/cantidadesbeneficioinst')) {
                        // admin_app_cantidadesbeneficioinst_list
                        if ('/admin/app/cantidadesbeneficioinst/list' === $pathinfo) {
                            return array (  '_controller' => 'AppBundle\\Controller\\CantidadesbeneficioinstAdminController::listAction',  '_sonata_admin' => 'app.admin.cantidadesbeneficioinst',  '_sonata_name' => 'admin_app_cantidadesbeneficioinst_list',  '_route' => 'admin_app_cantidadesbeneficioinst_list',);
                        }

                        // admin_app_cantidadesbeneficioinst_create
                        if ('/admin/app/cantidadesbeneficioinst/create' === $pathinfo) {
                            return array (  '_controller' => 'AppBundle\\Controller\\CantidadesbeneficioinstAdminController::createAction',  '_sonata_admin' => 'app.admin.cantidadesbeneficioinst',  '_sonata_name' => 'admin_app_cantidadesbeneficioinst_create',  '_route' => 'admin_app_cantidadesbeneficioinst_create',);
                        }

                        // admin_app_cantidadesbeneficioinst_batch
                        if ('/admin/app/cantidadesbeneficioinst/batch' === $pathinfo) {
                            return array (  '_controller' => 'AppBundle\\Controller\\CantidadesbeneficioinstAdminController::batchAction',  '_sonata_admin' => 'app.admin.cantidadesbeneficioinst',  '_sonata_name' => 'admin_app_cantidadesbeneficioinst_batch',  '_route' => 'admin_app_cantidadesbeneficioinst_batch',);
                        }

                        // admin_app_cantidadesbeneficioinst_edit
                        if (preg_match('#^/admin/app/cantidadesbeneficioinst/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_cantidadesbeneficioinst_edit')), array (  '_controller' => 'AppBundle\\Controller\\CantidadesbeneficioinstAdminController::editAction',  '_sonata_admin' => 'app.admin.cantidadesbeneficioinst',  '_sonata_name' => 'admin_app_cantidadesbeneficioinst_edit',));
                        }

                        // admin_app_cantidadesbeneficioinst_delete
                        if (preg_match('#^/admin/app/cantidadesbeneficioinst/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_cantidadesbeneficioinst_delete')), array (  '_controller' => 'AppBundle\\Controller\\CantidadesbeneficioinstAdminController::deleteAction',  '_sonata_admin' => 'app.admin.cantidadesbeneficioinst',  '_sonata_name' => 'admin_app_cantidadesbeneficioinst_delete',));
                        }

                        // admin_app_cantidadesbeneficioinst_show
                        if (preg_match('#^/admin/app/cantidadesbeneficioinst/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_cantidadesbeneficioinst_show')), array (  '_controller' => 'AppBundle\\Controller\\CantidadesbeneficioinstAdminController::showAction',  '_sonata_admin' => 'app.admin.cantidadesbeneficioinst',  '_sonata_name' => 'admin_app_cantidadesbeneficioinst_show',));
                        }

                        // admin_app_cantidadesbeneficioinst_export
                        if ('/admin/app/cantidadesbeneficioinst/export' === $pathinfo) {
                            return array (  '_controller' => 'AppBundle\\Controller\\CantidadesbeneficioinstAdminController::exportAction',  '_sonata_admin' => 'app.admin.cantidadesbeneficioinst',  '_sonata_name' => 'admin_app_cantidadesbeneficioinst_export',  '_route' => 'admin_app_cantidadesbeneficioinst_export',);
                        }

                    }

                    if (0 === strpos($pathinfo, '/admin/app/conceptos')) {
                        if (0 === strpos($pathinfo, '/admin/app/conceptosjunta')) {
                            // admin_app_conceptosjunta_list
                            if ('/admin/app/conceptosjunta/list' === $pathinfo) {
                                return array (  '_controller' => 'AppBundle\\Controller\\ConceptosjuntaAdminController::listAction',  '_sonata_admin' => 'app.admin.conceptosjunta',  '_sonata_name' => 'admin_app_conceptosjunta_list',  '_route' => 'admin_app_conceptosjunta_list',);
                            }

                            // admin_app_conceptosjunta_create
                            if ('/admin/app/conceptosjunta/create' === $pathinfo) {
                                return array (  '_controller' => 'AppBundle\\Controller\\ConceptosjuntaAdminController::createAction',  '_sonata_admin' => 'app.admin.conceptosjunta',  '_sonata_name' => 'admin_app_conceptosjunta_create',  '_route' => 'admin_app_conceptosjunta_create',);
                            }

                            // admin_app_conceptosjunta_batch
                            if ('/admin/app/conceptosjunta/batch' === $pathinfo) {
                                return array (  '_controller' => 'AppBundle\\Controller\\ConceptosjuntaAdminController::batchAction',  '_sonata_admin' => 'app.admin.conceptosjunta',  '_sonata_name' => 'admin_app_conceptosjunta_batch',  '_route' => 'admin_app_conceptosjunta_batch',);
                            }

                            // admin_app_conceptosjunta_edit
                            if (preg_match('#^/admin/app/conceptosjunta/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                                return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_conceptosjunta_edit')), array (  '_controller' => 'AppBundle\\Controller\\ConceptosjuntaAdminController::editAction',  '_sonata_admin' => 'app.admin.conceptosjunta',  '_sonata_name' => 'admin_app_conceptosjunta_edit',));
                            }

                            // admin_app_conceptosjunta_delete
                            if (preg_match('#^/admin/app/conceptosjunta/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                                return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_conceptosjunta_delete')), array (  '_controller' => 'AppBundle\\Controller\\ConceptosjuntaAdminController::deleteAction',  '_sonata_admin' => 'app.admin.conceptosjunta',  '_sonata_name' => 'admin_app_conceptosjunta_delete',));
                            }

                            // admin_app_conceptosjunta_show
                            if (preg_match('#^/admin/app/conceptosjunta/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                                return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_conceptosjunta_show')), array (  '_controller' => 'AppBundle\\Controller\\ConceptosjuntaAdminController::showAction',  '_sonata_admin' => 'app.admin.conceptosjunta',  '_sonata_name' => 'admin_app_conceptosjunta_show',));
                            }

                            // admin_app_conceptosjunta_export
                            if ('/admin/app/conceptosjunta/export' === $pathinfo) {
                                return array (  '_controller' => 'AppBundle\\Controller\\ConceptosjuntaAdminController::exportAction',  '_sonata_admin' => 'app.admin.conceptosjunta',  '_sonata_name' => 'admin_app_conceptosjunta_export',  '_route' => 'admin_app_conceptosjunta_export',);
                            }

                        }

                        if (0 === strpos($pathinfo, '/admin/app/conceptosvisita')) {
                            // admin_app_conceptosvisita_list
                            if ('/admin/app/conceptosvisita/list' === $pathinfo) {
                                return array (  '_controller' => 'AppBundle\\Controller\\ConceptosvisitaAdminController::listAction',  '_sonata_admin' => 'app.admin.conceptosvisita',  '_sonata_name' => 'admin_app_conceptosvisita_list',  '_route' => 'admin_app_conceptosvisita_list',);
                            }

                            // admin_app_conceptosvisita_create
                            if ('/admin/app/conceptosvisita/create' === $pathinfo) {
                                return array (  '_controller' => 'AppBundle\\Controller\\ConceptosvisitaAdminController::createAction',  '_sonata_admin' => 'app.admin.conceptosvisita',  '_sonata_name' => 'admin_app_conceptosvisita_create',  '_route' => 'admin_app_conceptosvisita_create',);
                            }

                            // admin_app_conceptosvisita_batch
                            if ('/admin/app/conceptosvisita/batch' === $pathinfo) {
                                return array (  '_controller' => 'AppBundle\\Controller\\ConceptosvisitaAdminController::batchAction',  '_sonata_admin' => 'app.admin.conceptosvisita',  '_sonata_name' => 'admin_app_conceptosvisita_batch',  '_route' => 'admin_app_conceptosvisita_batch',);
                            }

                            // admin_app_conceptosvisita_edit
                            if (preg_match('#^/admin/app/conceptosvisita/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                                return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_conceptosvisita_edit')), array (  '_controller' => 'AppBundle\\Controller\\ConceptosvisitaAdminController::editAction',  '_sonata_admin' => 'app.admin.conceptosvisita',  '_sonata_name' => 'admin_app_conceptosvisita_edit',));
                            }

                            // admin_app_conceptosvisita_delete
                            if (preg_match('#^/admin/app/conceptosvisita/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                                return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_conceptosvisita_delete')), array (  '_controller' => 'AppBundle\\Controller\\ConceptosvisitaAdminController::deleteAction',  '_sonata_admin' => 'app.admin.conceptosvisita',  '_sonata_name' => 'admin_app_conceptosvisita_delete',));
                            }

                            // admin_app_conceptosvisita_show
                            if (preg_match('#^/admin/app/conceptosvisita/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                                return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_conceptosvisita_show')), array (  '_controller' => 'AppBundle\\Controller\\ConceptosvisitaAdminController::showAction',  '_sonata_admin' => 'app.admin.conceptosvisita',  '_sonata_name' => 'admin_app_conceptosvisita_show',));
                            }

                            // admin_app_conceptosvisita_export
                            if ('/admin/app/conceptosvisita/export' === $pathinfo) {
                                return array (  '_controller' => 'AppBundle\\Controller\\ConceptosvisitaAdminController::exportAction',  '_sonata_admin' => 'app.admin.conceptosvisita',  '_sonata_name' => 'admin_app_conceptosvisita_export',  '_route' => 'admin_app_conceptosvisita_export',);
                            }

                        }

                    }

                }

                if (0 === strpos($pathinfo, '/admin/app/estadosciviles')) {
                    // admin_app_estadosciviles_list
                    if ('/admin/app/estadosciviles/list' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\EstadoscivilesAdminController::listAction',  '_sonata_admin' => 'app.admin.estadosciviles',  '_sonata_name' => 'admin_app_estadosciviles_list',  '_route' => 'admin_app_estadosciviles_list',);
                    }

                    // admin_app_estadosciviles_create
                    if ('/admin/app/estadosciviles/create' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\EstadoscivilesAdminController::createAction',  '_sonata_admin' => 'app.admin.estadosciviles',  '_sonata_name' => 'admin_app_estadosciviles_create',  '_route' => 'admin_app_estadosciviles_create',);
                    }

                    // admin_app_estadosciviles_batch
                    if ('/admin/app/estadosciviles/batch' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\EstadoscivilesAdminController::batchAction',  '_sonata_admin' => 'app.admin.estadosciviles',  '_sonata_name' => 'admin_app_estadosciviles_batch',  '_route' => 'admin_app_estadosciviles_batch',);
                    }

                    // admin_app_estadosciviles_edit
                    if (preg_match('#^/admin/app/estadosciviles/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_estadosciviles_edit')), array (  '_controller' => 'AppBundle\\Controller\\EstadoscivilesAdminController::editAction',  '_sonata_admin' => 'app.admin.estadosciviles',  '_sonata_name' => 'admin_app_estadosciviles_edit',));
                    }

                    // admin_app_estadosciviles_delete
                    if (preg_match('#^/admin/app/estadosciviles/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_estadosciviles_delete')), array (  '_controller' => 'AppBundle\\Controller\\EstadoscivilesAdminController::deleteAction',  '_sonata_admin' => 'app.admin.estadosciviles',  '_sonata_name' => 'admin_app_estadosciviles_delete',));
                    }

                    // admin_app_estadosciviles_show
                    if (preg_match('#^/admin/app/estadosciviles/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_estadosciviles_show')), array (  '_controller' => 'AppBundle\\Controller\\EstadoscivilesAdminController::showAction',  '_sonata_admin' => 'app.admin.estadosciviles',  '_sonata_name' => 'admin_app_estadosciviles_show',));
                    }

                    // admin_app_estadosciviles_export
                    if ('/admin/app/estadosciviles/export' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\EstadoscivilesAdminController::exportAction',  '_sonata_admin' => 'app.admin.estadosciviles',  '_sonata_name' => 'admin_app_estadosciviles_export',  '_route' => 'admin_app_estadosciviles_export',);
                    }

                }

                if (0 === strpos($pathinfo, '/admin/app/grados')) {
                    // admin_app_grados_list
                    if ('/admin/app/grados/list' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\GradosAdminController::listAction',  '_sonata_admin' => 'app.admin.grados',  '_sonata_name' => 'admin_app_grados_list',  '_route' => 'admin_app_grados_list',);
                    }

                    // admin_app_grados_create
                    if ('/admin/app/grados/create' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\GradosAdminController::createAction',  '_sonata_admin' => 'app.admin.grados',  '_sonata_name' => 'admin_app_grados_create',  '_route' => 'admin_app_grados_create',);
                    }

                    // admin_app_grados_batch
                    if ('/admin/app/grados/batch' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\GradosAdminController::batchAction',  '_sonata_admin' => 'app.admin.grados',  '_sonata_name' => 'admin_app_grados_batch',  '_route' => 'admin_app_grados_batch',);
                    }

                    // admin_app_grados_edit
                    if (preg_match('#^/admin/app/grados/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_grados_edit')), array (  '_controller' => 'AppBundle\\Controller\\GradosAdminController::editAction',  '_sonata_admin' => 'app.admin.grados',  '_sonata_name' => 'admin_app_grados_edit',));
                    }

                    // admin_app_grados_delete
                    if (preg_match('#^/admin/app/grados/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_grados_delete')), array (  '_controller' => 'AppBundle\\Controller\\GradosAdminController::deleteAction',  '_sonata_admin' => 'app.admin.grados',  '_sonata_name' => 'admin_app_grados_delete',));
                    }

                    // admin_app_grados_show
                    if (preg_match('#^/admin/app/grados/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_grados_show')), array (  '_controller' => 'AppBundle\\Controller\\GradosAdminController::showAction',  '_sonata_admin' => 'app.admin.grados',  '_sonata_name' => 'admin_app_grados_show',));
                    }

                    // admin_app_grados_export
                    if ('/admin/app/grados/export' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\GradosAdminController::exportAction',  '_sonata_admin' => 'app.admin.grados',  '_sonata_name' => 'admin_app_grados_export',  '_route' => 'admin_app_grados_export',);
                    }

                }

                if (0 === strpos($pathinfo, '/admin/app/ingresos')) {
                    // admin_app_ingresos_list
                    if ('/admin/app/ingresos/list' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\IngresosAdminController::listAction',  '_sonata_admin' => 'app.admin.ingresos',  '_sonata_name' => 'admin_app_ingresos_list',  '_route' => 'admin_app_ingresos_list',);
                    }

                    // admin_app_ingresos_create
                    if ('/admin/app/ingresos/create' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\IngresosAdminController::createAction',  '_sonata_admin' => 'app.admin.ingresos',  '_sonata_name' => 'admin_app_ingresos_create',  '_route' => 'admin_app_ingresos_create',);
                    }

                    // admin_app_ingresos_batch
                    if ('/admin/app/ingresos/batch' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\IngresosAdminController::batchAction',  '_sonata_admin' => 'app.admin.ingresos',  '_sonata_name' => 'admin_app_ingresos_batch',  '_route' => 'admin_app_ingresos_batch',);
                    }

                    // admin_app_ingresos_edit
                    if (preg_match('#^/admin/app/ingresos/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_ingresos_edit')), array (  '_controller' => 'AppBundle\\Controller\\IngresosAdminController::editAction',  '_sonata_admin' => 'app.admin.ingresos',  '_sonata_name' => 'admin_app_ingresos_edit',));
                    }

                    // admin_app_ingresos_delete
                    if (preg_match('#^/admin/app/ingresos/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_ingresos_delete')), array (  '_controller' => 'AppBundle\\Controller\\IngresosAdminController::deleteAction',  '_sonata_admin' => 'app.admin.ingresos',  '_sonata_name' => 'admin_app_ingresos_delete',));
                    }

                    // admin_app_ingresos_show
                    if (preg_match('#^/admin/app/ingresos/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_ingresos_show')), array (  '_controller' => 'AppBundle\\Controller\\IngresosAdminController::showAction',  '_sonata_admin' => 'app.admin.ingresos',  '_sonata_name' => 'admin_app_ingresos_show',));
                    }

                    // admin_app_ingresos_export
                    if ('/admin/app/ingresos/export' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\IngresosAdminController::exportAction',  '_sonata_admin' => 'app.admin.ingresos',  '_sonata_name' => 'admin_app_ingresos_export',  '_route' => 'admin_app_ingresos_export',);
                    }

                }

                if (0 === strpos($pathinfo, '/admin/app/motivosdeuda')) {
                    // admin_app_motivosdeuda_list
                    if ('/admin/app/motivosdeuda/list' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\MotivosdeudaAdminController::listAction',  '_sonata_admin' => 'app.admin.motivosdeuda',  '_sonata_name' => 'admin_app_motivosdeuda_list',  '_route' => 'admin_app_motivosdeuda_list',);
                    }

                    // admin_app_motivosdeuda_create
                    if ('/admin/app/motivosdeuda/create' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\MotivosdeudaAdminController::createAction',  '_sonata_admin' => 'app.admin.motivosdeuda',  '_sonata_name' => 'admin_app_motivosdeuda_create',  '_route' => 'admin_app_motivosdeuda_create',);
                    }

                    // admin_app_motivosdeuda_batch
                    if ('/admin/app/motivosdeuda/batch' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\MotivosdeudaAdminController::batchAction',  '_sonata_admin' => 'app.admin.motivosdeuda',  '_sonata_name' => 'admin_app_motivosdeuda_batch',  '_route' => 'admin_app_motivosdeuda_batch',);
                    }

                    // admin_app_motivosdeuda_edit
                    if (preg_match('#^/admin/app/motivosdeuda/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_motivosdeuda_edit')), array (  '_controller' => 'AppBundle\\Controller\\MotivosdeudaAdminController::editAction',  '_sonata_admin' => 'app.admin.motivosdeuda',  '_sonata_name' => 'admin_app_motivosdeuda_edit',));
                    }

                    // admin_app_motivosdeuda_delete
                    if (preg_match('#^/admin/app/motivosdeuda/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_motivosdeuda_delete')), array (  '_controller' => 'AppBundle\\Controller\\MotivosdeudaAdminController::deleteAction',  '_sonata_admin' => 'app.admin.motivosdeuda',  '_sonata_name' => 'admin_app_motivosdeuda_delete',));
                    }

                    // admin_app_motivosdeuda_show
                    if (preg_match('#^/admin/app/motivosdeuda/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_motivosdeuda_show')), array (  '_controller' => 'AppBundle\\Controller\\MotivosdeudaAdminController::showAction',  '_sonata_admin' => 'app.admin.motivosdeuda',  '_sonata_name' => 'admin_app_motivosdeuda_show',));
                    }

                    // admin_app_motivosdeuda_export
                    if ('/admin/app/motivosdeuda/export' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\MotivosdeudaAdminController::exportAction',  '_sonata_admin' => 'app.admin.motivosdeuda',  '_sonata_name' => 'admin_app_motivosdeuda_export',  '_route' => 'admin_app_motivosdeuda_export',);
                    }

                }

                if (0 === strpos($pathinfo, '/admin/app/p')) {
                    if (0 === strpos($pathinfo, '/admin/app/parentescos')) {
                        // admin_app_parentescos_list
                        if ('/admin/app/parentescos/list' === $pathinfo) {
                            return array (  '_controller' => 'AppBundle\\Controller\\ParentescosAdminController::listAction',  '_sonata_admin' => 'app.admin.parentescos',  '_sonata_name' => 'admin_app_parentescos_list',  '_route' => 'admin_app_parentescos_list',);
                        }

                        // admin_app_parentescos_create
                        if ('/admin/app/parentescos/create' === $pathinfo) {
                            return array (  '_controller' => 'AppBundle\\Controller\\ParentescosAdminController::createAction',  '_sonata_admin' => 'app.admin.parentescos',  '_sonata_name' => 'admin_app_parentescos_create',  '_route' => 'admin_app_parentescos_create',);
                        }

                        // admin_app_parentescos_batch
                        if ('/admin/app/parentescos/batch' === $pathinfo) {
                            return array (  '_controller' => 'AppBundle\\Controller\\ParentescosAdminController::batchAction',  '_sonata_admin' => 'app.admin.parentescos',  '_sonata_name' => 'admin_app_parentescos_batch',  '_route' => 'admin_app_parentescos_batch',);
                        }

                        // admin_app_parentescos_edit
                        if (preg_match('#^/admin/app/parentescos/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_parentescos_edit')), array (  '_controller' => 'AppBundle\\Controller\\ParentescosAdminController::editAction',  '_sonata_admin' => 'app.admin.parentescos',  '_sonata_name' => 'admin_app_parentescos_edit',));
                        }

                        // admin_app_parentescos_delete
                        if (preg_match('#^/admin/app/parentescos/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_parentescos_delete')), array (  '_controller' => 'AppBundle\\Controller\\ParentescosAdminController::deleteAction',  '_sonata_admin' => 'app.admin.parentescos',  '_sonata_name' => 'admin_app_parentescos_delete',));
                        }

                        // admin_app_parentescos_show
                        if (preg_match('#^/admin/app/parentescos/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_parentescos_show')), array (  '_controller' => 'AppBundle\\Controller\\ParentescosAdminController::showAction',  '_sonata_admin' => 'app.admin.parentescos',  '_sonata_name' => 'admin_app_parentescos_show',));
                        }

                        // admin_app_parentescos_export
                        if ('/admin/app/parentescos/export' === $pathinfo) {
                            return array (  '_controller' => 'AppBundle\\Controller\\ParentescosAdminController::exportAction',  '_sonata_admin' => 'app.admin.parentescos',  '_sonata_name' => 'admin_app_parentescos_export',  '_route' => 'admin_app_parentescos_export',);
                        }

                    }

                    if (0 === strpos($pathinfo, '/admin/app/personascargo')) {
                        // admin_app_personascargo_list
                        if ('/admin/app/personascargo/list' === $pathinfo) {
                            return array (  '_controller' => 'AppBundle\\Controller\\PersonascargoAdminController::listAction',  '_sonata_admin' => 'app.admin.personascargo',  '_sonata_name' => 'admin_app_personascargo_list',  '_route' => 'admin_app_personascargo_list',);
                        }

                        // admin_app_personascargo_create
                        if ('/admin/app/personascargo/create' === $pathinfo) {
                            return array (  '_controller' => 'AppBundle\\Controller\\PersonascargoAdminController::createAction',  '_sonata_admin' => 'app.admin.personascargo',  '_sonata_name' => 'admin_app_personascargo_create',  '_route' => 'admin_app_personascargo_create',);
                        }

                        // admin_app_personascargo_batch
                        if ('/admin/app/personascargo/batch' === $pathinfo) {
                            return array (  '_controller' => 'AppBundle\\Controller\\PersonascargoAdminController::batchAction',  '_sonata_admin' => 'app.admin.personascargo',  '_sonata_name' => 'admin_app_personascargo_batch',  '_route' => 'admin_app_personascargo_batch',);
                        }

                        // admin_app_personascargo_edit
                        if (preg_match('#^/admin/app/personascargo/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_personascargo_edit')), array (  '_controller' => 'AppBundle\\Controller\\PersonascargoAdminController::editAction',  '_sonata_admin' => 'app.admin.personascargo',  '_sonata_name' => 'admin_app_personascargo_edit',));
                        }

                        // admin_app_personascargo_delete
                        if (preg_match('#^/admin/app/personascargo/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_personascargo_delete')), array (  '_controller' => 'AppBundle\\Controller\\PersonascargoAdminController::deleteAction',  '_sonata_admin' => 'app.admin.personascargo',  '_sonata_name' => 'admin_app_personascargo_delete',));
                        }

                        // admin_app_personascargo_show
                        if (preg_match('#^/admin/app/personascargo/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_personascargo_show')), array (  '_controller' => 'AppBundle\\Controller\\PersonascargoAdminController::showAction',  '_sonata_admin' => 'app.admin.personascargo',  '_sonata_name' => 'admin_app_personascargo_show',));
                        }

                        // admin_app_personascargo_export
                        if ('/admin/app/personascargo/export' === $pathinfo) {
                            return array (  '_controller' => 'AppBundle\\Controller\\PersonascargoAdminController::exportAction',  '_sonata_admin' => 'app.admin.personascargo',  '_sonata_name' => 'admin_app_personascargo_export',  '_route' => 'admin_app_personascargo_export',);
                        }

                    }

                    if (0 === strpos($pathinfo, '/admin/app/poblacionbeneficia')) {
                        // admin_app_poblacionbeneficia_list
                        if ('/admin/app/poblacionbeneficia/list' === $pathinfo) {
                            return array (  '_controller' => 'AppBundle\\Controller\\PoblacionbeneficiaAdminController::listAction',  '_sonata_admin' => 'app.admin.poblacionbeneficia',  '_sonata_name' => 'admin_app_poblacionbeneficia_list',  '_route' => 'admin_app_poblacionbeneficia_list',);
                        }

                        // admin_app_poblacionbeneficia_create
                        if ('/admin/app/poblacionbeneficia/create' === $pathinfo) {
                            return array (  '_controller' => 'AppBundle\\Controller\\PoblacionbeneficiaAdminController::createAction',  '_sonata_admin' => 'app.admin.poblacionbeneficia',  '_sonata_name' => 'admin_app_poblacionbeneficia_create',  '_route' => 'admin_app_poblacionbeneficia_create',);
                        }

                        // admin_app_poblacionbeneficia_batch
                        if ('/admin/app/poblacionbeneficia/batch' === $pathinfo) {
                            return array (  '_controller' => 'AppBundle\\Controller\\PoblacionbeneficiaAdminController::batchAction',  '_sonata_admin' => 'app.admin.poblacionbeneficia',  '_sonata_name' => 'admin_app_poblacionbeneficia_batch',  '_route' => 'admin_app_poblacionbeneficia_batch',);
                        }

                        // admin_app_poblacionbeneficia_edit
                        if (preg_match('#^/admin/app/poblacionbeneficia/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_poblacionbeneficia_edit')), array (  '_controller' => 'AppBundle\\Controller\\PoblacionbeneficiaAdminController::editAction',  '_sonata_admin' => 'app.admin.poblacionbeneficia',  '_sonata_name' => 'admin_app_poblacionbeneficia_edit',));
                        }

                        // admin_app_poblacionbeneficia_delete
                        if (preg_match('#^/admin/app/poblacionbeneficia/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_poblacionbeneficia_delete')), array (  '_controller' => 'AppBundle\\Controller\\PoblacionbeneficiaAdminController::deleteAction',  '_sonata_admin' => 'app.admin.poblacionbeneficia',  '_sonata_name' => 'admin_app_poblacionbeneficia_delete',));
                        }

                        // admin_app_poblacionbeneficia_show
                        if (preg_match('#^/admin/app/poblacionbeneficia/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_poblacionbeneficia_show')), array (  '_controller' => 'AppBundle\\Controller\\PoblacionbeneficiaAdminController::showAction',  '_sonata_admin' => 'app.admin.poblacionbeneficia',  '_sonata_name' => 'admin_app_poblacionbeneficia_show',));
                        }

                        // admin_app_poblacionbeneficia_export
                        if ('/admin/app/poblacionbeneficia/export' === $pathinfo) {
                            return array (  '_controller' => 'AppBundle\\Controller\\PoblacionbeneficiaAdminController::exportAction',  '_sonata_admin' => 'app.admin.poblacionbeneficia',  '_sonata_name' => 'admin_app_poblacionbeneficia_export',  '_route' => 'admin_app_poblacionbeneficia_export',);
                        }

                    }

                    if (0 === strpos($pathinfo, '/admin/app/pr')) {
                        if (0 === strpos($pathinfo, '/admin/app/presupuestos')) {
                            // admin_app_presupuestos_list
                            if ('/admin/app/presupuestos/list' === $pathinfo) {
                                return array (  '_controller' => 'AppBundle\\Controller\\PresupuestosAdminController::listAction',  '_sonata_admin' => 'app.admin.presupuestos',  '_sonata_name' => 'admin_app_presupuestos_list',  '_route' => 'admin_app_presupuestos_list',);
                            }

                            // admin_app_presupuestos_create
                            if ('/admin/app/presupuestos/create' === $pathinfo) {
                                return array (  '_controller' => 'AppBundle\\Controller\\PresupuestosAdminController::createAction',  '_sonata_admin' => 'app.admin.presupuestos',  '_sonata_name' => 'admin_app_presupuestos_create',  '_route' => 'admin_app_presupuestos_create',);
                            }

                            // admin_app_presupuestos_batch
                            if ('/admin/app/presupuestos/batch' === $pathinfo) {
                                return array (  '_controller' => 'AppBundle\\Controller\\PresupuestosAdminController::batchAction',  '_sonata_admin' => 'app.admin.presupuestos',  '_sonata_name' => 'admin_app_presupuestos_batch',  '_route' => 'admin_app_presupuestos_batch',);
                            }

                            // admin_app_presupuestos_edit
                            if (preg_match('#^/admin/app/presupuestos/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                                return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_presupuestos_edit')), array (  '_controller' => 'AppBundle\\Controller\\PresupuestosAdminController::editAction',  '_sonata_admin' => 'app.admin.presupuestos',  '_sonata_name' => 'admin_app_presupuestos_edit',));
                            }

                            // admin_app_presupuestos_delete
                            if (preg_match('#^/admin/app/presupuestos/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                                return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_presupuestos_delete')), array (  '_controller' => 'AppBundle\\Controller\\PresupuestosAdminController::deleteAction',  '_sonata_admin' => 'app.admin.presupuestos',  '_sonata_name' => 'admin_app_presupuestos_delete',));
                            }

                            // admin_app_presupuestos_show
                            if (preg_match('#^/admin/app/presupuestos/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                                return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_presupuestos_show')), array (  '_controller' => 'AppBundle\\Controller\\PresupuestosAdminController::showAction',  '_sonata_admin' => 'app.admin.presupuestos',  '_sonata_name' => 'admin_app_presupuestos_show',));
                            }

                            // admin_app_presupuestos_export
                            if ('/admin/app/presupuestos/export' === $pathinfo) {
                                return array (  '_controller' => 'AppBundle\\Controller\\PresupuestosAdminController::exportAction',  '_sonata_admin' => 'app.admin.presupuestos',  '_sonata_name' => 'admin_app_presupuestos_export',  '_route' => 'admin_app_presupuestos_export',);
                            }

                        }

                        if (0 === strpos($pathinfo, '/admin/app/programas')) {
                            // admin_app_programas_list
                            if ('/admin/app/programas/list' === $pathinfo) {
                                return array (  '_controller' => 'AppBundle\\Controller\\ProgramasAdminController::listAction',  '_sonata_admin' => 'app.admin.programas',  '_sonata_name' => 'admin_app_programas_list',  '_route' => 'admin_app_programas_list',);
                            }

                            // admin_app_programas_create
                            if ('/admin/app/programas/create' === $pathinfo) {
                                return array (  '_controller' => 'AppBundle\\Controller\\ProgramasAdminController::createAction',  '_sonata_admin' => 'app.admin.programas',  '_sonata_name' => 'admin_app_programas_create',  '_route' => 'admin_app_programas_create',);
                            }

                            // admin_app_programas_batch
                            if ('/admin/app/programas/batch' === $pathinfo) {
                                return array (  '_controller' => 'AppBundle\\Controller\\ProgramasAdminController::batchAction',  '_sonata_admin' => 'app.admin.programas',  '_sonata_name' => 'admin_app_programas_batch',  '_route' => 'admin_app_programas_batch',);
                            }

                            // admin_app_programas_edit
                            if (preg_match('#^/admin/app/programas/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                                return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_programas_edit')), array (  '_controller' => 'AppBundle\\Controller\\ProgramasAdminController::editAction',  '_sonata_admin' => 'app.admin.programas',  '_sonata_name' => 'admin_app_programas_edit',));
                            }

                            // admin_app_programas_delete
                            if (preg_match('#^/admin/app/programas/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                                return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_programas_delete')), array (  '_controller' => 'AppBundle\\Controller\\ProgramasAdminController::deleteAction',  '_sonata_admin' => 'app.admin.programas',  '_sonata_name' => 'admin_app_programas_delete',));
                            }

                            // admin_app_programas_show
                            if (preg_match('#^/admin/app/programas/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                                return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_programas_show')), array (  '_controller' => 'AppBundle\\Controller\\ProgramasAdminController::showAction',  '_sonata_admin' => 'app.admin.programas',  '_sonata_name' => 'admin_app_programas_show',));
                            }

                            // admin_app_programas_export
                            if ('/admin/app/programas/export' === $pathinfo) {
                                return array (  '_controller' => 'AppBundle\\Controller\\ProgramasAdminController::exportAction',  '_sonata_admin' => 'app.admin.programas',  '_sonata_name' => 'admin_app_programas_export',  '_route' => 'admin_app_programas_export',);
                            }

                        }

                    }

                }

                if (0 === strpos($pathinfo, '/admin/app/s')) {
                    if (0 === strpos($pathinfo, '/admin/app/seccionales')) {
                        // admin_app_seccionales_list
                        if ('/admin/app/seccionales/list' === $pathinfo) {
                            return array (  '_controller' => 'AppBundle\\Controller\\SeccionalesAdminController::listAction',  '_sonata_admin' => 'app.admin.seccionales',  '_sonata_name' => 'admin_app_seccionales_list',  '_route' => 'admin_app_seccionales_list',);
                        }

                        // admin_app_seccionales_create
                        if ('/admin/app/seccionales/create' === $pathinfo) {
                            return array (  '_controller' => 'AppBundle\\Controller\\SeccionalesAdminController::createAction',  '_sonata_admin' => 'app.admin.seccionales',  '_sonata_name' => 'admin_app_seccionales_create',  '_route' => 'admin_app_seccionales_create',);
                        }

                        // admin_app_seccionales_batch
                        if ('/admin/app/seccionales/batch' === $pathinfo) {
                            return array (  '_controller' => 'AppBundle\\Controller\\SeccionalesAdminController::batchAction',  '_sonata_admin' => 'app.admin.seccionales',  '_sonata_name' => 'admin_app_seccionales_batch',  '_route' => 'admin_app_seccionales_batch',);
                        }

                        // admin_app_seccionales_edit
                        if (preg_match('#^/admin/app/seccionales/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_seccionales_edit')), array (  '_controller' => 'AppBundle\\Controller\\SeccionalesAdminController::editAction',  '_sonata_admin' => 'app.admin.seccionales',  '_sonata_name' => 'admin_app_seccionales_edit',));
                        }

                        // admin_app_seccionales_delete
                        if (preg_match('#^/admin/app/seccionales/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_seccionales_delete')), array (  '_controller' => 'AppBundle\\Controller\\SeccionalesAdminController::deleteAction',  '_sonata_admin' => 'app.admin.seccionales',  '_sonata_name' => 'admin_app_seccionales_delete',));
                        }

                        // admin_app_seccionales_show
                        if (preg_match('#^/admin/app/seccionales/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_seccionales_show')), array (  '_controller' => 'AppBundle\\Controller\\SeccionalesAdminController::showAction',  '_sonata_admin' => 'app.admin.seccionales',  '_sonata_name' => 'admin_app_seccionales_show',));
                        }

                        // admin_app_seccionales_export
                        if ('/admin/app/seccionales/export' === $pathinfo) {
                            return array (  '_controller' => 'AppBundle\\Controller\\SeccionalesAdminController::exportAction',  '_sonata_admin' => 'app.admin.seccionales',  '_sonata_name' => 'admin_app_seccionales_export',  '_route' => 'admin_app_seccionales_export',);
                        }

                    }

                    if (0 === strpos($pathinfo, '/admin/app/situacionesvivienda')) {
                        // admin_app_situacionesvivienda_list
                        if ('/admin/app/situacionesvivienda/list' === $pathinfo) {
                            return array (  '_controller' => 'AppBundle\\Controller\\SituacionesviviendaAdminController::listAction',  '_sonata_admin' => 'app.admin.situacionesvivienda',  '_sonata_name' => 'admin_app_situacionesvivienda_list',  '_route' => 'admin_app_situacionesvivienda_list',);
                        }

                        // admin_app_situacionesvivienda_create
                        if ('/admin/app/situacionesvivienda/create' === $pathinfo) {
                            return array (  '_controller' => 'AppBundle\\Controller\\SituacionesviviendaAdminController::createAction',  '_sonata_admin' => 'app.admin.situacionesvivienda',  '_sonata_name' => 'admin_app_situacionesvivienda_create',  '_route' => 'admin_app_situacionesvivienda_create',);
                        }

                        // admin_app_situacionesvivienda_batch
                        if ('/admin/app/situacionesvivienda/batch' === $pathinfo) {
                            return array (  '_controller' => 'AppBundle\\Controller\\SituacionesviviendaAdminController::batchAction',  '_sonata_admin' => 'app.admin.situacionesvivienda',  '_sonata_name' => 'admin_app_situacionesvivienda_batch',  '_route' => 'admin_app_situacionesvivienda_batch',);
                        }

                        // admin_app_situacionesvivienda_edit
                        if (preg_match('#^/admin/app/situacionesvivienda/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_situacionesvivienda_edit')), array (  '_controller' => 'AppBundle\\Controller\\SituacionesviviendaAdminController::editAction',  '_sonata_admin' => 'app.admin.situacionesvivienda',  '_sonata_name' => 'admin_app_situacionesvivienda_edit',));
                        }

                        // admin_app_situacionesvivienda_delete
                        if (preg_match('#^/admin/app/situacionesvivienda/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_situacionesvivienda_delete')), array (  '_controller' => 'AppBundle\\Controller\\SituacionesviviendaAdminController::deleteAction',  '_sonata_admin' => 'app.admin.situacionesvivienda',  '_sonata_name' => 'admin_app_situacionesvivienda_delete',));
                        }

                        // admin_app_situacionesvivienda_show
                        if (preg_match('#^/admin/app/situacionesvivienda/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_situacionesvivienda_show')), array (  '_controller' => 'AppBundle\\Controller\\SituacionesviviendaAdminController::showAction',  '_sonata_admin' => 'app.admin.situacionesvivienda',  '_sonata_name' => 'admin_app_situacionesvivienda_show',));
                        }

                        // admin_app_situacionesvivienda_export
                        if ('/admin/app/situacionesvivienda/export' === $pathinfo) {
                            return array (  '_controller' => 'AppBundle\\Controller\\SituacionesviviendaAdminController::exportAction',  '_sonata_admin' => 'app.admin.situacionesvivienda',  '_sonata_name' => 'admin_app_situacionesvivienda_export',  '_route' => 'admin_app_situacionesvivienda_export',);
                        }

                    }

                    if (0 === strpos($pathinfo, '/admin/app/solicitudes')) {
                        // admin_app_solicitudes_list
                        if ('/admin/app/solicitudes/list' === $pathinfo) {
                            return array (  '_controller' => 'AppBundle\\Controller\\SolicitudesAdminController::listAction',  '_sonata_admin' => 'app.admin.solicitudes',  '_sonata_name' => 'admin_app_solicitudes_list',  '_route' => 'admin_app_solicitudes_list',);
                        }

                        // admin_app_solicitudes_create
                        if ('/admin/app/solicitudes/create' === $pathinfo) {
                            return array (  '_controller' => 'AppBundle\\Controller\\SolicitudesAdminController::createAction',  '_sonata_admin' => 'app.admin.solicitudes',  '_sonata_name' => 'admin_app_solicitudes_create',  '_route' => 'admin_app_solicitudes_create',);
                        }

                        // admin_app_solicitudes_batch
                        if ('/admin/app/solicitudes/batch' === $pathinfo) {
                            return array (  '_controller' => 'AppBundle\\Controller\\SolicitudesAdminController::batchAction',  '_sonata_admin' => 'app.admin.solicitudes',  '_sonata_name' => 'admin_app_solicitudes_batch',  '_route' => 'admin_app_solicitudes_batch',);
                        }

                        // admin_app_solicitudes_edit
                        if (preg_match('#^/admin/app/solicitudes/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_solicitudes_edit')), array (  '_controller' => 'AppBundle\\Controller\\SolicitudesAdminController::editAction',  '_sonata_admin' => 'app.admin.solicitudes',  '_sonata_name' => 'admin_app_solicitudes_edit',));
                        }

                        // admin_app_solicitudes_delete
                        if (preg_match('#^/admin/app/solicitudes/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_solicitudes_delete')), array (  '_controller' => 'AppBundle\\Controller\\SolicitudesAdminController::deleteAction',  '_sonata_admin' => 'app.admin.solicitudes',  '_sonata_name' => 'admin_app_solicitudes_delete',));
                        }

                        // admin_app_solicitudes_show
                        if (preg_match('#^/admin/app/solicitudes/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_solicitudes_show')), array (  '_controller' => 'AppBundle\\Controller\\SolicitudesAdminController::showAction',  '_sonata_admin' => 'app.admin.solicitudes',  '_sonata_name' => 'admin_app_solicitudes_show',));
                        }

                        // admin_app_solicitudes_export
                        if ('/admin/app/solicitudes/export' === $pathinfo) {
                            return array (  '_controller' => 'AppBundle\\Controller\\SolicitudesAdminController::exportAction',  '_sonata_admin' => 'app.admin.solicitudes',  '_sonata_name' => 'admin_app_solicitudes_export',  '_route' => 'admin_app_solicitudes_export',);
                        }

                    }

                }

                if (0 === strpos($pathinfo, '/admin/app/tipossolicitud')) {
                    // admin_app_tipossolicitud_list
                    if ('/admin/app/tipossolicitud/list' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\TipossolicitudAdminController::listAction',  '_sonata_admin' => 'app.admin.tipossolicitud',  '_sonata_name' => 'admin_app_tipossolicitud_list',  '_route' => 'admin_app_tipossolicitud_list',);
                    }

                    // admin_app_tipossolicitud_create
                    if ('/admin/app/tipossolicitud/create' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\TipossolicitudAdminController::createAction',  '_sonata_admin' => 'app.admin.tipossolicitud',  '_sonata_name' => 'admin_app_tipossolicitud_create',  '_route' => 'admin_app_tipossolicitud_create',);
                    }

                    // admin_app_tipossolicitud_batch
                    if ('/admin/app/tipossolicitud/batch' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\TipossolicitudAdminController::batchAction',  '_sonata_admin' => 'app.admin.tipossolicitud',  '_sonata_name' => 'admin_app_tipossolicitud_batch',  '_route' => 'admin_app_tipossolicitud_batch',);
                    }

                    // admin_app_tipossolicitud_edit
                    if (preg_match('#^/admin/app/tipossolicitud/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_tipossolicitud_edit')), array (  '_controller' => 'AppBundle\\Controller\\TipossolicitudAdminController::editAction',  '_sonata_admin' => 'app.admin.tipossolicitud',  '_sonata_name' => 'admin_app_tipossolicitud_edit',));
                    }

                    // admin_app_tipossolicitud_delete
                    if (preg_match('#^/admin/app/tipossolicitud/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_tipossolicitud_delete')), array (  '_controller' => 'AppBundle\\Controller\\TipossolicitudAdminController::deleteAction',  '_sonata_admin' => 'app.admin.tipossolicitud',  '_sonata_name' => 'admin_app_tipossolicitud_delete',));
                    }

                    // admin_app_tipossolicitud_show
                    if (preg_match('#^/admin/app/tipossolicitud/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_tipossolicitud_show')), array (  '_controller' => 'AppBundle\\Controller\\TipossolicitudAdminController::showAction',  '_sonata_admin' => 'app.admin.tipossolicitud',  '_sonata_name' => 'admin_app_tipossolicitud_show',));
                    }

                    // admin_app_tipossolicitud_export
                    if ('/admin/app/tipossolicitud/export' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\TipossolicitudAdminController::exportAction',  '_sonata_admin' => 'app.admin.tipossolicitud',  '_sonata_name' => 'admin_app_tipossolicitud_export',  '_route' => 'admin_app_tipossolicitud_export',);
                    }

                }

                if (0 === strpos($pathinfo, '/admin/app/viabilidadplaneacion')) {
                    // admin_app_viabilidadplaneacion_list
                    if ('/admin/app/viabilidadplaneacion/list' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\ViabilidadplaneacionAdminController::listAction',  '_sonata_admin' => 'app.admin.viabilidadplaneacion',  '_sonata_name' => 'admin_app_viabilidadplaneacion_list',  '_route' => 'admin_app_viabilidadplaneacion_list',);
                    }

                    // admin_app_viabilidadplaneacion_create
                    if ('/admin/app/viabilidadplaneacion/create' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\ViabilidadplaneacionAdminController::createAction',  '_sonata_admin' => 'app.admin.viabilidadplaneacion',  '_sonata_name' => 'admin_app_viabilidadplaneacion_create',  '_route' => 'admin_app_viabilidadplaneacion_create',);
                    }

                    // admin_app_viabilidadplaneacion_batch
                    if ('/admin/app/viabilidadplaneacion/batch' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\ViabilidadplaneacionAdminController::batchAction',  '_sonata_admin' => 'app.admin.viabilidadplaneacion',  '_sonata_name' => 'admin_app_viabilidadplaneacion_batch',  '_route' => 'admin_app_viabilidadplaneacion_batch',);
                    }

                    // admin_app_viabilidadplaneacion_edit
                    if (preg_match('#^/admin/app/viabilidadplaneacion/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_viabilidadplaneacion_edit')), array (  '_controller' => 'AppBundle\\Controller\\ViabilidadplaneacionAdminController::editAction',  '_sonata_admin' => 'app.admin.viabilidadplaneacion',  '_sonata_name' => 'admin_app_viabilidadplaneacion_edit',));
                    }

                    // admin_app_viabilidadplaneacion_delete
                    if (preg_match('#^/admin/app/viabilidadplaneacion/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_viabilidadplaneacion_delete')), array (  '_controller' => 'AppBundle\\Controller\\ViabilidadplaneacionAdminController::deleteAction',  '_sonata_admin' => 'app.admin.viabilidadplaneacion',  '_sonata_name' => 'admin_app_viabilidadplaneacion_delete',));
                    }

                    // admin_app_viabilidadplaneacion_show
                    if (preg_match('#^/admin/app/viabilidadplaneacion/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_viabilidadplaneacion_show')), array (  '_controller' => 'AppBundle\\Controller\\ViabilidadplaneacionAdminController::showAction',  '_sonata_admin' => 'app.admin.viabilidadplaneacion',  '_sonata_name' => 'admin_app_viabilidadplaneacion_show',));
                    }

                    // admin_app_viabilidadplaneacion_export
                    if ('/admin/app/viabilidadplaneacion/export' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\ViabilidadplaneacionAdminController::exportAction',  '_sonata_admin' => 'app.admin.viabilidadplaneacion',  '_sonata_name' => 'admin_app_viabilidadplaneacion_export',  '_route' => 'admin_app_viabilidadplaneacion_export',);
                    }

                }

                if (0 === strpos($pathinfo, '/admin/app/zonasubicacion')) {
                    // admin_app_zonasubicacion_list
                    if ('/admin/app/zonasubicacion/list' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\ZonasubicacionAdminController::listAction',  '_sonata_admin' => 'app.admin.zonasubicacion',  '_sonata_name' => 'admin_app_zonasubicacion_list',  '_route' => 'admin_app_zonasubicacion_list',);
                    }

                    // admin_app_zonasubicacion_create
                    if ('/admin/app/zonasubicacion/create' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\ZonasubicacionAdminController::createAction',  '_sonata_admin' => 'app.admin.zonasubicacion',  '_sonata_name' => 'admin_app_zonasubicacion_create',  '_route' => 'admin_app_zonasubicacion_create',);
                    }

                    // admin_app_zonasubicacion_batch
                    if ('/admin/app/zonasubicacion/batch' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\ZonasubicacionAdminController::batchAction',  '_sonata_admin' => 'app.admin.zonasubicacion',  '_sonata_name' => 'admin_app_zonasubicacion_batch',  '_route' => 'admin_app_zonasubicacion_batch',);
                    }

                    // admin_app_zonasubicacion_edit
                    if (preg_match('#^/admin/app/zonasubicacion/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_zonasubicacion_edit')), array (  '_controller' => 'AppBundle\\Controller\\ZonasubicacionAdminController::editAction',  '_sonata_admin' => 'app.admin.zonasubicacion',  '_sonata_name' => 'admin_app_zonasubicacion_edit',));
                    }

                    // admin_app_zonasubicacion_delete
                    if (preg_match('#^/admin/app/zonasubicacion/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_zonasubicacion_delete')), array (  '_controller' => 'AppBundle\\Controller\\ZonasubicacionAdminController::deleteAction',  '_sonata_admin' => 'app.admin.zonasubicacion',  '_sonata_name' => 'admin_app_zonasubicacion_delete',));
                    }

                    // admin_app_zonasubicacion_show
                    if (preg_match('#^/admin/app/zonasubicacion/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_zonasubicacion_show')), array (  '_controller' => 'AppBundle\\Controller\\ZonasubicacionAdminController::showAction',  '_sonata_admin' => 'app.admin.zonasubicacion',  '_sonata_name' => 'admin_app_zonasubicacion_show',));
                    }

                    // admin_app_zonasubicacion_export
                    if ('/admin/app/zonasubicacion/export' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\ZonasubicacionAdminController::exportAction',  '_sonata_admin' => 'app.admin.zonasubicacion',  '_sonata_name' => 'admin_app_zonasubicacion_export',  '_route' => 'admin_app_zonasubicacion_export',);
                    }

                }

                if (0 === strpos($pathinfo, '/admin/app/afiliadodibie')) {
                    // admin_app_afiliadodibie_list
                    if ('/admin/app/afiliadodibie/list' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\AfiliadodibieAdminController::listAction',  '_sonata_admin' => 'app.admin.afiliadodibie',  '_sonata_name' => 'admin_app_afiliadodibie_list',  '_route' => 'admin_app_afiliadodibie_list',);
                    }

                    // admin_app_afiliadodibie_create
                    if ('/admin/app/afiliadodibie/create' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\AfiliadodibieAdminController::createAction',  '_sonata_admin' => 'app.admin.afiliadodibie',  '_sonata_name' => 'admin_app_afiliadodibie_create',  '_route' => 'admin_app_afiliadodibie_create',);
                    }

                    // admin_app_afiliadodibie_batch
                    if ('/admin/app/afiliadodibie/batch' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\AfiliadodibieAdminController::batchAction',  '_sonata_admin' => 'app.admin.afiliadodibie',  '_sonata_name' => 'admin_app_afiliadodibie_batch',  '_route' => 'admin_app_afiliadodibie_batch',);
                    }

                    // admin_app_afiliadodibie_edit
                    if (preg_match('#^/admin/app/afiliadodibie/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_afiliadodibie_edit')), array (  '_controller' => 'AppBundle\\Controller\\AfiliadodibieAdminController::editAction',  '_sonata_admin' => 'app.admin.afiliadodibie',  '_sonata_name' => 'admin_app_afiliadodibie_edit',));
                    }

                    // admin_app_afiliadodibie_delete
                    if (preg_match('#^/admin/app/afiliadodibie/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_afiliadodibie_delete')), array (  '_controller' => 'AppBundle\\Controller\\AfiliadodibieAdminController::deleteAction',  '_sonata_admin' => 'app.admin.afiliadodibie',  '_sonata_name' => 'admin_app_afiliadodibie_delete',));
                    }

                    // admin_app_afiliadodibie_show
                    if (preg_match('#^/admin/app/afiliadodibie/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_afiliadodibie_show')), array (  '_controller' => 'AppBundle\\Controller\\AfiliadodibieAdminController::showAction',  '_sonata_admin' => 'app.admin.afiliadodibie',  '_sonata_name' => 'admin_app_afiliadodibie_show',));
                    }

                    // admin_app_afiliadodibie_export
                    if ('/admin/app/afiliadodibie/export' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\AfiliadodibieAdminController::exportAction',  '_sonata_admin' => 'app.admin.afiliadodibie',  '_sonata_name' => 'admin_app_afiliadodibie_export',  '_route' => 'admin_app_afiliadodibie_export',);
                    }

                }

                if (0 === strpos($pathinfo, '/admin/app/unidad')) {
                    // admin_app_unidad_list
                    if ('/admin/app/unidad/list' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\unidadAdminController::listAction',  '_sonata_admin' => 'app.admin.unidad',  '_sonata_name' => 'admin_app_unidad_list',  '_route' => 'admin_app_unidad_list',);
                    }

                    // admin_app_unidad_create
                    if ('/admin/app/unidad/create' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\unidadAdminController::createAction',  '_sonata_admin' => 'app.admin.unidad',  '_sonata_name' => 'admin_app_unidad_create',  '_route' => 'admin_app_unidad_create',);
                    }

                    // admin_app_unidad_batch
                    if ('/admin/app/unidad/batch' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\unidadAdminController::batchAction',  '_sonata_admin' => 'app.admin.unidad',  '_sonata_name' => 'admin_app_unidad_batch',  '_route' => 'admin_app_unidad_batch',);
                    }

                    // admin_app_unidad_edit
                    if (preg_match('#^/admin/app/unidad/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_unidad_edit')), array (  '_controller' => 'AppBundle\\Controller\\unidadAdminController::editAction',  '_sonata_admin' => 'app.admin.unidad',  '_sonata_name' => 'admin_app_unidad_edit',));
                    }

                    // admin_app_unidad_delete
                    if (preg_match('#^/admin/app/unidad/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_unidad_delete')), array (  '_controller' => 'AppBundle\\Controller\\unidadAdminController::deleteAction',  '_sonata_admin' => 'app.admin.unidad',  '_sonata_name' => 'admin_app_unidad_delete',));
                    }

                    // admin_app_unidad_show
                    if (preg_match('#^/admin/app/unidad/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_unidad_show')), array (  '_controller' => 'AppBundle\\Controller\\unidadAdminController::showAction',  '_sonata_admin' => 'app.admin.unidad',  '_sonata_name' => 'admin_app_unidad_show',));
                    }

                    // admin_app_unidad_export
                    if ('/admin/app/unidad/export' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\unidadAdminController::exportAction',  '_sonata_admin' => 'app.admin.unidad',  '_sonata_name' => 'admin_app_unidad_export',  '_route' => 'admin_app_unidad_export',);
                    }

                }

                if (0 === strpos($pathinfo, '/admin/app/antiguedad')) {
                    // admin_app_antiguedad_list
                    if ('/admin/app/antiguedad/list' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\antiguedadAdminController::listAction',  '_sonata_admin' => 'app.admin.antiguedad',  '_sonata_name' => 'admin_app_antiguedad_list',  '_route' => 'admin_app_antiguedad_list',);
                    }

                    // admin_app_antiguedad_create
                    if ('/admin/app/antiguedad/create' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\antiguedadAdminController::createAction',  '_sonata_admin' => 'app.admin.antiguedad',  '_sonata_name' => 'admin_app_antiguedad_create',  '_route' => 'admin_app_antiguedad_create',);
                    }

                    // admin_app_antiguedad_batch
                    if ('/admin/app/antiguedad/batch' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\antiguedadAdminController::batchAction',  '_sonata_admin' => 'app.admin.antiguedad',  '_sonata_name' => 'admin_app_antiguedad_batch',  '_route' => 'admin_app_antiguedad_batch',);
                    }

                    // admin_app_antiguedad_edit
                    if (preg_match('#^/admin/app/antiguedad/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_antiguedad_edit')), array (  '_controller' => 'AppBundle\\Controller\\antiguedadAdminController::editAction',  '_sonata_admin' => 'app.admin.antiguedad',  '_sonata_name' => 'admin_app_antiguedad_edit',));
                    }

                    // admin_app_antiguedad_delete
                    if (preg_match('#^/admin/app/antiguedad/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_antiguedad_delete')), array (  '_controller' => 'AppBundle\\Controller\\antiguedadAdminController::deleteAction',  '_sonata_admin' => 'app.admin.antiguedad',  '_sonata_name' => 'admin_app_antiguedad_delete',));
                    }

                    // admin_app_antiguedad_show
                    if (preg_match('#^/admin/app/antiguedad/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_antiguedad_show')), array (  '_controller' => 'AppBundle\\Controller\\antiguedadAdminController::showAction',  '_sonata_admin' => 'app.admin.antiguedad',  '_sonata_name' => 'admin_app_antiguedad_show',));
                    }

                    // admin_app_antiguedad_export
                    if ('/admin/app/antiguedad/export' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\antiguedadAdminController::exportAction',  '_sonata_admin' => 'app.admin.antiguedad',  '_sonata_name' => 'admin_app_antiguedad_export',  '_route' => 'admin_app_antiguedad_export',);
                    }

                }

                if (0 === strpos($pathinfo, '/admin/app/puntaje')) {
                    // admin_app_puntaje_list
                    if ('/admin/app/puntaje/list' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\puntajeAdminController::listAction',  '_sonata_admin' => 'app.admin.puntaje',  '_sonata_name' => 'admin_app_puntaje_list',  '_route' => 'admin_app_puntaje_list',);
                    }

                    // admin_app_puntaje_create
                    if ('/admin/app/puntaje/create' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\puntajeAdminController::createAction',  '_sonata_admin' => 'app.admin.puntaje',  '_sonata_name' => 'admin_app_puntaje_create',  '_route' => 'admin_app_puntaje_create',);
                    }

                    // admin_app_puntaje_batch
                    if ('/admin/app/puntaje/batch' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\puntajeAdminController::batchAction',  '_sonata_admin' => 'app.admin.puntaje',  '_sonata_name' => 'admin_app_puntaje_batch',  '_route' => 'admin_app_puntaje_batch',);
                    }

                    // admin_app_puntaje_edit
                    if (preg_match('#^/admin/app/puntaje/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_puntaje_edit')), array (  '_controller' => 'AppBundle\\Controller\\puntajeAdminController::editAction',  '_sonata_admin' => 'app.admin.puntaje',  '_sonata_name' => 'admin_app_puntaje_edit',));
                    }

                    // admin_app_puntaje_delete
                    if (preg_match('#^/admin/app/puntaje/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_puntaje_delete')), array (  '_controller' => 'AppBundle\\Controller\\puntajeAdminController::deleteAction',  '_sonata_admin' => 'app.admin.puntaje',  '_sonata_name' => 'admin_app_puntaje_delete',));
                    }

                    // admin_app_puntaje_show
                    if (preg_match('#^/admin/app/puntaje/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_puntaje_show')), array (  '_controller' => 'AppBundle\\Controller\\puntajeAdminController::showAction',  '_sonata_admin' => 'app.admin.puntaje',  '_sonata_name' => 'admin_app_puntaje_show',));
                    }

                    // admin_app_puntaje_export
                    if ('/admin/app/puntaje/export' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\puntajeAdminController::exportAction',  '_sonata_admin' => 'app.admin.puntaje',  '_sonata_name' => 'admin_app_puntaje_export',  '_route' => 'admin_app_puntaje_export',);
                    }

                }

                if (0 === strpos($pathinfo, '/admin/app/otorga')) {
                    // admin_app_otorga_list
                    if ('/admin/app/otorga/list' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\otorgaAdminController::listAction',  '_sonata_admin' => 'app.admin.otorga',  '_sonata_name' => 'admin_app_otorga_list',  '_route' => 'admin_app_otorga_list',);
                    }

                    // admin_app_otorga_create
                    if ('/admin/app/otorga/create' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\otorgaAdminController::createAction',  '_sonata_admin' => 'app.admin.otorga',  '_sonata_name' => 'admin_app_otorga_create',  '_route' => 'admin_app_otorga_create',);
                    }

                    // admin_app_otorga_batch
                    if ('/admin/app/otorga/batch' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\otorgaAdminController::batchAction',  '_sonata_admin' => 'app.admin.otorga',  '_sonata_name' => 'admin_app_otorga_batch',  '_route' => 'admin_app_otorga_batch',);
                    }

                    // admin_app_otorga_edit
                    if (preg_match('#^/admin/app/otorga/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_otorga_edit')), array (  '_controller' => 'AppBundle\\Controller\\otorgaAdminController::editAction',  '_sonata_admin' => 'app.admin.otorga',  '_sonata_name' => 'admin_app_otorga_edit',));
                    }

                    // admin_app_otorga_delete
                    if (preg_match('#^/admin/app/otorga/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_otorga_delete')), array (  '_controller' => 'AppBundle\\Controller\\otorgaAdminController::deleteAction',  '_sonata_admin' => 'app.admin.otorga',  '_sonata_name' => 'admin_app_otorga_delete',));
                    }

                    // admin_app_otorga_show
                    if (preg_match('#^/admin/app/otorga/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_app_otorga_show')), array (  '_controller' => 'AppBundle\\Controller\\otorgaAdminController::showAction',  '_sonata_admin' => 'app.admin.otorga',  '_sonata_name' => 'admin_app_otorga_show',));
                    }

                    // admin_app_otorga_export
                    if ('/admin/app/otorga/export' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\otorgaAdminController::exportAction',  '_sonata_admin' => 'app.admin.otorga',  '_sonata_name' => 'admin_app_otorga_export',  '_route' => 'admin_app_otorga_export',);
                    }

                }

            }

            if (0 === strpos($pathinfo, '/admin/sonata/user')) {
                if (0 === strpos($pathinfo, '/admin/sonata/user/user')) {
                    // admin_sonata_user_user_list
                    if ('/admin/sonata/user/user/list' === $pathinfo) {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::listAction',  '_sonata_admin' => 'sonata.user.admin.user',  '_sonata_name' => 'admin_sonata_user_user_list',  '_route' => 'admin_sonata_user_user_list',);
                    }

                    // admin_sonata_user_user_create
                    if ('/admin/sonata/user/user/create' === $pathinfo) {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::createAction',  '_sonata_admin' => 'sonata.user.admin.user',  '_sonata_name' => 'admin_sonata_user_user_create',  '_route' => 'admin_sonata_user_user_create',);
                    }

                    // admin_sonata_user_user_batch
                    if ('/admin/sonata/user/user/batch' === $pathinfo) {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::batchAction',  '_sonata_admin' => 'sonata.user.admin.user',  '_sonata_name' => 'admin_sonata_user_user_batch',  '_route' => 'admin_sonata_user_user_batch',);
                    }

                    // admin_sonata_user_user_edit
                    if (preg_match('#^/admin/sonata/user/user/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_sonata_user_user_edit')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::editAction',  '_sonata_admin' => 'sonata.user.admin.user',  '_sonata_name' => 'admin_sonata_user_user_edit',));
                    }

                    // admin_sonata_user_user_delete
                    if (preg_match('#^/admin/sonata/user/user/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_sonata_user_user_delete')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::deleteAction',  '_sonata_admin' => 'sonata.user.admin.user',  '_sonata_name' => 'admin_sonata_user_user_delete',));
                    }

                    // admin_sonata_user_user_show
                    if (preg_match('#^/admin/sonata/user/user/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_sonata_user_user_show')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::showAction',  '_sonata_admin' => 'sonata.user.admin.user',  '_sonata_name' => 'admin_sonata_user_user_show',));
                    }

                    // admin_sonata_user_user_export
                    if ('/admin/sonata/user/user/export' === $pathinfo) {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::exportAction',  '_sonata_admin' => 'sonata.user.admin.user',  '_sonata_name' => 'admin_sonata_user_user_export',  '_route' => 'admin_sonata_user_user_export',);
                    }

                }

                if (0 === strpos($pathinfo, '/admin/sonata/user/group')) {
                    // admin_sonata_user_group_list
                    if ('/admin/sonata/user/group/list' === $pathinfo) {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::listAction',  '_sonata_admin' => 'sonata.user.admin.group',  '_sonata_name' => 'admin_sonata_user_group_list',  '_route' => 'admin_sonata_user_group_list',);
                    }

                    // admin_sonata_user_group_create
                    if ('/admin/sonata/user/group/create' === $pathinfo) {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::createAction',  '_sonata_admin' => 'sonata.user.admin.group',  '_sonata_name' => 'admin_sonata_user_group_create',  '_route' => 'admin_sonata_user_group_create',);
                    }

                    // admin_sonata_user_group_batch
                    if ('/admin/sonata/user/group/batch' === $pathinfo) {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::batchAction',  '_sonata_admin' => 'sonata.user.admin.group',  '_sonata_name' => 'admin_sonata_user_group_batch',  '_route' => 'admin_sonata_user_group_batch',);
                    }

                    // admin_sonata_user_group_edit
                    if (preg_match('#^/admin/sonata/user/group/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_sonata_user_group_edit')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::editAction',  '_sonata_admin' => 'sonata.user.admin.group',  '_sonata_name' => 'admin_sonata_user_group_edit',));
                    }

                    // admin_sonata_user_group_delete
                    if (preg_match('#^/admin/sonata/user/group/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_sonata_user_group_delete')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::deleteAction',  '_sonata_admin' => 'sonata.user.admin.group',  '_sonata_name' => 'admin_sonata_user_group_delete',));
                    }

                    // admin_sonata_user_group_show
                    if (preg_match('#^/admin/sonata/user/group/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_sonata_user_group_show')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::showAction',  '_sonata_admin' => 'sonata.user.admin.group',  '_sonata_name' => 'admin_sonata_user_group_show',));
                    }

                    // admin_sonata_user_group_export
                    if ('/admin/sonata/user/group/export' === $pathinfo) {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::exportAction',  '_sonata_admin' => 'sonata.user.admin.group',  '_sonata_name' => 'admin_sonata_user_group_export',  '_route' => 'admin_sonata_user_group_export',);
                    }

                }

            }

        }

        if (0 === strpos($pathinfo, '/log')) {
            if (0 === strpos($pathinfo, '/login')) {
                // fos_user_security_login
                if ('/login' === $pathinfo) {
                    return array (  '_controller' => 'Sonata\\UserBundle\\Controller\\SecurityFOSUser1Controller::loginAction',  '_route' => 'fos_user_security_login',);
                }

                // fos_user_security_check
                if ('/login_check' === $pathinfo) {
                    if ($this->context->getMethod() != 'POST') {
                        $allow[] = 'POST';
                        goto not_fos_user_security_check;
                    }

                    return array (  '_controller' => 'Sonata\\UserBundle\\Controller\\SecurityFOSUser1Controller::checkAction',  '_route' => 'fos_user_security_check',);
                }
                not_fos_user_security_check:

            }

            // fos_user_security_logout
            if ('/logout' === $pathinfo) {
                return array (  '_controller' => 'Sonata\\UserBundle\\Controller\\SecurityFOSUser1Controller::logoutAction',  '_route' => 'fos_user_security_logout',);
            }

            if (0 === strpos($pathinfo, '/login')) {
                // sonata_user_security_login
                if ('/login' === $pathinfo) {
                    return array (  '_controller' => 'Sonata\\UserBundle\\Controller\\SecurityFOSUser1Controller::loginAction',  '_route' => 'sonata_user_security_login',);
                }

                // sonata_user_security_check
                if ('/login_check' === $pathinfo) {
                    if ($this->context->getMethod() != 'POST') {
                        $allow[] = 'POST';
                        goto not_sonata_user_security_check;
                    }

                    return array (  '_controller' => 'Sonata\\UserBundle\\Controller\\SecurityFOSUser1Controller::checkAction',  '_route' => 'sonata_user_security_check',);
                }
                not_sonata_user_security_check:

            }

            // sonata_user_security_logout
            if ('/logout' === $pathinfo) {
                return array (  '_controller' => 'Sonata\\UserBundle\\Controller\\SecurityFOSUser1Controller::logoutAction',  '_route' => 'sonata_user_security_logout',);
            }

        }

        if (0 === strpos($pathinfo, '/resetting')) {
            // fos_user_resetting_request
            if ('/resetting/request' === $pathinfo) {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_fos_user_resetting_request;
                }

                return array (  '_controller' => 'Sonata\\UserBundle\\Controller\\ResettingFOSUser1Controller::requestAction',  '_route' => 'fos_user_resetting_request',);
            }
            not_fos_user_resetting_request:

            // fos_user_resetting_send_email
            if ('/resetting/send-email' === $pathinfo) {
                if ($this->context->getMethod() != 'POST') {
                    $allow[] = 'POST';
                    goto not_fos_user_resetting_send_email;
                }

                return array (  '_controller' => 'Sonata\\UserBundle\\Controller\\ResettingFOSUser1Controller::sendEmailAction',  '_route' => 'fos_user_resetting_send_email',);
            }
            not_fos_user_resetting_send_email:

            // fos_user_resetting_check_email
            if ('/resetting/check-email' === $pathinfo) {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_fos_user_resetting_check_email;
                }

                return array (  '_controller' => 'Sonata\\UserBundle\\Controller\\ResettingFOSUser1Controller::checkEmailAction',  '_route' => 'fos_user_resetting_check_email',);
            }
            not_fos_user_resetting_check_email:

            if (0 === strpos($pathinfo, '/resetting/re')) {
                // fos_user_resetting_reset
                if (0 === strpos($pathinfo, '/resetting/reset') && preg_match('#^/resetting/reset/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_fos_user_resetting_reset;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'fos_user_resetting_reset')), array (  '_controller' => 'Sonata\\UserBundle\\Controller\\ResettingFOSUser1Controller::resetAction',));
                }
                not_fos_user_resetting_reset:

                // sonata_user_resetting_request
                if ('/resetting/request' === $pathinfo) {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_sonata_user_resetting_request;
                    }

                    return array (  '_controller' => 'Sonata\\UserBundle\\Controller\\ResettingFOSUser1Controller::requestAction',  '_route' => 'sonata_user_resetting_request',);
                }
                not_sonata_user_resetting_request:

            }

            // sonata_user_resetting_send_email
            if ('/resetting/send-email' === $pathinfo) {
                if ($this->context->getMethod() != 'POST') {
                    $allow[] = 'POST';
                    goto not_sonata_user_resetting_send_email;
                }

                return array (  '_controller' => 'Sonata\\UserBundle\\Controller\\ResettingFOSUser1Controller::sendEmailAction',  '_route' => 'sonata_user_resetting_send_email',);
            }
            not_sonata_user_resetting_send_email:

            // sonata_user_resetting_check_email
            if ('/resetting/check-email' === $pathinfo) {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_sonata_user_resetting_check_email;
                }

                return array (  '_controller' => 'Sonata\\UserBundle\\Controller\\ResettingFOSUser1Controller::checkEmailAction',  '_route' => 'sonata_user_resetting_check_email',);
            }
            not_sonata_user_resetting_check_email:

            // sonata_user_resetting_reset
            if (0 === strpos($pathinfo, '/resetting/reset') && preg_match('#^/resetting/reset/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                    goto not_sonata_user_resetting_reset;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'sonata_user_resetting_reset')), array (  '_controller' => 'Sonata\\UserBundle\\Controller\\ResettingFOSUser1Controller::resetAction',));
            }
            not_sonata_user_resetting_reset:

        }

        if (0 === strpos($pathinfo, '/profile')) {
            // fos_user_profile_show
            if ('/profile' === rtrim($pathinfo, '/')) {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_fos_user_profile_show;
                }

                if (substr($pathinfo, -1) !== '/') {
                    return $this->redirect($rawPathinfo.'/', 'fos_user_profile_show');
                }

                return array (  '_controller' => 'Sonata\\UserBundle\\Controller\\ProfileFOSUser1Controller::showAction',  '_route' => 'fos_user_profile_show',);
            }
            not_fos_user_profile_show:

            if (0 === strpos($pathinfo, '/profile/edit-')) {
                // fos_user_profile_edit_authentication
                if ('/profile/edit-authentication' === $pathinfo) {
                    return array (  '_controller' => 'Sonata\\UserBundle\\Controller\\ProfileFOSUser1Controller::editAuthenticationAction',  '_route' => 'fos_user_profile_edit_authentication',);
                }

                // fos_user_profile_edit
                if ('/profile/edit-profile' === $pathinfo) {
                    return array (  '_controller' => 'Sonata\\UserBundle\\Controller\\ProfileFOSUser1Controller::editProfileAction',  '_route' => 'fos_user_profile_edit',);
                }

            }

            // sonata_user_profile_show
            if ('/profile' === rtrim($pathinfo, '/')) {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_sonata_user_profile_show;
                }

                if (substr($pathinfo, -1) !== '/') {
                    return $this->redirect($rawPathinfo.'/', 'sonata_user_profile_show');
                }

                return array (  '_controller' => 'Sonata\\UserBundle\\Controller\\ProfileFOSUser1Controller::showAction',  '_route' => 'sonata_user_profile_show',);
            }
            not_sonata_user_profile_show:

            if (0 === strpos($pathinfo, '/profile/edit-')) {
                // sonata_user_profile_edit_authentication
                if ('/profile/edit-authentication' === $pathinfo) {
                    return array (  '_controller' => 'Sonata\\UserBundle\\Controller\\ProfileFOSUser1Controller::editAuthenticationAction',  '_route' => 'sonata_user_profile_edit_authentication',);
                }

                // sonata_user_profile_edit
                if ('/profile/edit-profile' === $pathinfo) {
                    return array (  '_controller' => 'Sonata\\UserBundle\\Controller\\ProfileFOSUser1Controller::editProfileAction',  '_route' => 'sonata_user_profile_edit',);
                }

            }

        }

        if (0 === strpos($pathinfo, '/register')) {
            // fos_user_registration_register
            if ('/register' === rtrim($pathinfo, '/')) {
                if (substr($pathinfo, -1) !== '/') {
                    return $this->redirect($rawPathinfo.'/', 'fos_user_registration_register');
                }

                return array (  '_controller' => 'Sonata\\UserBundle\\Controller\\RegistrationFOSUser1Controller::registerAction',  '_route' => 'fos_user_registration_register',);
            }

            if (0 === strpos($pathinfo, '/register/c')) {
                // fos_user_registration_check_email
                if ('/register/check-email' === $pathinfo) {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_fos_user_registration_check_email;
                    }

                    return array (  '_controller' => 'Sonata\\UserBundle\\Controller\\RegistrationFOSUser1Controller::checkEmailAction',  '_route' => 'fos_user_registration_check_email',);
                }
                not_fos_user_registration_check_email:

                if (0 === strpos($pathinfo, '/register/confirm')) {
                    // fos_user_registration_confirm
                    if (preg_match('#^/register/confirm/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                        if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                            $allow = array_merge($allow, array('GET', 'HEAD'));
                            goto not_fos_user_registration_confirm;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'fos_user_registration_confirm')), array (  '_controller' => 'Sonata\\UserBundle\\Controller\\RegistrationFOSUser1Controller::confirmAction',));
                    }
                    not_fos_user_registration_confirm:

                    // fos_user_registration_confirmed
                    if ('/register/confirmed' === $pathinfo) {
                        if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                            $allow = array_merge($allow, array('GET', 'HEAD'));
                            goto not_fos_user_registration_confirmed;
                        }

                        return array (  '_controller' => 'Sonata\\UserBundle\\Controller\\RegistrationFOSUser1Controller::confirmedAction',  '_route' => 'fos_user_registration_confirmed',);
                    }
                    not_fos_user_registration_confirmed:

                }

            }

            // sonata_user_registration_register
            if ('/register' === rtrim($pathinfo, '/')) {
                if (substr($pathinfo, -1) !== '/') {
                    return $this->redirect($rawPathinfo.'/', 'sonata_user_registration_register');
                }

                return array (  '_controller' => 'Sonata\\UserBundle\\Controller\\RegistrationFOSUser1Controller::registerAction',  '_route' => 'sonata_user_registration_register',);
            }

            if (0 === strpos($pathinfo, '/register/c')) {
                // sonata_user_registration_check_email
                if ('/register/check-email' === $pathinfo) {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_sonata_user_registration_check_email;
                    }

                    return array (  '_controller' => 'Sonata\\UserBundle\\Controller\\RegistrationFOSUser1Controller::checkEmailAction',  '_route' => 'sonata_user_registration_check_email',);
                }
                not_sonata_user_registration_check_email:

                if (0 === strpos($pathinfo, '/register/confirm')) {
                    // sonata_user_registration_confirm
                    if (preg_match('#^/register/confirm/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                        if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                            $allow = array_merge($allow, array('GET', 'HEAD'));
                            goto not_sonata_user_registration_confirm;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'sonata_user_registration_confirm')), array (  '_controller' => 'Sonata\\UserBundle\\Controller\\RegistrationFOSUser1Controller::confirmAction',));
                    }
                    not_sonata_user_registration_confirm:

                    // sonata_user_registration_confirmed
                    if ('/register/confirmed' === $pathinfo) {
                        if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                            $allow = array_merge($allow, array('GET', 'HEAD'));
                            goto not_sonata_user_registration_confirmed;
                        }

                        return array (  '_controller' => 'Sonata\\UserBundle\\Controller\\RegistrationFOSUser1Controller::confirmedAction',  '_route' => 'sonata_user_registration_confirmed',);
                    }
                    not_sonata_user_registration_confirmed:

                }

            }

        }

        if (0 === strpos($pathinfo, '/profile/change-password')) {
            // fos_user_change_password
            if ('/profile/change-password' === $pathinfo) {
                if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                    goto not_fos_user_change_password;
                }

                return array (  '_controller' => 'Sonata\\UserBundle\\Controller\\ChangePasswordFOSUser1Controller::changePasswordAction',  '_route' => 'fos_user_change_password',);
            }
            not_fos_user_change_password:

            // sonata_user_change_password
            if ('/profile/change-password' === $pathinfo) {
                if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                    goto not_sonata_user_change_password;
                }

                return array (  '_controller' => 'Sonata\\UserBundle\\Controller\\ChangePasswordFOSUser1Controller::changePasswordAction',  '_route' => 'sonata_user_change_password',);
            }
            not_sonata_user_change_password:

        }

        if (0 === strpos($pathinfo, '/admin/log')) {
            if (0 === strpos($pathinfo, '/admin/login')) {
                // sonata_user_admin_security_login
                if ('/admin/login' === $pathinfo) {
                    return array (  '_controller' => 'Sonata\\UserBundle\\Controller\\AdminSecurityController::loginAction',  '_route' => 'sonata_user_admin_security_login',);
                }

                // sonata_user_admin_security_check
                if ('/admin/login_check' === $pathinfo) {
                    if ($this->context->getMethod() != 'POST') {
                        $allow[] = 'POST';
                        goto not_sonata_user_admin_security_check;
                    }

                    return array (  '_controller' => 'Sonata\\UserBundle\\Controller\\AdminSecurityController::checkAction',  '_route' => 'sonata_user_admin_security_check',);
                }
                not_sonata_user_admin_security_check:

            }

            // sonata_user_admin_security_logout
            if ('/admin/logout' === $pathinfo) {
                return array (  '_controller' => 'Sonata\\UserBundle\\Controller\\AdminSecurityController::logoutAction',  '_route' => 'sonata_user_admin_security_logout',);
            }

        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}

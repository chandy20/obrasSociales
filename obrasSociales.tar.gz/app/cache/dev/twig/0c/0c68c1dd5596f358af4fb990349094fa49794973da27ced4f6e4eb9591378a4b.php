<?php

/* SonataAdminBundle:Pager:links.html.twig */
class __TwigTemplate_7697657cf7f31139bfbdbc147e4574decbdee00b6440971a3ecf1a4bd21d5e9a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 12
        $this->parent = $this->loadTemplate("@SonataAdmin/Pager/base_links.html.twig", "SonataAdminBundle:Pager:links.html.twig", 12);
        $this->blocks = array(
        );
    }

    protected function doGetParent(array $context)
    {
        return "@SonataAdmin/Pager/base_links.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_347c9b0a2b042a2a3e61630ed655dc3d714f5c6e3a14799fd3560aaac0008303 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_347c9b0a2b042a2a3e61630ed655dc3d714f5c6e3a14799fd3560aaac0008303->enter($__internal_347c9b0a2b042a2a3e61630ed655dc3d714f5c6e3a14799fd3560aaac0008303_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataAdminBundle:Pager:links.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_347c9b0a2b042a2a3e61630ed655dc3d714f5c6e3a14799fd3560aaac0008303->leave($__internal_347c9b0a2b042a2a3e61630ed655dc3d714f5c6e3a14799fd3560aaac0008303_prof);

    }

    public function getTemplateName()
    {
        return "SonataAdminBundle:Pager:links.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  11 => 12,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#

This file is part of the Sonata package.

(c) Thomas Rabaix <thomas.rabaix@sonata-project.org>

For the full copyright and license information, please view the LICENSE
file that was distributed with this source code.

#}

{% extends '@SonataAdmin/Pager/base_links.html.twig' %}
", "SonataAdminBundle:Pager:links.html.twig", "/home/ch/proyectos/php/obrasSociales/vendor/sonata-project/admin-bundle/src/Resources/views/Pager/links.html.twig");
    }
}

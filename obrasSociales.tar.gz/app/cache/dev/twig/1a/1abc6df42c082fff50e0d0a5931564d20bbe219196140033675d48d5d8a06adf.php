<?php

/* SonataAdminBundle::standard_layout.html.twig */
class __TwigTemplate_2eea3d9966d98b69b3e775199843a7b287e07b5769ee3af6917707f2adc07b9d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'html_attributes' => array($this, 'block_html_attributes'),
            'meta_tags' => array($this, 'block_meta_tags'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
            'sonata_javascript_config' => array($this, 'block_sonata_javascript_config'),
            'sonata_javascript_pool' => array($this, 'block_sonata_javascript_pool'),
            'sonata_head_title' => array($this, 'block_sonata_head_title'),
            'body_attributes' => array($this, 'block_body_attributes'),
            'sonata_header' => array($this, 'block_sonata_header'),
            'sonata_header_noscript_warning' => array($this, 'block_sonata_header_noscript_warning'),
            'logo' => array($this, 'block_logo'),
            'sonata_nav' => array($this, 'block_sonata_nav'),
            'sonata_breadcrumb' => array($this, 'block_sonata_breadcrumb'),
            'sonata_top_nav_menu' => array($this, 'block_sonata_top_nav_menu'),
            'sonata_top_nav_menu_add_block' => array($this, 'block_sonata_top_nav_menu_add_block'),
            'sonata_top_nav_menu_user_block' => array($this, 'block_sonata_top_nav_menu_user_block'),
            'sonata_wrapper' => array($this, 'block_sonata_wrapper'),
            'sonata_left_side' => array($this, 'block_sonata_left_side'),
            'sonata_side_nav' => array($this, 'block_sonata_side_nav'),
            'sonata_sidebar_search' => array($this, 'block_sonata_sidebar_search'),
            'side_bar_before_nav' => array($this, 'block_side_bar_before_nav'),
            'side_bar_nav' => array($this, 'block_side_bar_nav'),
            'side_bar_after_nav' => array($this, 'block_side_bar_after_nav'),
            'side_bar_after_nav_content' => array($this, 'block_side_bar_after_nav_content'),
            'sonata_page_content' => array($this, 'block_sonata_page_content'),
            'sonata_page_content_header' => array($this, 'block_sonata_page_content_header'),
            'sonata_page_content_nav' => array($this, 'block_sonata_page_content_nav'),
            'tab_menu_navbar_header' => array($this, 'block_tab_menu_navbar_header'),
            'sonata_admin_content_actions_wrappers' => array($this, 'block_sonata_admin_content_actions_wrappers'),
            'sonata_admin_content' => array($this, 'block_sonata_admin_content'),
            'notice' => array($this, 'block_notice'),
            'bootlint' => array($this, 'block_bootlint'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_04b556ac30e8f5934fe94fecfa61a6eed0d0a8ec66692fab61b2baf041111d0f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_04b556ac30e8f5934fe94fecfa61a6eed0d0a8ec66692fab61b2baf041111d0f->enter($__internal_04b556ac30e8f5934fe94fecfa61a6eed0d0a8ec66692fab61b2baf041111d0f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataAdminBundle::standard_layout.html.twig"));

        // line 12
        $context["_preview"] = ((        $this->hasBlock("preview", $context, $blocks)) ? (twig_trim_filter(        $this->renderBlock("preview", $context, $blocks))) : (null));
        // line 13
        $context["_form"] = ((        $this->hasBlock("form", $context, $blocks)) ? (twig_trim_filter(        $this->renderBlock("form", $context, $blocks))) : (null));
        // line 14
        $context["_show"] = ((        $this->hasBlock("show", $context, $blocks)) ? (twig_trim_filter(        $this->renderBlock("show", $context, $blocks))) : (null));
        // line 15
        $context["_list_table"] = ((        $this->hasBlock("list_table", $context, $blocks)) ? (twig_trim_filter(        $this->renderBlock("list_table", $context, $blocks))) : (null));
        // line 16
        $context["_list_filters"] = ((        $this->hasBlock("list_filters", $context, $blocks)) ? (twig_trim_filter(        $this->renderBlock("list_filters", $context, $blocks))) : (null));
        // line 17
        $context["_tab_menu"] = ((        $this->hasBlock("tab_menu", $context, $blocks)) ? (twig_trim_filter(        $this->renderBlock("tab_menu", $context, $blocks))) : (null));
        // line 18
        $context["_content"] = ((        $this->hasBlock("content", $context, $blocks)) ? (twig_trim_filter(        $this->renderBlock("content", $context, $blocks))) : (null));
        // line 19
        $context["_title"] = ((        $this->hasBlock("title", $context, $blocks)) ? (twig_trim_filter(        $this->renderBlock("title", $context, $blocks))) : (null));
        // line 20
        $context["_breadcrumb"] = ((        $this->hasBlock("breadcrumb", $context, $blocks)) ? (twig_trim_filter(        $this->renderBlock("breadcrumb", $context, $blocks))) : (null));
        // line 21
        $context["_actions"] = ((        $this->hasBlock("actions", $context, $blocks)) ? (twig_trim_filter(        $this->renderBlock("actions", $context, $blocks))) : (null));
        // line 22
        $context["_navbar_title"] = ((        $this->hasBlock("navbar_title", $context, $blocks)) ? (twig_trim_filter(        $this->renderBlock("navbar_title", $context, $blocks))) : (null));
        // line 23
        $context["_list_filters_actions"] = ((        $this->hasBlock("list_filters_actions", $context, $blocks)) ? (twig_trim_filter(        $this->renderBlock("list_filters_actions", $context, $blocks))) : (null));
        // line 25
        echo "<!DOCTYPE html>
<html ";
        // line 26
        $this->displayBlock('html_attributes', $context, $blocks);
        echo ">
    <head>
        ";
        // line 28
        $this->displayBlock('meta_tags', $context, $blocks);
        // line 33
        echo "
        ";
        // line 34
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 39
        echo "
        ";
        // line 40
        $this->displayBlock('javascripts', $context, $blocks);
        // line 86
        echo "
        <title>
        ";
        // line 88
        $this->displayBlock('sonata_head_title', $context, $blocks);
        // line 114
        echo "        </title>
    </head>
    <body
            ";
        // line 117
        $this->displayBlock('body_attributes', $context, $blocks);
        // line 123
        echo ">

    <div class=\"wrapper\">

        ";
        // line 127
        $this->displayBlock('sonata_header', $context, $blocks);
        // line 226
        echo "
        ";
        // line 227
        $this->displayBlock('sonata_wrapper', $context, $blocks);
        // line 364
        echo "    </div>

    ";
        // line 366
        if ($this->getAttribute($this->getAttribute(($context["sonata_admin"] ?? $this->getContext($context, "sonata_admin")), "adminPool", array()), "getOption", array(0 => "use_bootlint"), "method")) {
            // line 367
            echo "        ";
            $this->displayBlock('bootlint', $context, $blocks);
            // line 373
            echo "    ";
        }
        // line 374
        echo "
    </body>
</html>
";
        
        $__internal_04b556ac30e8f5934fe94fecfa61a6eed0d0a8ec66692fab61b2baf041111d0f->leave($__internal_04b556ac30e8f5934fe94fecfa61a6eed0d0a8ec66692fab61b2baf041111d0f_prof);

    }

    // line 26
    public function block_html_attributes($context, array $blocks = array())
    {
        $__internal_e532144308b997f46501f663a6e936f03328115b059e44ee6857f71e86410dce = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e532144308b997f46501f663a6e936f03328115b059e44ee6857f71e86410dce->enter($__internal_e532144308b997f46501f663a6e936f03328115b059e44ee6857f71e86410dce_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "html_attributes"));

        echo "class=\"no-js\"";
        
        $__internal_e532144308b997f46501f663a6e936f03328115b059e44ee6857f71e86410dce->leave($__internal_e532144308b997f46501f663a6e936f03328115b059e44ee6857f71e86410dce_prof);

    }

    // line 28
    public function block_meta_tags($context, array $blocks = array())
    {
        $__internal_1f05145d3b859749b8272e9458f5ab8cb9c26999eb7e5839f6a132a5da88b12c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1f05145d3b859749b8272e9458f5ab8cb9c26999eb7e5839f6a132a5da88b12c->enter($__internal_1f05145d3b859749b8272e9458f5ab8cb9c26999eb7e5839f6a132a5da88b12c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "meta_tags"));

        // line 29
        echo "            <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
            <meta charset=\"UTF-8\">
            <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
        ";
        
        $__internal_1f05145d3b859749b8272e9458f5ab8cb9c26999eb7e5839f6a132a5da88b12c->leave($__internal_1f05145d3b859749b8272e9458f5ab8cb9c26999eb7e5839f6a132a5da88b12c_prof);

    }

    // line 34
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_ff9add73341bc90dc6b0bcb27d42558282426a4c4e01aaf1fd0e8d58a1f1dbe0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ff9add73341bc90dc6b0bcb27d42558282426a4c4e01aaf1fd0e8d58a1f1dbe0->enter($__internal_ff9add73341bc90dc6b0bcb27d42558282426a4c4e01aaf1fd0e8d58a1f1dbe0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 35
        echo "            ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute(($context["sonata_admin"] ?? $this->getContext($context, "sonata_admin")), "adminPool", array()), "getOption", array(0 => "stylesheets", 1 => array()), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["stylesheet"]) {
            // line 36
            echo "                <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl($context["stylesheet"]), "html", null, true);
            echo "\">
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['stylesheet'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 38
        echo "        ";
        
        $__internal_ff9add73341bc90dc6b0bcb27d42558282426a4c4e01aaf1fd0e8d58a1f1dbe0->leave($__internal_ff9add73341bc90dc6b0bcb27d42558282426a4c4e01aaf1fd0e8d58a1f1dbe0_prof);

    }

    // line 40
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_14d55e7878d027fe36063f61aa8ddd32bd1462091905cfc0df676d65c450825d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_14d55e7878d027fe36063f61aa8ddd32bd1462091905cfc0df676d65c450825d->enter($__internal_14d55e7878d027fe36063f61aa8ddd32bd1462091905cfc0df676d65c450825d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 41
        echo "            ";
        $this->displayBlock('sonata_javascript_config', $context, $blocks);
        // line 61
        echo "
            ";
        // line 62
        $this->displayBlock('sonata_javascript_pool', $context, $blocks);
        // line 67
        echo "
            ";
        // line 69
        echo "            ";
        $context["localeForMoment"] = $this->env->getExtension('Sonata\AdminBundle\Twig\Extension\SonataAdminExtension')->getCanonicalizedLocaleForMoment($context);
        // line 70
        echo "            ";
        if (($context["localeForMoment"] ?? $this->getContext($context, "localeForMoment"))) {
            // line 71
            echo "                <script src=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl((("bundles/sonatacore/vendor/moment/locale/" .             // line 73
($context["localeForMoment"] ?? $this->getContext($context, "localeForMoment"))) . ".js")), "html", null, true);
            // line 75
            echo "\"></script>
            ";
        }
        // line 77
        echo "
            ";
        // line 79
        echo "            ";
        if ($this->getAttribute($this->getAttribute(($context["sonata_admin"] ?? $this->getContext($context, "sonata_admin")), "adminPool", array()), "getOption", array(0 => "use_select2"), "method")) {
            // line 80
            echo "                ";
            $context["localeForSelect2"] = $this->env->getExtension('Sonata\AdminBundle\Twig\Extension\SonataAdminExtension')->getCanonicalizedLocaleForSelect2($context);
            // line 81
            echo "                ";
            if (($context["localeForSelect2"] ?? $this->getContext($context, "localeForSelect2"))) {
                // line 82
                echo "                    <script src=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl((("bundles/sonatacore/vendor/select2/select2_locale_" . ($context["localeForSelect2"] ?? $this->getContext($context, "localeForSelect2"))) . ".js")), "html", null, true);
                echo "\"></script>
                ";
            }
            // line 84
            echo "            ";
        }
        // line 85
        echo "        ";
        
        $__internal_14d55e7878d027fe36063f61aa8ddd32bd1462091905cfc0df676d65c450825d->leave($__internal_14d55e7878d027fe36063f61aa8ddd32bd1462091905cfc0df676d65c450825d_prof);

    }

    // line 41
    public function block_sonata_javascript_config($context, array $blocks = array())
    {
        $__internal_49fb242c2b5094939c79c81b37d37a0edf369d8d61e81dc059d64377204008cb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_49fb242c2b5094939c79c81b37d37a0edf369d8d61e81dc059d64377204008cb->enter($__internal_49fb242c2b5094939c79c81b37d37a0edf369d8d61e81dc059d64377204008cb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_javascript_config"));

        // line 42
        echo "                <script>
                    window.SONATA_CONFIG = {
                        CONFIRM_EXIT: ";
        // line 44
        if ($this->getAttribute($this->getAttribute(($context["sonata_admin"] ?? $this->getContext($context, "sonata_admin")), "adminPool", array()), "getOption", array(0 => "confirm_exit"), "method")) {
            echo "true";
        } else {
            echo "false";
        }
        echo ",
                        USE_SELECT2: ";
        // line 45
        if ($this->getAttribute($this->getAttribute(($context["sonata_admin"] ?? $this->getContext($context, "sonata_admin")), "adminPool", array()), "getOption", array(0 => "use_select2"), "method")) {
            echo "true";
        } else {
            echo "false";
        }
        echo ",
                        USE_ICHECK: ";
        // line 46
        if ($this->getAttribute($this->getAttribute(($context["sonata_admin"] ?? $this->getContext($context, "sonata_admin")), "adminPool", array()), "getOption", array(0 => "use_icheck"), "method")) {
            echo "true";
        } else {
            echo "false";
        }
        echo ",
                        USE_STICKYFORMS: ";
        // line 47
        if ($this->getAttribute($this->getAttribute(($context["sonata_admin"] ?? $this->getContext($context, "sonata_admin")), "adminPool", array()), "getOption", array(0 => "use_stickyforms"), "method")) {
            echo "true";
        } else {
            echo "false";
        }
        // line 48
        echo "                    };
                    window.SONATA_TRANSLATIONS = {
                        CONFIRM_EXIT: '";
        // line 50
        echo twig_escape_filter($this->env, twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("confirm_exit", array(), "SonataAdminBundle"), "js"), "html", null, true);
        echo "'
                    };

                    // http://getbootstrap.com/getting-started/#support-ie10-width
                    if (navigator.userAgent.match(/IEMobile\\/10\\.0/)) {
                        var msViewportStyle = document.createElement('style');
                        msViewportStyle.appendChild(document.createTextNode('@-ms-viewport{width:auto!important}'));
                        document.querySelector('head').appendChild(msViewportStyle);
                    }
                </script>
            ";
        
        $__internal_49fb242c2b5094939c79c81b37d37a0edf369d8d61e81dc059d64377204008cb->leave($__internal_49fb242c2b5094939c79c81b37d37a0edf369d8d61e81dc059d64377204008cb_prof);

    }

    // line 62
    public function block_sonata_javascript_pool($context, array $blocks = array())
    {
        $__internal_914a57df257072a3104e0a2e7fe46d9e239ea8e5a3357c6f054ec438338b9a6a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_914a57df257072a3104e0a2e7fe46d9e239ea8e5a3357c6f054ec438338b9a6a->enter($__internal_914a57df257072a3104e0a2e7fe46d9e239ea8e5a3357c6f054ec438338b9a6a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_javascript_pool"));

        // line 63
        echo "                ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute(($context["sonata_admin"] ?? $this->getContext($context, "sonata_admin")), "adminPool", array()), "getOption", array(0 => "javascripts", 1 => array()), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["javascript"]) {
            // line 64
            echo "                    <script src=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl($context["javascript"]), "html", null, true);
            echo "\"></script>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['javascript'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 66
        echo "            ";
        
        $__internal_914a57df257072a3104e0a2e7fe46d9e239ea8e5a3357c6f054ec438338b9a6a->leave($__internal_914a57df257072a3104e0a2e7fe46d9e239ea8e5a3357c6f054ec438338b9a6a_prof);

    }

    // line 88
    public function block_sonata_head_title($context, array $blocks = array())
    {
        $__internal_47c5d6873147329b1d8213c9e200b4f296b04976724b0a51fbf42fe1229f8d67 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_47c5d6873147329b1d8213c9e200b4f296b04976724b0a51fbf42fe1229f8d67->enter($__internal_47c5d6873147329b1d8213c9e200b4f296b04976724b0a51fbf42fe1229f8d67_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_head_title"));

        // line 89
        echo "            ";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Admin", array(), "SonataAdminBundle"), "html", null, true);
        echo "

            ";
        // line 91
        if ( !twig_test_empty(($context["_title"] ?? $this->getContext($context, "_title")))) {
            // line 92
            echo "                ";
            echo strip_tags(($context["_title"] ?? $this->getContext($context, "_title")));
            echo "
            ";
        } else {
            // line 94
            echo "                ";
            if (array_key_exists("action", $context)) {
                // line 95
                echo "                    -
                    ";
                // line 96
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["breadcrumbs_builder"] ?? $this->getContext($context, "breadcrumbs_builder")), "breadcrumbs", array(0 => ($context["admin"] ?? $this->getContext($context, "admin")), 1 => ($context["action"] ?? $this->getContext($context, "action"))), "method"));
                $context['loop'] = array(
                  'parent' => $context['_parent'],
                  'index0' => 0,
                  'index'  => 1,
                  'first'  => true,
                );
                if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                    $length = count($context['_seq']);
                    $context['loop']['revindex0'] = $length - 1;
                    $context['loop']['revindex'] = $length;
                    $context['loop']['length'] = $length;
                    $context['loop']['last'] = 1 === $length;
                }
                foreach ($context['_seq'] as $context["_key"] => $context["menu"]) {
                    // line 97
                    echo "                        ";
                    if ( !$this->getAttribute($context["loop"], "first", array())) {
                        // line 98
                        echo "                            ";
                        if (($this->getAttribute($context["loop"], "index", array()) != 2)) {
                            // line 99
                            echo "                                &gt;
                            ";
                        }
                        // line 102
                        $context["translation_domain"] = $this->getAttribute($context["menu"], "extra", array(0 => "translation_domain", 1 => "messages"), "method");
                        // line 103
                        $context["label"] = $this->getAttribute($context["menu"], "label", array());
                        // line 104
                        if ( !(($context["translation_domain"] ?? $this->getContext($context, "translation_domain")) === false)) {
                            // line 105
                            $context["label"] = $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans(($context["label"] ?? $this->getContext($context, "label")), $this->getAttribute($context["menu"], "extra", array(0 => "translation_params", 1 => array()), "method"), ($context["translation_domain"] ?? $this->getContext($context, "translation_domain")));
                        }
                        // line 108
                        echo twig_escape_filter($this->env, ($context["label"] ?? $this->getContext($context, "label")), "html", null, true);
                        echo "
                        ";
                    }
                    // line 110
                    echo "                    ";
                    ++$context['loop']['index0'];
                    ++$context['loop']['index'];
                    $context['loop']['first'] = false;
                    if (isset($context['loop']['length'])) {
                        --$context['loop']['revindex0'];
                        --$context['loop']['revindex'];
                        $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                    }
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['menu'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 111
                echo "                ";
            }
            // line 112
            echo "            ";
        }
        // line 113
        echo "        ";
        
        $__internal_47c5d6873147329b1d8213c9e200b4f296b04976724b0a51fbf42fe1229f8d67->leave($__internal_47c5d6873147329b1d8213c9e200b4f296b04976724b0a51fbf42fe1229f8d67_prof);

    }

    // line 117
    public function block_body_attributes($context, array $blocks = array())
    {
        $__internal_f6baef5fbcacb8cec309535f158a65df8b2b718919712a184b2bf74e4a1206f6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f6baef5fbcacb8cec309535f158a65df8b2b718919712a184b2bf74e4a1206f6->enter($__internal_f6baef5fbcacb8cec309535f158a65df8b2b718919712a184b2bf74e4a1206f6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_attributes"));

        // line 118
        echo "class=\"sonata-bc skin-black fixed
                ";
        // line 119
        if ($this->getAttribute($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "cookies", array()), "get", array(0 => "sonata_sidebar_hide"), "method")) {
            // line 120
            echo "sidebar-collapse";
        }
        // line 121
        echo "\"";
        
        $__internal_f6baef5fbcacb8cec309535f158a65df8b2b718919712a184b2bf74e4a1206f6->leave($__internal_f6baef5fbcacb8cec309535f158a65df8b2b718919712a184b2bf74e4a1206f6_prof);

    }

    // line 127
    public function block_sonata_header($context, array $blocks = array())
    {
        $__internal_e311738e80aed83b68f5f9cae11442367b3d4b8a558a6a75cf42f9eda39cdbae = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e311738e80aed83b68f5f9cae11442367b3d4b8a558a6a75cf42f9eda39cdbae->enter($__internal_e311738e80aed83b68f5f9cae11442367b3d4b8a558a6a75cf42f9eda39cdbae_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_header"));

        // line 128
        echo "            <header class=\"main-header\">
                ";
        // line 129
        $this->displayBlock('sonata_header_noscript_warning', $context, $blocks);
        // line 136
        echo "                ";
        $this->displayBlock('logo', $context, $blocks);
        // line 148
        echo "                ";
        $this->displayBlock('sonata_nav', $context, $blocks);
        // line 224
        echo "            </header>
        ";
        
        $__internal_e311738e80aed83b68f5f9cae11442367b3d4b8a558a6a75cf42f9eda39cdbae->leave($__internal_e311738e80aed83b68f5f9cae11442367b3d4b8a558a6a75cf42f9eda39cdbae_prof);

    }

    // line 129
    public function block_sonata_header_noscript_warning($context, array $blocks = array())
    {
        $__internal_f09e6ff02d05881ae6b9d918f21fcd03ffd19d1c157e3ea4ceeb95c149255df7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f09e6ff02d05881ae6b9d918f21fcd03ffd19d1c157e3ea4ceeb95c149255df7->enter($__internal_f09e6ff02d05881ae6b9d918f21fcd03ffd19d1c157e3ea4ceeb95c149255df7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_header_noscript_warning"));

        // line 130
        echo "                    <noscript>
                        <div class=\"noscript-warning\">
                            ";
        // line 132
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("noscript_warning", array(), "SonataAdminBundle"), "html", null, true);
        echo "
                        </div>
                    </noscript>
                ";
        
        $__internal_f09e6ff02d05881ae6b9d918f21fcd03ffd19d1c157e3ea4ceeb95c149255df7->leave($__internal_f09e6ff02d05881ae6b9d918f21fcd03ffd19d1c157e3ea4ceeb95c149255df7_prof);

    }

    // line 136
    public function block_logo($context, array $blocks = array())
    {
        $__internal_2c233a87eba62d5c3501655fd00aba43aee20a147b3a796f6ed741640ccb7692 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2c233a87eba62d5c3501655fd00aba43aee20a147b3a796f6ed741640ccb7692->enter($__internal_2c233a87eba62d5c3501655fd00aba43aee20a147b3a796f6ed741640ccb7692_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "logo"));

        // line 137
        echo "                    ";
        ob_start();
        // line 138
        echo "                        <a class=\"logo\" href=\"";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("sonata_admin_dashboard");
        echo "\">
                            ";
        // line 139
        if ((("single_image" == $this->getAttribute($this->getAttribute(($context["sonata_admin"] ?? $this->getContext($context, "sonata_admin")), "adminPool", array()), "getOption", array(0 => "title_mode"), "method")) || ("both" == $this->getAttribute($this->getAttribute(($context["sonata_admin"] ?? $this->getContext($context, "sonata_admin")), "adminPool", array()), "getOption", array(0 => "title_mode"), "method")))) {
            // line 140
            echo "                                <img src=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl($this->getAttribute($this->getAttribute(($context["sonata_admin"] ?? $this->getContext($context, "sonata_admin")), "adminPool", array()), "titlelogo", array())), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["sonata_admin"] ?? $this->getContext($context, "sonata_admin")), "adminPool", array()), "title", array()), "html", null, true);
            echo "\">
                            ";
        }
        // line 142
        echo "                            ";
        if ((("single_text" == $this->getAttribute($this->getAttribute(($context["sonata_admin"] ?? $this->getContext($context, "sonata_admin")), "adminPool", array()), "getOption", array(0 => "title_mode"), "method")) || ("both" == $this->getAttribute($this->getAttribute(($context["sonata_admin"] ?? $this->getContext($context, "sonata_admin")), "adminPool", array()), "getOption", array(0 => "title_mode"), "method")))) {
            // line 143
            echo "                                <span>";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["sonata_admin"] ?? $this->getContext($context, "sonata_admin")), "adminPool", array()), "title", array()), "html", null, true);
            echo "</span>
                            ";
        }
        // line 145
        echo "                        </a>
                    ";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
        // line 147
        echo "                ";
        
        $__internal_2c233a87eba62d5c3501655fd00aba43aee20a147b3a796f6ed741640ccb7692->leave($__internal_2c233a87eba62d5c3501655fd00aba43aee20a147b3a796f6ed741640ccb7692_prof);

    }

    // line 148
    public function block_sonata_nav($context, array $blocks = array())
    {
        $__internal_1e6227c0f1d6e319a7f55b2f9ecaeeac7fff57e1fc15aa90ee0468d84a7ed068 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1e6227c0f1d6e319a7f55b2f9ecaeeac7fff57e1fc15aa90ee0468d84a7ed068->enter($__internal_1e6227c0f1d6e319a7f55b2f9ecaeeac7fff57e1fc15aa90ee0468d84a7ed068_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_nav"));

        // line 149
        echo "                    <nav class=\"navbar navbar-static-top\" role=\"navigation\">
                        <a href=\"#\" class=\"sidebar-toggle\" data-toggle=\"offcanvas\" role=\"button\">
                            <span class=\"sr-only\">";
        // line 151
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("toggle_navigation", array(), "SonataAdminBundle"), "html", null, true);
        echo "</span>
                        </a>

                        <div class=\"navbar-left\">
                            ";
        // line 155
        $this->displayBlock('sonata_breadcrumb', $context, $blocks);
        // line 194
        echo "                        </div>

                        ";
        // line 196
        $this->displayBlock('sonata_top_nav_menu', $context, $blocks);
        // line 222
        echo "                    </nav>
                ";
        
        $__internal_1e6227c0f1d6e319a7f55b2f9ecaeeac7fff57e1fc15aa90ee0468d84a7ed068->leave($__internal_1e6227c0f1d6e319a7f55b2f9ecaeeac7fff57e1fc15aa90ee0468d84a7ed068_prof);

    }

    // line 155
    public function block_sonata_breadcrumb($context, array $blocks = array())
    {
        $__internal_7cd6ab648c820fb2287cfdc0e67b0a9d8baae88e8f65d07858a1769e01916714 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7cd6ab648c820fb2287cfdc0e67b0a9d8baae88e8f65d07858a1769e01916714->enter($__internal_7cd6ab648c820fb2287cfdc0e67b0a9d8baae88e8f65d07858a1769e01916714_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_breadcrumb"));

        // line 156
        echo "                                <div class=\"hidden-xs\">
                                    ";
        // line 157
        if (( !twig_test_empty(($context["_breadcrumb"] ?? $this->getContext($context, "_breadcrumb"))) || array_key_exists("action", $context))) {
            // line 158
            echo "                                        <ol class=\"nav navbar-top-links breadcrumb\">
                                            ";
            // line 159
            if (twig_test_empty(($context["_breadcrumb"] ?? $this->getContext($context, "_breadcrumb")))) {
                // line 160
                echo "                                                ";
                if (array_key_exists("action", $context)) {
                    // line 161
                    echo "                                                    ";
                    $context['_parent'] = $context;
                    $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["breadcrumbs_builder"] ?? $this->getContext($context, "breadcrumbs_builder")), "breadcrumbs", array(0 => ($context["admin"] ?? $this->getContext($context, "admin")), 1 => ($context["action"] ?? $this->getContext($context, "action"))), "method"));
                    $context['loop'] = array(
                      'parent' => $context['_parent'],
                      'index0' => 0,
                      'index'  => 1,
                      'first'  => true,
                    );
                    if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                        $length = count($context['_seq']);
                        $context['loop']['revindex0'] = $length - 1;
                        $context['loop']['revindex'] = $length;
                        $context['loop']['length'] = $length;
                        $context['loop']['last'] = 1 === $length;
                    }
                    foreach ($context['_seq'] as $context["_key"] => $context["menu"]) {
                        // line 162
                        $context["translation_domain"] = $this->getAttribute($context["menu"], "extra", array(0 => "translation_domain", 1 => "messages"), "method");
                        // line 163
                        $context["label"] = $this->getAttribute($context["menu"], "label", array());
                        // line 164
                        if ( !(($context["translation_domain"] ?? $this->getContext($context, "translation_domain")) === false)) {
                            // line 165
                            $context["label"] = $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans(($context["label"] ?? $this->getContext($context, "label")), $this->getAttribute($context["menu"], "extra", array(0 => "translation_params", 1 => array()), "method"), ($context["translation_domain"] ?? $this->getContext($context, "translation_domain")));
                        }
                        // line 168
                        if ( !$this->getAttribute($context["loop"], "last", array())) {
                            // line 169
                            echo "                                                            <li>
                                                                ";
                            // line 170
                            if ( !twig_test_empty($this->getAttribute($context["menu"], "uri", array()))) {
                                // line 171
                                echo "                                                                    <a href=\"";
                                echo twig_escape_filter($this->env, $this->getAttribute($context["menu"], "uri", array()), "html", null, true);
                                echo "\">
                                                                        ";
                                // line 172
                                if ($this->getAttribute($context["menu"], "extra", array(0 => "safe_label", 1 => true), "method")) {
                                    // line 173
                                    echo ($context["label"] ?? $this->getContext($context, "label"));
                                } else {
                                    // line 175
                                    echo twig_escape_filter($this->env, ($context["label"] ?? $this->getContext($context, "label")), "html", null, true);
                                }
                                // line 177
                                echo "                                                                    </a>
                                                                ";
                            } else {
                                // line 179
                                echo "                                                                    <span>";
                                echo twig_escape_filter($this->env, ($context["label"] ?? $this->getContext($context, "label")), "html", null, true);
                                echo "</span>
                                                                ";
                            }
                            // line 181
                            echo "                                                            </li>
                                                        ";
                        } else {
                            // line 183
                            echo "                                                            <li class=\"active\"><span>";
                            echo twig_escape_filter($this->env, ($context["label"] ?? $this->getContext($context, "label")), "html", null, true);
                            echo "</span></li>
                                                        ";
                        }
                        // line 185
                        echo "                                                    ";
                        ++$context['loop']['index0'];
                        ++$context['loop']['index'];
                        $context['loop']['first'] = false;
                        if (isset($context['loop']['length'])) {
                            --$context['loop']['revindex0'];
                            --$context['loop']['revindex'];
                            $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                        }
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['_key'], $context['menu'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                    // line 186
                    echo "                                                ";
                }
                // line 187
                echo "                                            ";
            } else {
                // line 188
                echo "                                                ";
                echo ($context["_breadcrumb"] ?? $this->getContext($context, "_breadcrumb"));
                echo "
                                            ";
            }
            // line 190
            echo "                                        </ol>
                                    ";
        }
        // line 192
        echo "                                </div>
                            ";
        
        $__internal_7cd6ab648c820fb2287cfdc0e67b0a9d8baae88e8f65d07858a1769e01916714->leave($__internal_7cd6ab648c820fb2287cfdc0e67b0a9d8baae88e8f65d07858a1769e01916714_prof);

    }

    // line 196
    public function block_sonata_top_nav_menu($context, array $blocks = array())
    {
        $__internal_6fbbba26ff89d7021b349889c6fa51bad19c7eeef76bba9ccb54761e45973b36 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6fbbba26ff89d7021b349889c6fa51bad19c7eeef76bba9ccb54761e45973b36->enter($__internal_6fbbba26ff89d7021b349889c6fa51bad19c7eeef76bba9ccb54761e45973b36_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_top_nav_menu"));

        // line 197
        echo "                            ";
        if (($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()) && $this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted($this->getAttribute($this->getAttribute(($context["sonata_admin"] ?? $this->getContext($context, "sonata_admin")), "adminPool", array()), "getOption", array(0 => "role_admin"), "method")))) {
            // line 198
            echo "                                <div class=\"navbar-custom-menu\">
                                    <ul class=\"nav navbar-nav\">
                                        ";
            // line 200
            $this->displayBlock('sonata_top_nav_menu_add_block', $context, $blocks);
            // line 208
            echo "                                        ";
            $this->displayBlock('sonata_top_nav_menu_user_block', $context, $blocks);
            // line 218
            echo "                                    </ul>
                                </div>
                            ";
        }
        // line 221
        echo "                        ";
        
        $__internal_6fbbba26ff89d7021b349889c6fa51bad19c7eeef76bba9ccb54761e45973b36->leave($__internal_6fbbba26ff89d7021b349889c6fa51bad19c7eeef76bba9ccb54761e45973b36_prof);

    }

    // line 200
    public function block_sonata_top_nav_menu_add_block($context, array $blocks = array())
    {
        $__internal_c241cc58629d5813ce3aef5fb786c825c92248175278fc7a51ada181ffdf989d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c241cc58629d5813ce3aef5fb786c825c92248175278fc7a51ada181ffdf989d->enter($__internal_c241cc58629d5813ce3aef5fb786c825c92248175278fc7a51ada181ffdf989d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_top_nav_menu_add_block"));

        // line 201
        echo "                                            <li class=\"dropdown\">
                                                <a class=\"dropdown-toggle\" data-toggle=\"dropdown\" href=\"#\">
                                                    <i class=\"fa fa-plus-square fa-fw\" aria-hidden=\"true\"></i> <i class=\"fa fa-caret-down\" aria-hidden=\"true\"></i>
                                                </a>
                                                ";
        // line 205
        $this->loadTemplate($this->getAttribute($this->getAttribute(($context["sonata_admin"] ?? $this->getContext($context, "sonata_admin")), "adminPool", array()), "getTemplate", array(0 => "add_block"), "method"), "SonataAdminBundle::standard_layout.html.twig", 205)->display($context);
        // line 206
        echo "                                            </li>
                                        ";
        
        $__internal_c241cc58629d5813ce3aef5fb786c825c92248175278fc7a51ada181ffdf989d->leave($__internal_c241cc58629d5813ce3aef5fb786c825c92248175278fc7a51ada181ffdf989d_prof);

    }

    // line 208
    public function block_sonata_top_nav_menu_user_block($context, array $blocks = array())
    {
        $__internal_c057ea7e885f1b055653f7f763ec744514d7e46502814c1855504e6b610f2e1f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c057ea7e885f1b055653f7f763ec744514d7e46502814c1855504e6b610f2e1f->enter($__internal_c057ea7e885f1b055653f7f763ec744514d7e46502814c1855504e6b610f2e1f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_top_nav_menu_user_block"));

        // line 209
        echo "                                            <li class=\"dropdown user-menu\">
                                                <a class=\"dropdown-toggle\" data-toggle=\"dropdown\" href=\"#\">
                                                    <i class=\"fa fa-user fa-fw\" aria-hidden=\"true\"></i> <i class=\"fa fa-caret-down\" aria-hidden=\"true\"></i>
                                                </a>
                                                <ul class=\"dropdown-menu dropdown-user\">
                                                    ";
        // line 214
        $this->loadTemplate($this->getAttribute($this->getAttribute(($context["sonata_admin"] ?? $this->getContext($context, "sonata_admin")), "adminPool", array()), "getTemplate", array(0 => "user_block"), "method"), "SonataAdminBundle::standard_layout.html.twig", 214)->display($context);
        // line 215
        echo "                                                </ul>
                                            </li>
                                        ";
        
        $__internal_c057ea7e885f1b055653f7f763ec744514d7e46502814c1855504e6b610f2e1f->leave($__internal_c057ea7e885f1b055653f7f763ec744514d7e46502814c1855504e6b610f2e1f_prof);

    }

    // line 227
    public function block_sonata_wrapper($context, array $blocks = array())
    {
        $__internal_93765f03f5d6a9f7e28405138909c981f2e1c7512d025db8669ba71ff529750a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_93765f03f5d6a9f7e28405138909c981f2e1c7512d025db8669ba71ff529750a->enter($__internal_93765f03f5d6a9f7e28405138909c981f2e1c7512d025db8669ba71ff529750a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_wrapper"));

        // line 228
        echo "            ";
        $this->displayBlock('sonata_left_side', $context, $blocks);
        // line 260
        echo "
            <div class=\"content-wrapper\">
                ";
        // line 262
        $this->displayBlock('sonata_page_content', $context, $blocks);
        // line 362
        echo "            </div>
        ";
        
        $__internal_93765f03f5d6a9f7e28405138909c981f2e1c7512d025db8669ba71ff529750a->leave($__internal_93765f03f5d6a9f7e28405138909c981f2e1c7512d025db8669ba71ff529750a_prof);

    }

    // line 228
    public function block_sonata_left_side($context, array $blocks = array())
    {
        $__internal_a03df732e5bd9ac8c6519a94f396e5907fdf22c23ad7b2df20ca36b32144f768 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a03df732e5bd9ac8c6519a94f396e5907fdf22c23ad7b2df20ca36b32144f768->enter($__internal_a03df732e5bd9ac8c6519a94f396e5907fdf22c23ad7b2df20ca36b32144f768_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_left_side"));

        // line 229
        echo "                <aside class=\"main-sidebar\">
                    <section class=\"sidebar\">
                        ";
        // line 231
        $this->displayBlock('sonata_side_nav', $context, $blocks);
        // line 257
        echo "                    </section>
                </aside>
            ";
        
        $__internal_a03df732e5bd9ac8c6519a94f396e5907fdf22c23ad7b2df20ca36b32144f768->leave($__internal_a03df732e5bd9ac8c6519a94f396e5907fdf22c23ad7b2df20ca36b32144f768_prof);

    }

    // line 231
    public function block_sonata_side_nav($context, array $blocks = array())
    {
        $__internal_5710cdf6ca32d8536b990f3d9a55d5ceca27e4aea2e8db409467d033d846c526 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5710cdf6ca32d8536b990f3d9a55d5ceca27e4aea2e8db409467d033d846c526->enter($__internal_5710cdf6ca32d8536b990f3d9a55d5ceca27e4aea2e8db409467d033d846c526_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_side_nav"));

        // line 232
        echo "                            ";
        $this->displayBlock('sonata_sidebar_search', $context, $blocks);
        // line 244
        echo "
                            ";
        // line 245
        $this->displayBlock('side_bar_before_nav', $context, $blocks);
        // line 246
        echo "                            ";
        $this->displayBlock('side_bar_nav', $context, $blocks);
        // line 249
        echo "                            ";
        $this->displayBlock('side_bar_after_nav', $context, $blocks);
        // line 256
        echo "                        ";
        
        $__internal_5710cdf6ca32d8536b990f3d9a55d5ceca27e4aea2e8db409467d033d846c526->leave($__internal_5710cdf6ca32d8536b990f3d9a55d5ceca27e4aea2e8db409467d033d846c526_prof);

    }

    // line 232
    public function block_sonata_sidebar_search($context, array $blocks = array())
    {
        $__internal_4ec65eb30a176cf9651694e6eb2437a7eeebaf4bfa3ccaaf16775219ea522dd1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4ec65eb30a176cf9651694e6eb2437a7eeebaf4bfa3ccaaf16775219ea522dd1->enter($__internal_4ec65eb30a176cf9651694e6eb2437a7eeebaf4bfa3ccaaf16775219ea522dd1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_sidebar_search"));

        // line 233
        echo "                                <form action=\"";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("sonata_admin_search");
        echo "\" method=\"GET\" class=\"sidebar-form\" role=\"search\">
                                    <div class=\"input-group custom-search-form\">
                                        <input type=\"text\" name=\"q\" value=\"";
        // line 235
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "get", array(0 => "q"), "method"), "html", null, true);
        echo "\" class=\"form-control\" placeholder=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("search_placeholder", array(), "SonataAdminBundle"), "html", null, true);
        echo "\">
                                        <span class=\"input-group-btn\">
                                            <button class=\"btn btn-flat\" type=\"submit\">
                                                <i class=\"fa fa-search\" aria-hidden=\"true\"></i>
                                            </button>
                                        </span>
                                    </div>
                                </form>
                            ";
        
        $__internal_4ec65eb30a176cf9651694e6eb2437a7eeebaf4bfa3ccaaf16775219ea522dd1->leave($__internal_4ec65eb30a176cf9651694e6eb2437a7eeebaf4bfa3ccaaf16775219ea522dd1_prof);

    }

    // line 245
    public function block_side_bar_before_nav($context, array $blocks = array())
    {
        $__internal_d2bd1300ddd678acf37031b6e3e1a14e82899e2464fcbed4bcf2344d3f767087 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d2bd1300ddd678acf37031b6e3e1a14e82899e2464fcbed4bcf2344d3f767087->enter($__internal_d2bd1300ddd678acf37031b6e3e1a14e82899e2464fcbed4bcf2344d3f767087_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "side_bar_before_nav"));

        echo " ";
        
        $__internal_d2bd1300ddd678acf37031b6e3e1a14e82899e2464fcbed4bcf2344d3f767087->leave($__internal_d2bd1300ddd678acf37031b6e3e1a14e82899e2464fcbed4bcf2344d3f767087_prof);

    }

    // line 246
    public function block_side_bar_nav($context, array $blocks = array())
    {
        $__internal_3aec35ed973bf15df7d6c555fba980c3e573cd6c7f92debb84bdbb7a9e4dbd48 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3aec35ed973bf15df7d6c555fba980c3e573cd6c7f92debb84bdbb7a9e4dbd48->enter($__internal_3aec35ed973bf15df7d6c555fba980c3e573cd6c7f92debb84bdbb7a9e4dbd48_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "side_bar_nav"));

        // line 247
        echo "                                ";
        echo $this->env->getExtension('Knp\Menu\Twig\MenuExtension')->render("sonata_admin_sidebar", array("template" => $this->getAttribute($this->getAttribute(($context["sonata_admin"] ?? $this->getContext($context, "sonata_admin")), "adminPool", array()), "getTemplate", array(0 => "knp_menu_template"), "method")));
        echo "
                            ";
        
        $__internal_3aec35ed973bf15df7d6c555fba980c3e573cd6c7f92debb84bdbb7a9e4dbd48->leave($__internal_3aec35ed973bf15df7d6c555fba980c3e573cd6c7f92debb84bdbb7a9e4dbd48_prof);

    }

    // line 249
    public function block_side_bar_after_nav($context, array $blocks = array())
    {
        $__internal_395fddcbc912421d7b93e554eb6bcf2f0b88a0d21e4fe554aff4c60f5b0a5ef3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_395fddcbc912421d7b93e554eb6bcf2f0b88a0d21e4fe554aff4c60f5b0a5ef3->enter($__internal_395fddcbc912421d7b93e554eb6bcf2f0b88a0d21e4fe554aff4c60f5b0a5ef3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "side_bar_after_nav"));

        // line 250
        echo "                                <p class=\"text-center small\" style=\"border-top: 1px solid #444444; padding-top: 10px\">
                                    ";
        // line 251
        $this->displayBlock('side_bar_after_nav_content', $context, $blocks);
        // line 254
        echo "                                </p>
                            ";
        
        $__internal_395fddcbc912421d7b93e554eb6bcf2f0b88a0d21e4fe554aff4c60f5b0a5ef3->leave($__internal_395fddcbc912421d7b93e554eb6bcf2f0b88a0d21e4fe554aff4c60f5b0a5ef3_prof);

    }

    // line 251
    public function block_side_bar_after_nav_content($context, array $blocks = array())
    {
        $__internal_948c7b15445b921b72122c7258e13826a6d55c8ac87c76bf6c1fb45e5885cebe = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_948c7b15445b921b72122c7258e13826a6d55c8ac87c76bf6c1fb45e5885cebe->enter($__internal_948c7b15445b921b72122c7258e13826a6d55c8ac87c76bf6c1fb45e5885cebe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "side_bar_after_nav_content"));

        // line 252
        echo "                                        <a href=\"https://sonata-project.org\" rel=\"noreferrer\" target=\"_blank\">sonata project</a>
                                    ";
        
        $__internal_948c7b15445b921b72122c7258e13826a6d55c8ac87c76bf6c1fb45e5885cebe->leave($__internal_948c7b15445b921b72122c7258e13826a6d55c8ac87c76bf6c1fb45e5885cebe_prof);

    }

    // line 262
    public function block_sonata_page_content($context, array $blocks = array())
    {
        $__internal_c3bd0c11d10c1cd205be47ee6afca078383ab2583ccdcd3ddf74b040bc3016d7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c3bd0c11d10c1cd205be47ee6afca078383ab2583ccdcd3ddf74b040bc3016d7->enter($__internal_c3bd0c11d10c1cd205be47ee6afca078383ab2583ccdcd3ddf74b040bc3016d7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_page_content"));

        // line 263
        echo "                    <section class=\"content-header\">

                        ";
        // line 265
        $this->displayBlock('sonata_page_content_header', $context, $blocks);
        // line 323
        echo "                    </section>

                    <section class=\"content\">
                        ";
        // line 326
        $this->displayBlock('sonata_admin_content', $context, $blocks);
        // line 360
        echo "                    </section>
                ";
        
        $__internal_c3bd0c11d10c1cd205be47ee6afca078383ab2583ccdcd3ddf74b040bc3016d7->leave($__internal_c3bd0c11d10c1cd205be47ee6afca078383ab2583ccdcd3ddf74b040bc3016d7_prof);

    }

    // line 265
    public function block_sonata_page_content_header($context, array $blocks = array())
    {
        $__internal_2df07e2cd7a28261c584e278c5d425b811aec8e89cc1ef90537455fbdceeaa73 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2df07e2cd7a28261c584e278c5d425b811aec8e89cc1ef90537455fbdceeaa73->enter($__internal_2df07e2cd7a28261c584e278c5d425b811aec8e89cc1ef90537455fbdceeaa73_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_page_content_header"));

        // line 266
        echo "                            ";
        $this->displayBlock('sonata_page_content_nav', $context, $blocks);
        // line 322
        echo "                        ";
        
        $__internal_2df07e2cd7a28261c584e278c5d425b811aec8e89cc1ef90537455fbdceeaa73->leave($__internal_2df07e2cd7a28261c584e278c5d425b811aec8e89cc1ef90537455fbdceeaa73_prof);

    }

    // line 266
    public function block_sonata_page_content_nav($context, array $blocks = array())
    {
        $__internal_d357a042c74ba708575916e2355dfb6d02620b89153c50434f46ef28403160cb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d357a042c74ba708575916e2355dfb6d02620b89153c50434f46ef28403160cb->enter($__internal_d357a042c74ba708575916e2355dfb6d02620b89153c50434f46ef28403160cb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_page_content_nav"));

        // line 267
        echo "                                ";
        if (((( !twig_test_empty(($context["_navbar_title"] ?? $this->getContext($context, "_navbar_title"))) ||  !twig_test_empty(        // line 268
($context["_tab_menu"] ?? $this->getContext($context, "_tab_menu")))) ||  !twig_test_empty(        // line 269
($context["_actions"] ?? $this->getContext($context, "_actions")))) ||  !twig_test_empty(        // line 270
($context["_list_filters_actions"] ?? $this->getContext($context, "_list_filters_actions"))))) {
            // line 272
            echo "                                    <nav class=\"navbar navbar-default\" role=\"navigation\">
                                        <div class=\"container-fluid\">
                                            ";
            // line 274
            $this->displayBlock('tab_menu_navbar_header', $context, $blocks);
            // line 281
            echo "
                                            <div class=\"navbar-collapse\">
                                                ";
            // line 283
            if ( !twig_test_empty(($context["_tab_menu"] ?? $this->getContext($context, "_tab_menu")))) {
                // line 284
                echo "                                                    <div class=\"navbar-left\">
                                                        ";
                // line 285
                echo ($context["_tab_menu"] ?? $this->getContext($context, "_tab_menu"));
                echo "
                                                    </div>
                                                ";
            }
            // line 288
            echo "
                                                ";
            // line 289
            if ((((array_key_exists("admin", $context) && array_key_exists("action", $context)) && (($context["action"] ?? $this->getContext($context, "action")) == "list")) && (twig_length_filter($this->env, $this->getAttribute(($context["admin"] ?? $this->getContext($context, "admin")), "listModes", array())) > 1))) {
                // line 290
                echo "                                                    <div class=\"nav navbar-right btn-group\">
                                                        ";
                // line 291
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["admin"] ?? $this->getContext($context, "admin")), "listModes", array()));
                foreach ($context['_seq'] as $context["mode"] => $context["settings"]) {
                    // line 292
                    echo "                                                            <a href=\"";
                    echo twig_escape_filter($this->env, $this->getAttribute(($context["admin"] ?? $this->getContext($context, "admin")), "generateUrl", array(0 => "list", 1 => twig_array_merge($this->getAttribute($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "query", array()), "all", array()), array("_list_mode" => $context["mode"]))), "method"), "html", null, true);
                    echo "\" class=\"btn btn-default navbar-btn btn-sm";
                    if (($this->getAttribute(($context["admin"] ?? $this->getContext($context, "admin")), "getListMode", array(), "method") == $context["mode"])) {
                        echo " active";
                    }
                    echo "\"><i class=\"";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["settings"], "class", array()), "html", null, true);
                    echo "\"></i></a>
                                                        ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['mode'], $context['settings'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 294
                echo "                                                    </div>
                                                ";
            }
            // line 296
            echo "
                                                ";
            // line 297
            $this->displayBlock('sonata_admin_content_actions_wrappers', $context, $blocks);
            // line 313
            echo "
                                                ";
            // line 314
            if ( !twig_test_empty(($context["_list_filters_actions"] ?? $this->getContext($context, "_list_filters_actions")))) {
                // line 315
                echo "                                                    ";
                echo ($context["_list_filters_actions"] ?? $this->getContext($context, "_list_filters_actions"));
                echo "
                                                ";
            }
            // line 317
            echo "                                            </div>
                                        </div>
                                    </nav>
                                ";
        }
        // line 321
        echo "                            ";
        
        $__internal_d357a042c74ba708575916e2355dfb6d02620b89153c50434f46ef28403160cb->leave($__internal_d357a042c74ba708575916e2355dfb6d02620b89153c50434f46ef28403160cb_prof);

    }

    // line 274
    public function block_tab_menu_navbar_header($context, array $blocks = array())
    {
        $__internal_e915831538d8111c63ea788ca3a958a01c1ab03cf24c0129ebc2ced392da9d8c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e915831538d8111c63ea788ca3a958a01c1ab03cf24c0129ebc2ced392da9d8c->enter($__internal_e915831538d8111c63ea788ca3a958a01c1ab03cf24c0129ebc2ced392da9d8c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "tab_menu_navbar_header"));

        // line 275
        echo "                                                ";
        if ( !twig_test_empty(($context["_navbar_title"] ?? $this->getContext($context, "_navbar_title")))) {
            // line 276
            echo "                                                    <div class=\"navbar-header\">
                                                        <a class=\"navbar-brand\" href=\"#\">";
            // line 277
            echo ($context["_navbar_title"] ?? $this->getContext($context, "_navbar_title"));
            echo "</a>
                                                    </div>
                                                ";
        }
        // line 280
        echo "                                            ";
        
        $__internal_e915831538d8111c63ea788ca3a958a01c1ab03cf24c0129ebc2ced392da9d8c->leave($__internal_e915831538d8111c63ea788ca3a958a01c1ab03cf24c0129ebc2ced392da9d8c_prof);

    }

    // line 297
    public function block_sonata_admin_content_actions_wrappers($context, array $blocks = array())
    {
        $__internal_caeec4f089920aa8c543dffb6484a21c8ae28192de6d8fabb75fbb4c08f3be8a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_caeec4f089920aa8c543dffb6484a21c8ae28192de6d8fabb75fbb4c08f3be8a->enter($__internal_caeec4f089920aa8c543dffb6484a21c8ae28192de6d8fabb75fbb4c08f3be8a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_admin_content_actions_wrappers"));

        // line 298
        echo "                                                    ";
        if ( !twig_test_empty(twig_trim_filter(twig_replace_filter(($context["_actions"] ?? $this->getContext($context, "_actions")), array("<li>" => "", "</li>" => ""))))) {
            // line 299
            echo "                                                        <ul class=\"nav navbar-nav navbar-right\">
                                                        ";
            // line 300
            if ((twig_length_filter($this->env, twig_split_filter($this->env, ($context["_actions"] ?? $this->getContext($context, "_actions")), "</a>")) > 2)) {
                // line 301
                echo "                                                            <li class=\"dropdown sonata-actions\">
                                                                <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">";
                // line 302
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("link_actions", array(), "SonataAdminBundle"), "html", null, true);
                echo " <b class=\"caret\"></b></a>
                                                                <ul class=\"dropdown-menu\" role=\"menu\">
                                                                    ";
                // line 304
                echo ($context["_actions"] ?? $this->getContext($context, "_actions"));
                echo "
                                                                </ul>
                                                            </li>
                                                        ";
            } else {
                // line 308
                echo "                                                            ";
                echo ($context["_actions"] ?? $this->getContext($context, "_actions"));
                echo "
                                                        ";
            }
            // line 310
            echo "                                                        </ul>
                                                    ";
        }
        // line 312
        echo "                                                ";
        
        $__internal_caeec4f089920aa8c543dffb6484a21c8ae28192de6d8fabb75fbb4c08f3be8a->leave($__internal_caeec4f089920aa8c543dffb6484a21c8ae28192de6d8fabb75fbb4c08f3be8a_prof);

    }

    // line 326
    public function block_sonata_admin_content($context, array $blocks = array())
    {
        $__internal_e7fb3036b3361eb90d6b880b2a69d63b95e7def74168b39698d116845c1e465c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e7fb3036b3361eb90d6b880b2a69d63b95e7def74168b39698d116845c1e465c->enter($__internal_e7fb3036b3361eb90d6b880b2a69d63b95e7def74168b39698d116845c1e465c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_admin_content"));

        // line 327
        echo "
                            ";
        // line 328
        $this->displayBlock('notice', $context, $blocks);
        // line 331
        echo "
                            ";
        // line 332
        if ( !twig_test_empty(($context["_preview"] ?? $this->getContext($context, "_preview")))) {
            // line 333
            echo "                                <div class=\"sonata-ba-preview\">";
            echo ($context["_preview"] ?? $this->getContext($context, "_preview"));
            echo "</div>
                            ";
        }
        // line 335
        echo "
                            ";
        // line 336
        if ( !twig_test_empty(($context["_content"] ?? $this->getContext($context, "_content")))) {
            // line 337
            echo "                                <div class=\"sonata-ba-content\">";
            echo ($context["_content"] ?? $this->getContext($context, "_content"));
            echo "</div>
                            ";
        }
        // line 339
        echo "
                            ";
        // line 340
        if ( !twig_test_empty(($context["_show"] ?? $this->getContext($context, "_show")))) {
            // line 341
            echo "                                <div class=\"sonata-ba-show\">";
            echo ($context["_show"] ?? $this->getContext($context, "_show"));
            echo "</div>
                            ";
        }
        // line 343
        echo "
                            ";
        // line 344
        if ( !twig_test_empty(($context["_form"] ?? $this->getContext($context, "_form")))) {
            // line 345
            echo "                                <div class=\"sonata-ba-form\">";
            echo ($context["_form"] ?? $this->getContext($context, "_form"));
            echo "</div>
                            ";
        }
        // line 347
        echo "
                            ";
        // line 348
        if ( !twig_test_empty(($context["_list_filters"] ?? $this->getContext($context, "_list_filters")))) {
            // line 349
            echo "                                <div class=\"row\">
                                    ";
            // line 350
            echo ($context["_list_filters"] ?? $this->getContext($context, "_list_filters"));
            echo "
                                </div>
                            ";
        }
        // line 353
        echo "
                            ";
        // line 354
        if ( !twig_test_empty(($context["_list_table"] ?? $this->getContext($context, "_list_table")))) {
            // line 355
            echo "                                <div class=\"row\">
                                    ";
            // line 356
            echo ($context["_list_table"] ?? $this->getContext($context, "_list_table"));
            echo "
                                </div>
                            ";
        }
        // line 359
        echo "                        ";
        
        $__internal_e7fb3036b3361eb90d6b880b2a69d63b95e7def74168b39698d116845c1e465c->leave($__internal_e7fb3036b3361eb90d6b880b2a69d63b95e7def74168b39698d116845c1e465c_prof);

    }

    // line 328
    public function block_notice($context, array $blocks = array())
    {
        $__internal_d887513c0dc6f615b39823384f7be63cd68ff6ec79780d49d505a5759339f2c2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d887513c0dc6f615b39823384f7be63cd68ff6ec79780d49d505a5759339f2c2->enter($__internal_d887513c0dc6f615b39823384f7be63cd68ff6ec79780d49d505a5759339f2c2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "notice"));

        // line 329
        echo "                                ";
        $this->loadTemplate("@SonataCore/FlashMessage/render.html.twig", "SonataAdminBundle::standard_layout.html.twig", 329)->display($context);
        // line 330
        echo "                            ";
        
        $__internal_d887513c0dc6f615b39823384f7be63cd68ff6ec79780d49d505a5759339f2c2->leave($__internal_d887513c0dc6f615b39823384f7be63cd68ff6ec79780d49d505a5759339f2c2_prof);

    }

    // line 367
    public function block_bootlint($context, array $blocks = array())
    {
        $__internal_1a61bc73156c784885b36497916bf48d98b552939fb0028afbde02cb3c23ac9a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1a61bc73156c784885b36497916bf48d98b552939fb0028afbde02cb3c23ac9a->enter($__internal_1a61bc73156c784885b36497916bf48d98b552939fb0028afbde02cb3c23ac9a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "bootlint"));

        // line 368
        echo "            ";
        // line 369
        echo "            <script type=\"text/javascript\">
                javascript:(function(){var s=document.createElement(\"script\");s.onload=function(){bootlint.showLintReportForCurrentDocument([], {hasProblems: false, problemFree: false});};s.src=\"https://maxcdn.bootstrapcdn.com/bootlint/latest/bootlint.min.js\";document.body.appendChild(s)})();
            </script>
        ";
        
        $__internal_1a61bc73156c784885b36497916bf48d98b552939fb0028afbde02cb3c23ac9a->leave($__internal_1a61bc73156c784885b36497916bf48d98b552939fb0028afbde02cb3c23ac9a_prof);

    }

    public function getTemplateName()
    {
        return "SonataAdminBundle::standard_layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  1270 => 369,  1268 => 368,  1262 => 367,  1255 => 330,  1252 => 329,  1246 => 328,  1239 => 359,  1233 => 356,  1230 => 355,  1228 => 354,  1225 => 353,  1219 => 350,  1216 => 349,  1214 => 348,  1211 => 347,  1205 => 345,  1203 => 344,  1200 => 343,  1194 => 341,  1192 => 340,  1189 => 339,  1183 => 337,  1181 => 336,  1178 => 335,  1172 => 333,  1170 => 332,  1167 => 331,  1165 => 328,  1162 => 327,  1156 => 326,  1149 => 312,  1145 => 310,  1139 => 308,  1132 => 304,  1127 => 302,  1124 => 301,  1122 => 300,  1119 => 299,  1116 => 298,  1110 => 297,  1103 => 280,  1097 => 277,  1094 => 276,  1091 => 275,  1085 => 274,  1078 => 321,  1072 => 317,  1066 => 315,  1064 => 314,  1061 => 313,  1059 => 297,  1056 => 296,  1052 => 294,  1037 => 292,  1033 => 291,  1030 => 290,  1028 => 289,  1025 => 288,  1019 => 285,  1016 => 284,  1014 => 283,  1010 => 281,  1008 => 274,  1004 => 272,  1002 => 270,  1001 => 269,  1000 => 268,  998 => 267,  992 => 266,  985 => 322,  982 => 266,  976 => 265,  968 => 360,  966 => 326,  961 => 323,  959 => 265,  955 => 263,  949 => 262,  941 => 252,  935 => 251,  927 => 254,  925 => 251,  922 => 250,  916 => 249,  906 => 247,  900 => 246,  888 => 245,  870 => 235,  864 => 233,  858 => 232,  851 => 256,  848 => 249,  845 => 246,  843 => 245,  840 => 244,  837 => 232,  831 => 231,  822 => 257,  820 => 231,  816 => 229,  810 => 228,  802 => 362,  800 => 262,  796 => 260,  793 => 228,  787 => 227,  778 => 215,  776 => 214,  769 => 209,  763 => 208,  755 => 206,  753 => 205,  747 => 201,  741 => 200,  734 => 221,  729 => 218,  726 => 208,  724 => 200,  720 => 198,  717 => 197,  711 => 196,  703 => 192,  699 => 190,  693 => 188,  690 => 187,  687 => 186,  673 => 185,  667 => 183,  663 => 181,  657 => 179,  653 => 177,  650 => 175,  647 => 173,  645 => 172,  640 => 171,  638 => 170,  635 => 169,  633 => 168,  630 => 165,  628 => 164,  626 => 163,  624 => 162,  606 => 161,  603 => 160,  601 => 159,  598 => 158,  596 => 157,  593 => 156,  587 => 155,  579 => 222,  577 => 196,  573 => 194,  571 => 155,  564 => 151,  560 => 149,  554 => 148,  547 => 147,  543 => 145,  537 => 143,  534 => 142,  526 => 140,  524 => 139,  519 => 138,  516 => 137,  510 => 136,  499 => 132,  495 => 130,  489 => 129,  481 => 224,  478 => 148,  475 => 136,  473 => 129,  470 => 128,  464 => 127,  457 => 121,  454 => 120,  452 => 119,  449 => 118,  443 => 117,  436 => 113,  433 => 112,  430 => 111,  416 => 110,  411 => 108,  408 => 105,  406 => 104,  404 => 103,  402 => 102,  398 => 99,  395 => 98,  392 => 97,  375 => 96,  372 => 95,  369 => 94,  363 => 92,  361 => 91,  355 => 89,  349 => 88,  342 => 66,  333 => 64,  328 => 63,  322 => 62,  304 => 50,  300 => 48,  294 => 47,  286 => 46,  278 => 45,  270 => 44,  266 => 42,  260 => 41,  253 => 85,  250 => 84,  244 => 82,  241 => 81,  238 => 80,  235 => 79,  232 => 77,  228 => 75,  226 => 73,  224 => 71,  221 => 70,  218 => 69,  215 => 67,  213 => 62,  210 => 61,  207 => 41,  201 => 40,  194 => 38,  185 => 36,  180 => 35,  174 => 34,  164 => 29,  158 => 28,  146 => 26,  136 => 374,  133 => 373,  130 => 367,  128 => 366,  124 => 364,  122 => 227,  119 => 226,  117 => 127,  111 => 123,  109 => 117,  104 => 114,  102 => 88,  98 => 86,  96 => 40,  93 => 39,  91 => 34,  88 => 33,  86 => 28,  81 => 26,  78 => 25,  76 => 23,  74 => 22,  72 => 21,  70 => 20,  68 => 19,  66 => 18,  64 => 17,  62 => 16,  60 => 15,  58 => 14,  56 => 13,  54 => 12,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#

This file is part of the Sonata package.

(c) Thomas Rabaix <thomas.rabaix@sonata-project.org>

For the full copyright and license information, please view the LICENSE
file that was distributed with this source code.

#}

{%- set _preview = block('preview') is defined ? block('preview')|trim : null %}
{% set _form = block('form') is defined ? block('form')|trim : null %}
{% set _show = block('show') is defined ? block('show')|trim : null %}
{% set _list_table = block('list_table') is defined ? block('list_table')|trim : null %}
{% set _list_filters = block('list_filters') is defined ? block('list_filters')|trim : null %}
{% set _tab_menu = block('tab_menu') is defined ? block('tab_menu')|trim : null %}
{% set _content = block('content') is defined ? block('content')|trim : null %}
{% set _title = block('title') is defined ? block('title')|trim : null %}
{% set _breadcrumb = block('breadcrumb') is defined ? block('breadcrumb')|trim : null %}
{% set _actions = block('actions') is defined ? block('actions')|trim : null %}
{% set _navbar_title = block('navbar_title') is defined ? block('navbar_title')|trim : null %}
{% set _list_filters_actions = block('list_filters_actions') is defined ? block('list_filters_actions')|trim : null -%}

<!DOCTYPE html>
<html {% block html_attributes %}class=\"no-js\"{% endblock %}>
    <head>
        {% block meta_tags %}
            <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
            <meta charset=\"UTF-8\">
            <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
        {% endblock %}

        {% block stylesheets %}
            {% for stylesheet in sonata_admin.adminPool.getOption('stylesheets', []) %}
                <link rel=\"stylesheet\" href=\"{{ asset(stylesheet) }}\">
            {% endfor %}
        {% endblock %}

        {% block javascripts %}
            {% block sonata_javascript_config %}
                <script>
                    window.SONATA_CONFIG = {
                        CONFIRM_EXIT: {% if sonata_admin.adminPool.getOption('confirm_exit') %}true{% else %}false{% endif %},
                        USE_SELECT2: {% if sonata_admin.adminPool.getOption('use_select2') %}true{% else %}false{% endif %},
                        USE_ICHECK: {% if sonata_admin.adminPool.getOption('use_icheck') %}true{% else %}false{% endif %},
                        USE_STICKYFORMS: {% if sonata_admin.adminPool.getOption('use_stickyforms') %}true{% else %}false{% endif %}
                    };
                    window.SONATA_TRANSLATIONS = {
                        CONFIRM_EXIT: '{{ 'confirm_exit'|trans({}, 'SonataAdminBundle')|escape('js') }}'
                    };

                    // http://getbootstrap.com/getting-started/#support-ie10-width
                    if (navigator.userAgent.match(/IEMobile\\/10\\.0/)) {
                        var msViewportStyle = document.createElement('style');
                        msViewportStyle.appendChild(document.createTextNode('@-ms-viewport{width:auto!important}'));
                        document.querySelector('head').appendChild(msViewportStyle);
                    }
                </script>
            {% endblock %}

            {% block sonata_javascript_pool %}
                {% for javascript in sonata_admin.adminPool.getOption('javascripts', []) %}
                    <script src=\"{{ asset(javascript) }}\"></script>
                {% endfor %}
            {% endblock %}

            {# localize moment #}
            {% set localeForMoment = canonicalize_locale_for_moment() %}
            {% if localeForMoment %}
                <script src=\"{{ asset(
                    'bundles/sonatacore/vendor/moment/locale/' ~
                    localeForMoment ~
                    '.js'
                ) }}\"></script>
            {% endif %}

            {# localize select2 #}
            {% if sonata_admin.adminPool.getOption('use_select2') %}
                {% set localeForSelect2 = canonicalize_locale_for_select2() %}
                {% if localeForSelect2 %}
                    <script src=\"{{ asset('bundles/sonatacore/vendor/select2/select2_locale_' ~ localeForSelect2 ~ '.js') }}\"></script>
                {% endif %}
            {% endif %}
        {% endblock %}

        <title>
        {% block sonata_head_title %}
            {{ 'Admin'|trans({}, 'SonataAdminBundle') }}

            {% if _title is not empty %}
                {{ _title|striptags|raw }}
            {% else %}
                {% if action is defined %}
                    -
                    {% for menu in breadcrumbs_builder.breadcrumbs(admin, action) %}
                        {% if not loop.first %}
                            {% if loop.index != 2 %}
                                &gt;
                            {% endif %}

                            {%- set translation_domain = menu.extra('translation_domain', 'messages') -%}
                            {%- set label = menu.label -%}
                            {%- if translation_domain is not same as(false) -%}
                                {%- set label = label|trans(menu.extra('translation_params', {}), translation_domain) -%}
                            {%- endif -%}

                            {{ label }}
                        {% endif %}
                    {% endfor %}
                {% endif %}
            {% endif %}
        {% endblock %}
        </title>
    </head>
    <body
            {% block body_attributes -%}
                class=\"sonata-bc skin-black fixed
                {% if app.request.cookies.get('sonata_sidebar_hide') -%}
                    sidebar-collapse
                {%- endif -%}\"
            {%- endblock -%}
    >

    <div class=\"wrapper\">

        {% block sonata_header %}
            <header class=\"main-header\">
                {% block sonata_header_noscript_warning %}
                    <noscript>
                        <div class=\"noscript-warning\">
                            {{ 'noscript_warning'|trans({}, 'SonataAdminBundle') }}
                        </div>
                    </noscript>
                {% endblock %}
                {% block logo %}
                    {% spaceless %}
                        <a class=\"logo\" href=\"{{ path('sonata_admin_dashboard') }}\">
                            {% if 'single_image' == sonata_admin.adminPool.getOption('title_mode') or 'both' == sonata_admin.adminPool.getOption('title_mode') %}
                                <img src=\"{{ asset(sonata_admin.adminPool.titlelogo) }}\" alt=\"{{ sonata_admin.adminPool.title }}\">
                            {% endif %}
                            {% if 'single_text' == sonata_admin.adminPool.getOption('title_mode') or 'both' == sonata_admin.adminPool.getOption('title_mode') %}
                                <span>{{ sonata_admin.adminPool.title }}</span>
                            {% endif %}
                        </a>
                    {% endspaceless %}
                {% endblock %}
                {% block sonata_nav %}
                    <nav class=\"navbar navbar-static-top\" role=\"navigation\">
                        <a href=\"#\" class=\"sidebar-toggle\" data-toggle=\"offcanvas\" role=\"button\">
                            <span class=\"sr-only\">{{ 'toggle_navigation'|trans({}, 'SonataAdminBundle') }}</span>
                        </a>

                        <div class=\"navbar-left\">
                            {% block sonata_breadcrumb %}
                                <div class=\"hidden-xs\">
                                    {% if _breadcrumb is not empty or action is defined %}
                                        <ol class=\"nav navbar-top-links breadcrumb\">
                                            {% if _breadcrumb is empty %}
                                                {% if action is defined %}
                                                    {% for menu in breadcrumbs_builder.breadcrumbs(admin, action) %}
                                                        {%- set translation_domain = menu.extra('translation_domain', 'messages') -%}
                                                        {%- set label = menu.label -%}
                                                        {%- if translation_domain is not same as(false) -%}
                                                            {%- set label = label|trans(menu.extra('translation_params', {}), translation_domain) -%}
                                                        {%- endif -%}

                                                        {% if not loop.last %}
                                                            <li>
                                                                {% if menu.uri is not empty %}
                                                                    <a href=\"{{ menu.uri }}\">
                                                                        {% if menu.extra('safe_label', true) %}
                                                                            {{- label|raw -}}
                                                                        {% else %}
                                                                            {{- label -}}
                                                                        {% endif %}
                                                                    </a>
                                                                {% else %}
                                                                    <span>{{ label }}</span>
                                                                {% endif %}
                                                            </li>
                                                        {% else %}
                                                            <li class=\"active\"><span>{{ label }}</span></li>
                                                        {% endif %}
                                                    {% endfor %}
                                                {% endif %}
                                            {% else %}
                                                {{ _breadcrumb|raw }}
                                            {% endif %}
                                        </ol>
                                    {% endif %}
                                </div>
                            {% endblock sonata_breadcrumb %}
                        </div>

                        {% block sonata_top_nav_menu %}
                            {% if app.user and is_granted(sonata_admin.adminPool.getOption('role_admin')) %}
                                <div class=\"navbar-custom-menu\">
                                    <ul class=\"nav navbar-nav\">
                                        {% block sonata_top_nav_menu_add_block %}
                                            <li class=\"dropdown\">
                                                <a class=\"dropdown-toggle\" data-toggle=\"dropdown\" href=\"#\">
                                                    <i class=\"fa fa-plus-square fa-fw\" aria-hidden=\"true\"></i> <i class=\"fa fa-caret-down\" aria-hidden=\"true\"></i>
                                                </a>
                                                {% include sonata_admin.adminPool.getTemplate('add_block') %}
                                            </li>
                                        {% endblock %}
                                        {% block sonata_top_nav_menu_user_block %}
                                            <li class=\"dropdown user-menu\">
                                                <a class=\"dropdown-toggle\" data-toggle=\"dropdown\" href=\"#\">
                                                    <i class=\"fa fa-user fa-fw\" aria-hidden=\"true\"></i> <i class=\"fa fa-caret-down\" aria-hidden=\"true\"></i>
                                                </a>
                                                <ul class=\"dropdown-menu dropdown-user\">
                                                    {% include sonata_admin.adminPool.getTemplate('user_block') %}
                                                </ul>
                                            </li>
                                        {% endblock %}
                                    </ul>
                                </div>
                            {% endif %}
                        {% endblock %}
                    </nav>
                {% endblock sonata_nav %}
            </header>
        {% endblock sonata_header %}

        {% block sonata_wrapper %}
            {% block sonata_left_side %}
                <aside class=\"main-sidebar\">
                    <section class=\"sidebar\">
                        {% block sonata_side_nav %}
                            {% block sonata_sidebar_search %}
                                <form action=\"{{ path('sonata_admin_search') }}\" method=\"GET\" class=\"sidebar-form\" role=\"search\">
                                    <div class=\"input-group custom-search-form\">
                                        <input type=\"text\" name=\"q\" value=\"{{ app.request.get('q') }}\" class=\"form-control\" placeholder=\"{{ 'search_placeholder'|trans({}, 'SonataAdminBundle') }}\">
                                        <span class=\"input-group-btn\">
                                            <button class=\"btn btn-flat\" type=\"submit\">
                                                <i class=\"fa fa-search\" aria-hidden=\"true\"></i>
                                            </button>
                                        </span>
                                    </div>
                                </form>
                            {% endblock sonata_sidebar_search %}

                            {% block side_bar_before_nav %} {% endblock %}
                            {% block side_bar_nav %}
                                {{ knp_menu_render('sonata_admin_sidebar', {template: sonata_admin.adminPool.getTemplate('knp_menu_template')}) }}
                            {% endblock side_bar_nav %}
                            {% block side_bar_after_nav %}
                                <p class=\"text-center small\" style=\"border-top: 1px solid #444444; padding-top: 10px\">
                                    {% block side_bar_after_nav_content %}
                                        <a href=\"https://sonata-project.org\" rel=\"noreferrer\" target=\"_blank\">sonata project</a>
                                    {% endblock %}
                                </p>
                            {% endblock %}
                        {% endblock sonata_side_nav %}
                    </section>
                </aside>
            {% endblock sonata_left_side %}

            <div class=\"content-wrapper\">
                {% block sonata_page_content %}
                    <section class=\"content-header\">

                        {% block sonata_page_content_header %}
                            {% block sonata_page_content_nav %}
                                {% if _navbar_title is not empty
                                  or _tab_menu is not empty
                                  or _actions is not empty
                                  or _list_filters_actions is not empty
                                 %}
                                    <nav class=\"navbar navbar-default\" role=\"navigation\">
                                        <div class=\"container-fluid\">
                                            {% block tab_menu_navbar_header %}
                                                {% if _navbar_title is not empty %}
                                                    <div class=\"navbar-header\">
                                                        <a class=\"navbar-brand\" href=\"#\">{{ _navbar_title|raw }}</a>
                                                    </div>
                                                {% endif %}
                                            {% endblock %}

                                            <div class=\"navbar-collapse\">
                                                {% if _tab_menu is not empty %}
                                                    <div class=\"navbar-left\">
                                                        {{ _tab_menu|raw }}
                                                    </div>
                                                {% endif %}

                                                {% if admin is defined and action is defined and action == 'list' and admin.listModes|length > 1 %}
                                                    <div class=\"nav navbar-right btn-group\">
                                                        {% for mode, settings in admin.listModes %}
                                                            <a href=\"{{ admin.generateUrl('list', app.request.query.all|merge({_list_mode: mode})) }}\" class=\"btn btn-default navbar-btn btn-sm{% if admin.getListMode() == mode %} active{% endif %}\"><i class=\"{{ settings.class }}\"></i></a>
                                                        {% endfor %}
                                                    </div>
                                                {% endif %}

                                                {% block sonata_admin_content_actions_wrappers %}
                                                    {% if _actions|replace({ '<li>': '', '</li>': '' })|trim is not empty %}
                                                        <ul class=\"nav navbar-nav navbar-right\">
                                                        {% if _actions|split('</a>')|length > 2 %}
                                                            <li class=\"dropdown sonata-actions\">
                                                                <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">{{ 'link_actions'|trans({}, 'SonataAdminBundle') }} <b class=\"caret\"></b></a>
                                                                <ul class=\"dropdown-menu\" role=\"menu\">
                                                                    {{ _actions|raw }}
                                                                </ul>
                                                            </li>
                                                        {% else %}
                                                            {{ _actions|raw }}
                                                        {% endif %}
                                                        </ul>
                                                    {% endif %}
                                                {% endblock sonata_admin_content_actions_wrappers %}

                                                {% if _list_filters_actions is not empty %}
                                                    {{ _list_filters_actions|raw }}
                                                {% endif %}
                                            </div>
                                        </div>
                                    </nav>
                                {% endif %}
                            {% endblock sonata_page_content_nav %}
                        {% endblock sonata_page_content_header %}
                    </section>

                    <section class=\"content\">
                        {% block sonata_admin_content %}

                            {% block notice %}
                                {% include '@SonataCore/FlashMessage/render.html.twig' %}
                            {% endblock notice %}

                            {% if _preview is not empty %}
                                <div class=\"sonata-ba-preview\">{{ _preview|raw }}</div>
                            {% endif %}

                            {% if _content is not empty %}
                                <div class=\"sonata-ba-content\">{{ _content|raw }}</div>
                            {% endif %}

                            {% if _show is not empty %}
                                <div class=\"sonata-ba-show\">{{ _show|raw }}</div>
                            {% endif %}

                            {% if _form is not empty %}
                                <div class=\"sonata-ba-form\">{{ _form|raw }}</div>
                            {% endif %}

                            {% if _list_filters is not empty %}
                                <div class=\"row\">
                                    {{ _list_filters|raw }}
                                </div>
                            {% endif %}

                            {% if _list_table is not empty %}
                                <div class=\"row\">
                                    {{ _list_table|raw }}
                                </div>
                            {% endif %}
                        {% endblock sonata_admin_content %}
                    </section>
                {% endblock sonata_page_content %}
            </div>
        {% endblock sonata_wrapper %}
    </div>

    {% if sonata_admin.adminPool.getOption('use_bootlint') %}
        {% block bootlint %}
            {# Bootlint - https://github.com/twbs/bootlint#in-the-browser #}
            <script type=\"text/javascript\">
                javascript:(function(){var s=document.createElement(\"script\");s.onload=function(){bootlint.showLintReportForCurrentDocument([], {hasProblems: false, problemFree: false});};s.src=\"https://maxcdn.bootstrapcdn.com/bootlint/latest/bootlint.min.js\";document.body.appendChild(s)})();
            </script>
        {% endblock %}
    {% endif %}

    </body>
</html>
", "SonataAdminBundle::standard_layout.html.twig", "/home/ch/proyectos/php/obrasSociales/vendor/sonata-project/admin-bundle/src/Resources/views/standard_layout.html.twig");
    }
}

<?php

/* FrontendBundle:Solicitudes:show.html.twig */
class __TwigTemplate_003051857ee6681b753f598acb193fc2a726d73547e82ba9b8dc94b532142898 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "FrontendBundle:Solicitudes:show.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7121b2feedf19583d7030f9798f6649c67afe0286675c8dd371aea081721b71f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7121b2feedf19583d7030f9798f6649c67afe0286675c8dd371aea081721b71f->enter($__internal_7121b2feedf19583d7030f9798f6649c67afe0286675c8dd371aea081721b71f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FrontendBundle:Solicitudes:show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_7121b2feedf19583d7030f9798f6649c67afe0286675c8dd371aea081721b71f->leave($__internal_7121b2feedf19583d7030f9798f6649c67afe0286675c8dd371aea081721b71f_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_05a05cbc5ded92c076a060305ad146e573917be6347fbc1499f1659964521b00 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_05a05cbc5ded92c076a060305ad146e573917be6347fbc1499f1659964521b00->enter($__internal_05a05cbc5ded92c076a060305ad146e573917be6347fbc1499f1659964521b00_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "<div class=\"top-content\">
    <div class=\"container\" style=\"width: 90% !important\">
        <div class=\"row\">
            <div class=\"col-sm-8 col-sm-offset-2 text\">
                <h1><strong> Solicitudes </strong> Obras Sociales </h1>
                <div class=\"description\">
                   
                </div>
            </div>
        </div>
        <div class=\"row\">
            <div class=\"f1 col-md-20 form-box\">
                     
                
                <p><font color=\"#054e96\">Asociación Obras Sociales en Beneficio de la Policia Nacional</p>


                <div align=\"float:center\"><img src=\"\\web\\bundles\\frontend\\images\\logo@2x.png\" height=\"260\" width=\"300\"></div>
                
    <table class=\"record_properties\">
        <tbody>
            <h1>Registro Completado Exitosamente!</h1>
        </tbody>
    </table>
        <ul class=\"record_actions\">
        <p>
                        Retorno a la Pagina Principal de Obras Sociales. 
                        ingresa en <a href=\"http://obrassocialespolicia.org/obras/\"><strong><u>Obras Sociales</strong></a></ul>
                    </p>
                    

            
        <li>
            <a href=\"";
        // line 38
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("solicitudes_new");
        echo "\"><strong><u> Crear Nueva Solicitud! </a></strong></u>
        </li>
    </ul>
";
        
        $__internal_05a05cbc5ded92c076a060305ad146e573917be6347fbc1499f1659964521b00->leave($__internal_05a05cbc5ded92c076a060305ad146e573917be6347fbc1499f1659964521b00_prof);

    }

    public function getTemplateName()
    {
        return "FrontendBundle:Solicitudes:show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  75 => 38,  40 => 5,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '::base.html.twig' %}

{% block body -%}
 
    <div class=\"top-content\">
    <div class=\"container\" style=\"width: 90% !important\">
        <div class=\"row\">
            <div class=\"col-sm-8 col-sm-offset-2 text\">
                <h1><strong> Solicitudes </strong> Obras Sociales </h1>
                <div class=\"description\">
                   
                </div>
            </div>
        </div>
        <div class=\"row\">
            <div class=\"f1 col-md-20 form-box\">
                     
                
                <p><font color=\"#054e96\">Asociación Obras Sociales en Beneficio de la Policia Nacional</p>


                <div align=\"float:center\"><img src=\"\\web\\bundles\\frontend\\images\\logo@2x.png\" height=\"260\" width=\"300\"></div>
                
    <table class=\"record_properties\">
        <tbody>
            <h1>Registro Completado Exitosamente!</h1>
        </tbody>
    </table>
        <ul class=\"record_actions\">
        <p>
                        Retorno a la Pagina Principal de Obras Sociales. 
                        ingresa en <a href=\"http://obrassocialespolicia.org/obras/\"><strong><u>Obras Sociales</strong></a></ul>
                    </p>
                    

            
        <li>
            <a href=\"{{ path('solicitudes_new') }}\"><strong><u> Crear Nueva Solicitud! </a></strong></u>
        </li>
    </ul>
{% endblock %}
", "FrontendBundle:Solicitudes:show.html.twig", "/home/ch/proyectos/php/obrasSociales/src/FrontendBundle/Resources/views/Solicitudes/show.html.twig");
    }
}

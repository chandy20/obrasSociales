<?php

/* TwigBundle:Exception:error.atom.twig */
class __TwigTemplate_9b257d0bd02556b9f4d3c81f70f05c736202cd398667007b549135f8cc9d499e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ce64e947058dcc34e59d9d37fd896c38a498a22d193eaecc4c6787ab5691834c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ce64e947058dcc34e59d9d37fd896c38a498a22d193eaecc4c6787ab5691834c->enter($__internal_ce64e947058dcc34e59d9d37fd896c38a498a22d193eaecc4c6787ab5691834c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "TwigBundle:Exception:error.atom.twig", 1)->display($context);
        
        $__internal_ce64e947058dcc34e59d9d37fd896c38a498a22d193eaecc4c6787ab5691834c->leave($__internal_ce64e947058dcc34e59d9d37fd896c38a498a22d193eaecc4c6787ab5691834c_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.atom.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include '@Twig/Exception/error.xml.twig' %}
", "TwigBundle:Exception:error.atom.twig", "/home/ch/proyectos/php/obrasSociales/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/error.atom.twig");
    }
}

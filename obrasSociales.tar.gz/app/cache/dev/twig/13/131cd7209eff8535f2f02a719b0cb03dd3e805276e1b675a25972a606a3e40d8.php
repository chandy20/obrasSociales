<?php

/* FOSUserBundle:Group:new.html.twig */
class __TwigTemplate_2c16a34b067ecaa6a1bc61272d6193a5ba81ec3c5155dd9939c9867a79226386 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Group:new.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b2533e76f845d596f83dd8d2245d31efe6ea50da9e1e15a1ab386f0bb01ba27f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b2533e76f845d596f83dd8d2245d31efe6ea50da9e1e15a1ab386f0bb01ba27f->enter($__internal_b2533e76f845d596f83dd8d2245d31efe6ea50da9e1e15a1ab386f0bb01ba27f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b2533e76f845d596f83dd8d2245d31efe6ea50da9e1e15a1ab386f0bb01ba27f->leave($__internal_b2533e76f845d596f83dd8d2245d31efe6ea50da9e1e15a1ab386f0bb01ba27f_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_429609316522c87b22f9d824b18de25aa1f40d11afdef098b2d9e3d14f6a72a2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_429609316522c87b22f9d824b18de25aa1f40d11afdef098b2d9e3d14f6a72a2->enter($__internal_429609316522c87b22f9d824b18de25aa1f40d11afdef098b2d9e3d14f6a72a2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Group:new_content.html.twig", "FOSUserBundle:Group:new.html.twig", 4)->display($context);
        
        $__internal_429609316522c87b22f9d824b18de25aa1f40d11afdef098b2d9e3d14f6a72a2->leave($__internal_429609316522c87b22f9d824b18de25aa1f40d11afdef098b2d9e3d14f6a72a2_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"FOSUserBundle::layout.html.twig\" %}

{% block fos_user_content %}
{% include \"FOSUserBundle:Group:new_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Group:new.html.twig", "/home/ch/proyectos/php/obrasSociales/vendor/friendsofsymfony/user-bundle/FOS/UserBundle/Resources/views/Group/new.html.twig");
    }
}

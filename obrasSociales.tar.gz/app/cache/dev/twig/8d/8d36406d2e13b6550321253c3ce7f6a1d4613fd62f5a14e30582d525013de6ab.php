<?php

/* @SonataAdmin/CRUD/edit.html.twig */
class __TwigTemplate_040440c9c648e2a898fbbe3b46e18ca8602c7fc01d4704205c2523abbf9fcab6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 12
        $this->parent = $this->loadTemplate("@SonataAdmin/CRUD/base_edit.html.twig", "@SonataAdmin/CRUD/edit.html.twig", 12);
        $this->blocks = array(
        );
    }

    protected function doGetParent(array $context)
    {
        return "@SonataAdmin/CRUD/base_edit.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5b51263d24cfda3c1e5b4a3a84e9b3d0d2289616fc91deb8ae7548ee3c9fb0f8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5b51263d24cfda3c1e5b4a3a84e9b3d0d2289616fc91deb8ae7548ee3c9fb0f8->enter($__internal_5b51263d24cfda3c1e5b4a3a84e9b3d0d2289616fc91deb8ae7548ee3c9fb0f8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@SonataAdmin/CRUD/edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5b51263d24cfda3c1e5b4a3a84e9b3d0d2289616fc91deb8ae7548ee3c9fb0f8->leave($__internal_5b51263d24cfda3c1e5b4a3a84e9b3d0d2289616fc91deb8ae7548ee3c9fb0f8_prof);

    }

    public function getTemplateName()
    {
        return "@SonataAdmin/CRUD/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  11 => 12,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#

This file is part of the Sonata package.

(c) Thomas Rabaix <thomas.rabaix@sonata-project.org>

For the full copyright and license information, please view the LICENSE
file that was distributed with this source code.

#}

{% extends '@SonataAdmin/CRUD/base_edit.html.twig' %}
", "@SonataAdmin/CRUD/edit.html.twig", "/home/ch/proyectos/php/obrasSociales/vendor/sonata-project/admin-bundle/src/Resources/views/CRUD/edit.html.twig");
    }
}

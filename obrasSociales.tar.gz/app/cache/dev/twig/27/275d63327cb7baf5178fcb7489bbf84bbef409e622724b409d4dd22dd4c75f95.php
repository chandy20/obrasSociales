<?php

/* ::base.html.twig */
class __TwigTemplate_b433ebbb958cb2b39f588f2820a3296d9f6110d39c1b82ace3fd33885e2a4b84 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_82b9b6a81749702203f7fe3fcc94a2848973fc584f9fbd3f9b562a534db250b9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_82b9b6a81749702203f7fe3fcc94a2848973fc584f9fbd3f9b562a534db250b9->enter($__internal_82b9b6a81749702203f7fe3fcc94a2848973fc584f9fbd3f9b562a534db250b9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 17
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 20
        $this->displayBlock('body', $context, $blocks);
        // line 23
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 32
        echo "    </body>
</html>
";
        
        $__internal_82b9b6a81749702203f7fe3fcc94a2848973fc584f9fbd3f9b562a534db250b9->leave($__internal_82b9b6a81749702203f7fe3fcc94a2848973fc584f9fbd3f9b562a534db250b9_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_303342da666fcdc4e99459332e1e087bbb3148a02523c9c4ec9ba1544d55e1c1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_303342da666fcdc4e99459332e1e087bbb3148a02523c9c4ec9ba1544d55e1c1->enter($__internal_303342da666fcdc4e99459332e1e087bbb3148a02523c9c4ec9ba1544d55e1c1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Solicitudes AOS!";
        
        $__internal_303342da666fcdc4e99459332e1e087bbb3148a02523c9c4ec9ba1544d55e1c1->leave($__internal_303342da666fcdc4e99459332e1e087bbb3148a02523c9c4ec9ba1544d55e1c1_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_017c5d2996efba879ffd5af5f8b005641be9575e104f7c43d3acc189461add15 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_017c5d2996efba879ffd5af5f8b005641be9575e104f7c43d3acc189461add15->enter($__internal_017c5d2996efba879ffd5af5f8b005641be9575e104f7c43d3acc189461add15_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 7
        echo "       
        <link rel=\"stylesheet\" href=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "getSchemeAndHttpHost", array(), "method"), "html", null, true);
        echo "/bundles/frontend/css/bootstrap.min.css\">
        <link rel=\"stylesheet\" href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "getSchemeAndHttpHost", array(), "method"), "html", null, true);
        echo "/bundles/frontend/css/form-elements.css\">
        <link rel=\"stylesheet\" href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "getSchemeAndHttpHost", array(), "method"), "html", null, true);
        echo "/bundles/frontend/css/style.css\">
       
       



        ";
        
        $__internal_017c5d2996efba879ffd5af5f8b005641be9575e104f7c43d3acc189461add15->leave($__internal_017c5d2996efba879ffd5af5f8b005641be9575e104f7c43d3acc189461add15_prof);

    }

    // line 20
    public function block_body($context, array $blocks = array())
    {
        $__internal_7c423344fc2ecfc156cbd65780777e3e6d9fb8d8d92a4732c150ebec4fa59f58 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7c423344fc2ecfc156cbd65780777e3e6d9fb8d8d92a4732c150ebec4fa59f58->enter($__internal_7c423344fc2ecfc156cbd65780777e3e6d9fb8d8d92a4732c150ebec4fa59f58_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 21
        echo "        
        ";
        
        $__internal_7c423344fc2ecfc156cbd65780777e3e6d9fb8d8d92a4732c150ebec4fa59f58->leave($__internal_7c423344fc2ecfc156cbd65780777e3e6d9fb8d8d92a4732c150ebec4fa59f58_prof);

    }

    // line 23
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_18cb3301cedb5fcae6c377410ce75d0ef74d28009ae5fae223046054d2c5b213 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_18cb3301cedb5fcae6c377410ce75d0ef74d28009ae5fae223046054d2c5b213->enter($__internal_18cb3301cedb5fcae6c377410ce75d0ef74d28009ae5fae223046054d2c5b213_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 24
        echo "        <script src=\"";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "getSchemeAndHttpHost", array(), "method"), "html", null, true);
        echo "/bundles/frontend/js/jquery-1.11.1.min.js\"></script>
        <script src=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "getSchemeAndHttpHost", array(), "method"), "html", null, true);
        echo "/bundles/frontend/js/bootstrap.min.js\"></script>
        <script src=\"";
        // line 26
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "getSchemeAndHttpHost", array(), "method"), "html", null, true);
        echo "/bundles/frontend/js/jquery.backstretch.min.js\"></script>
        <script src=\"";
        // line 27
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "getSchemeAndHttpHost", array(), "method"), "html", null, true);
        echo "/bundles/frontend/js/retina-1.1.0.min.js\"></script>
        <script src=\"";
        // line 28
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "getSchemeAndHttpHost", array(), "method"), "html", null, true);
        echo "/bundles/frontend/js/scripts.js\"></script>
        <script src=\"";
        // line 29
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "getSchemeAndHttpHost", array(), "method"), "html", null, true);
        echo "/bundles/frontend/js/funcionesComunes.js\"></script>

        ";
        
        $__internal_18cb3301cedb5fcae6c377410ce75d0ef74d28009ae5fae223046054d2c5b213->leave($__internal_18cb3301cedb5fcae6c377410ce75d0ef74d28009ae5fae223046054d2c5b213_prof);

    }

    public function getTemplateName()
    {
        return "::base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  143 => 29,  139 => 28,  135 => 27,  131 => 26,  127 => 25,  122 => 24,  116 => 23,  108 => 21,  102 => 20,  88 => 10,  84 => 9,  80 => 8,  77 => 7,  71 => 6,  59 => 5,  50 => 32,  47 => 23,  45 => 20,  38 => 17,  36 => 6,  32 => 5,  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Solicitudes AOS!{% endblock %}</title>
        {% block stylesheets %}
       
        <link rel=\"stylesheet\" href=\"{{ app.request.getSchemeAndHttpHost() }}/bundles/frontend/css/bootstrap.min.css\">
        <link rel=\"stylesheet\" href=\"{{ app.request.getSchemeAndHttpHost() }}/bundles/frontend/css/form-elements.css\">
        <link rel=\"stylesheet\" href=\"{{ app.request.getSchemeAndHttpHost() }}/bundles/frontend/css/style.css\">
       
       



        {% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body>
        {% block body %}
        
        {% endblock %}
        {% block javascripts %}
        <script src=\"{{ app.request.getSchemeAndHttpHost() }}/bundles/frontend/js/jquery-1.11.1.min.js\"></script>
        <script src=\"{{ app.request.getSchemeAndHttpHost() }}/bundles/frontend/js/bootstrap.min.js\"></script>
        <script src=\"{{ app.request.getSchemeAndHttpHost() }}/bundles/frontend/js/jquery.backstretch.min.js\"></script>
        <script src=\"{{ app.request.getSchemeAndHttpHost() }}/bundles/frontend/js/retina-1.1.0.min.js\"></script>
        <script src=\"{{ app.request.getSchemeAndHttpHost() }}/bundles/frontend/js/scripts.js\"></script>
        <script src=\"{{ app.request.getSchemeAndHttpHost() }}/bundles/frontend/js/funcionesComunes.js\"></script>

        {% endblock %}
    </body>
</html>
", "::base.html.twig", "/home/ch/proyectos/php/obrasSociales/app/Resources/views/base.html.twig");
    }
}

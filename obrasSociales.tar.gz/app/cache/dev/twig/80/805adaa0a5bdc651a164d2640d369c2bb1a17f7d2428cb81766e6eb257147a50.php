<?php

/* @Framework/Form/repeated_row.html.php */
class __TwigTemplate_ff0501e634963b1b05d2c3c0bc59244c5a0d9290471e117244ee28597197ce58 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bc6d7fa401751209dabb4c9d8e8038dfcf3e1be276e230e0ed53b7be40114453 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bc6d7fa401751209dabb4c9d8e8038dfcf3e1be276e230e0ed53b7be40114453->enter($__internal_bc6d7fa401751209dabb4c9d8e8038dfcf3e1be276e230e0ed53b7be40114453_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/repeated_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_rows') ?>
";
        
        $__internal_bc6d7fa401751209dabb4c9d8e8038dfcf3e1be276e230e0ed53b7be40114453->leave($__internal_bc6d7fa401751209dabb4c9d8e8038dfcf3e1be276e230e0ed53b7be40114453_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/repeated_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_rows') ?>
", "@Framework/Form/repeated_row.html.php", "/home/ch/proyectos/php/obrasSociales/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/repeated_row.html.php");
    }
}

<?php

/* FrontendBundle:Default:index.html.twig */
class __TwigTemplate_39a07ed76a3a3ba9e9a58a9ac847edd55d2bc175fb9e60c015b8f6ad9fe522e1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "FrontendBundle:Default:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a5755808752142dd90a20c055c30110a88e47bed57a85dea9cd728e665111473 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a5755808752142dd90a20c055c30110a88e47bed57a85dea9cd728e665111473->enter($__internal_a5755808752142dd90a20c055c30110a88e47bed57a85dea9cd728e665111473_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FrontendBundle:Default:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a5755808752142dd90a20c055c30110a88e47bed57a85dea9cd728e665111473->leave($__internal_a5755808752142dd90a20c055c30110a88e47bed57a85dea9cd728e665111473_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_4433adc1f28fd60211ea19db12e4df015626471f321b0abb6dab13b67a3b867a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4433adc1f28fd60211ea19db12e4df015626471f321b0abb6dab13b67a3b867a->enter($__internal_4433adc1f28fd60211ea19db12e4df015626471f321b0abb6dab13b67a3b867a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "<div class=\"top-content\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-sm-8 col-sm-offset-2 text\">
                <h1>Bienvenido a <strong>Formulario de Solicitudes </strong> AOS </h1>
                <div class=\"description\">
              </div>
            </div>
        </div>   

        <div class=\"row\">
            <div class=\"f1 col-md-12 form-box\">
                <h3>Formulario de Solicitudes</h3>
                <p>Asociación Obras Sociales</p>
                <div class=\"f1-steps\">
                 <div align=\"float:center\"><img src=\"\\web\\bundles\\frontend\\images\\slider.jpg\" height=\"500\" width=\"2150\"></div>
                    
                       <div class=\"f1-step active\">
                        
                    </div>

    <ul class=\"record_actions\">
        <li>
            <a href=\"";
        // line 28
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("solicitudes_new");
        echo "\">Ingrese al Formulario de Solicitudes</a>
        </li>

    </ul>
</div>

";
        
        $__internal_4433adc1f28fd60211ea19db12e4df015626471f321b0abb6dab13b67a3b867a->leave($__internal_4433adc1f28fd60211ea19db12e4df015626471f321b0abb6dab13b67a3b867a_prof);

    }

    public function getTemplateName()
    {
        return "FrontendBundle:Default:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  65 => 28,  40 => 5,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '::base.html.twig' %}

{% block body -%}

<div class=\"top-content\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-sm-8 col-sm-offset-2 text\">
                <h1>Bienvenido a <strong>Formulario de Solicitudes </strong> AOS </h1>
                <div class=\"description\">
              </div>
            </div>
        </div>   

        <div class=\"row\">
            <div class=\"f1 col-md-12 form-box\">
                <h3>Formulario de Solicitudes</h3>
                <p>Asociación Obras Sociales</p>
                <div class=\"f1-steps\">
                 <div align=\"float:center\"><img src=\"\\web\\bundles\\frontend\\images\\slider.jpg\" height=\"500\" width=\"2150\"></div>
                    
                       <div class=\"f1-step active\">
                        
                    </div>

    <ul class=\"record_actions\">
        <li>
            <a href=\"{{ path('solicitudes_new') }}\">Ingrese al Formulario de Solicitudes</a>
        </li>

    </ul>
</div>

{% endblock %}", "FrontendBundle:Default:index.html.twig", "/home/ch/proyectos/php/obrasSociales/src/FrontendBundle/Resources/views/Default/index.html.twig");
    }
}

<?php

/* SonataAdminBundle:CRUD:action.html.twig */
class __TwigTemplate_383c5d9ca1056df536e3e14c2b6d9ea991959628f7ae7e247ee6bbffbc6aa6b6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'actions' => array($this, 'block_actions'),
            'tab_menu' => array($this, 'block_tab_menu'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        // line 12
        return $this->loadTemplate(($context["base_template"] ?? $this->getContext($context, "base_template")), "SonataAdminBundle:CRUD:action.html.twig", 12);
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_78172cb72bfdb3ebc1f3441895a6a4e388cff24108c6374d9f1ceb3f11ee022e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_78172cb72bfdb3ebc1f3441895a6a4e388cff24108c6374d9f1ceb3f11ee022e->enter($__internal_78172cb72bfdb3ebc1f3441895a6a4e388cff24108c6374d9f1ceb3f11ee022e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataAdminBundle:CRUD:action.html.twig"));

        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_78172cb72bfdb3ebc1f3441895a6a4e388cff24108c6374d9f1ceb3f11ee022e->leave($__internal_78172cb72bfdb3ebc1f3441895a6a4e388cff24108c6374d9f1ceb3f11ee022e_prof);

    }

    // line 14
    public function block_actions($context, array $blocks = array())
    {
        $__internal_4816fd500d0872907a5db39336182b6d696ed4114d7ff977a1d22be86e510109 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4816fd500d0872907a5db39336182b6d696ed4114d7ff977a1d22be86e510109->enter($__internal_4816fd500d0872907a5db39336182b6d696ed4114d7ff977a1d22be86e510109_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "actions"));

        // line 15
        $this->loadTemplate("@SonataAdmin/CRUD/action_buttons.html.twig", "SonataAdminBundle:CRUD:action.html.twig", 15)->display($context);
        
        $__internal_4816fd500d0872907a5db39336182b6d696ed4114d7ff977a1d22be86e510109->leave($__internal_4816fd500d0872907a5db39336182b6d696ed4114d7ff977a1d22be86e510109_prof);

    }

    // line 18
    public function block_tab_menu($context, array $blocks = array())
    {
        $__internal_fbd7b3e1b37c8c0a690243bfc26e8e28dcf1b1fde4436736b5a8207df5c2ba3a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fbd7b3e1b37c8c0a690243bfc26e8e28dcf1b1fde4436736b5a8207df5c2ba3a->enter($__internal_fbd7b3e1b37c8c0a690243bfc26e8e28dcf1b1fde4436736b5a8207df5c2ba3a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "tab_menu"));

        // line 19
        echo "    ";
        if (array_key_exists("action", $context)) {
            // line 20
            echo "        ";
            echo $this->env->getExtension('Knp\Menu\Twig\MenuExtension')->render($this->getAttribute(($context["admin"] ?? $this->getContext($context, "admin")), "sidemenu", array(0 => ($context["action"] ?? $this->getContext($context, "action"))), "method"), array("currentClass" => "active", "template" => $this->getAttribute($this->getAttribute(($context["sonata_admin"] ?? $this->getContext($context, "sonata_admin")), "adminPool", array()), "getTemplate", array(0 => "tab_menu_template"), "method")), "twig");
            echo "
    ";
        }
        
        $__internal_fbd7b3e1b37c8c0a690243bfc26e8e28dcf1b1fde4436736b5a8207df5c2ba3a->leave($__internal_fbd7b3e1b37c8c0a690243bfc26e8e28dcf1b1fde4436736b5a8207df5c2ba3a_prof);

    }

    // line 24
    public function block_content($context, array $blocks = array())
    {
        $__internal_b87c430df874bd8d1ddea665bd5b73eac5e829f786d42477bf5d48857910816b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b87c430df874bd8d1ddea665bd5b73eac5e829f786d42477bf5d48857910816b->enter($__internal_b87c430df874bd8d1ddea665bd5b73eac5e829f786d42477bf5d48857910816b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 25
        echo "
    Redefine the content block in your action template

";
        
        $__internal_b87c430df874bd8d1ddea665bd5b73eac5e829f786d42477bf5d48857910816b->leave($__internal_b87c430df874bd8d1ddea665bd5b73eac5e829f786d42477bf5d48857910816b_prof);

    }

    public function getTemplateName()
    {
        return "SonataAdminBundle:CRUD:action.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  74 => 25,  68 => 24,  57 => 20,  54 => 19,  48 => 18,  41 => 15,  35 => 14,  20 => 12,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#

This file is part of the Sonata package.

(c) Thomas Rabaix <thomas.rabaix@sonata-project.org>

For the full copyright and license information, please view the LICENSE
file that was distributed with this source code.

#}

{% extends base_template %}

{%- block actions -%}
    {% include '@SonataAdmin/CRUD/action_buttons.html.twig' %}
{%- endblock -%}

{% block tab_menu %}
    {% if action is defined %}
        {{ knp_menu_render(admin.sidemenu(action), {'currentClass' : 'active', 'template': sonata_admin.adminPool.getTemplate('tab_menu_template')}, 'twig') }}
    {% endif %}
{% endblock %}

{% block content %}

    Redefine the content block in your action template

{% endblock %}
", "SonataAdminBundle:CRUD:action.html.twig", "/home/ch/proyectos/php/obrasSociales/vendor/sonata-project/admin-bundle/src/Resources/views/CRUD/action.html.twig");
    }
}

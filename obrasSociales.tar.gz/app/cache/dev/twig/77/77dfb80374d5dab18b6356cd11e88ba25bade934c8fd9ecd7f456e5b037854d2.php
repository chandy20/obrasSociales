<?php

/* SonataAdminBundle:CRUD:edit_string.html.twig */
class __TwigTemplate_a86e3fd9d88b867d1a348794b2b57dc562a45cd7a45db1f643fb323189f76a81 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'field' => array($this, 'block_field'),
        );
    }

    protected function doGetParent(array $context)
    {
        // line 12
        return $this->loadTemplate(($context["base_template"] ?? $this->getContext($context, "base_template")), "SonataAdminBundle:CRUD:edit_string.html.twig", 12);
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fc30d1dd7550fcce5bcc8ea6e00be139006226a7dae4bdb6712e16671e80eb9e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fc30d1dd7550fcce5bcc8ea6e00be139006226a7dae4bdb6712e16671e80eb9e->enter($__internal_fc30d1dd7550fcce5bcc8ea6e00be139006226a7dae4bdb6712e16671e80eb9e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataAdminBundle:CRUD:edit_string.html.twig"));

        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_fc30d1dd7550fcce5bcc8ea6e00be139006226a7dae4bdb6712e16671e80eb9e->leave($__internal_fc30d1dd7550fcce5bcc8ea6e00be139006226a7dae4bdb6712e16671e80eb9e_prof);

    }

    // line 14
    public function block_field($context, array $blocks = array())
    {
        $__internal_591c10b6aa954d131d377427b8ab6d5b3651c4c50fc0933215110bb77afc40d9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_591c10b6aa954d131d377427b8ab6d5b3651c4c50fc0933215110bb77afc40d9->enter($__internal_591c10b6aa954d131d377427b8ab6d5b3651c4c50fc0933215110bb77afc40d9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "field"));

        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock(($context["field_element"] ?? $this->getContext($context, "field_element")), 'widget', array("attr" => array("class" => "title")));
        
        $__internal_591c10b6aa954d131d377427b8ab6d5b3651c4c50fc0933215110bb77afc40d9->leave($__internal_591c10b6aa954d131d377427b8ab6d5b3651c4c50fc0933215110bb77afc40d9_prof);

    }

    public function getTemplateName()
    {
        return "SonataAdminBundle:CRUD:edit_string.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  33 => 14,  18 => 12,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#

This file is part of the Sonata package.

(c) Thomas Rabaix <thomas.rabaix@sonata-project.org>

For the full copyright and license information, please view the LICENSE
file that was distributed with this source code.

#}

{% extends base_template %}

{% block field %}{{ form_widget(field_element, {'attr': {'class' : 'title'}}) }}{% endblock %}
", "SonataAdminBundle:CRUD:edit_string.html.twig", "/home/ch/proyectos/php/obrasSociales/vendor/sonata-project/admin-bundle/src/Resources/views/CRUD/edit_string.html.twig");
    }
}

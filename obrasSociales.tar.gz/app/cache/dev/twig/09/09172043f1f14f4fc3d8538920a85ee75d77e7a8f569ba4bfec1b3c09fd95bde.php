<?php

/* @Framework/Form/container_attributes.html.php */
class __TwigTemplate_44606b53f51af12d070cac8deae1dc4e96966d267c6a76e5d8a908812a41cb67 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_47012d1c235144a115e7859fe66774742499db9bf1b70a74cda280d1f5641e58 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_47012d1c235144a115e7859fe66774742499db9bf1b70a74cda280d1f5641e58->enter($__internal_47012d1c235144a115e7859fe66774742499db9bf1b70a74cda280d1f5641e58_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/container_attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
";
        
        $__internal_47012d1c235144a115e7859fe66774742499db9bf1b70a74cda280d1f5641e58->leave($__internal_47012d1c235144a115e7859fe66774742499db9bf1b70a74cda280d1f5641e58_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/container_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
", "@Framework/Form/container_attributes.html.php", "/home/ch/proyectos/php/obrasSociales/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/container_attributes.html.php");
    }
}

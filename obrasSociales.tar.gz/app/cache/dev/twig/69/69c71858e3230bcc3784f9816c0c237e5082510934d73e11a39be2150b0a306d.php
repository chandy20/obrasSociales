<?php

/* SonataAdminBundle::empty_layout.html.twig */
class __TwigTemplate_f050d6c39ac0b364a36772346ba1c700596ba62ccababd38f396e78f84e5a7fa extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'sonata_header' => array($this, 'block_sonata_header'),
            'sonata_left_side' => array($this, 'block_sonata_left_side'),
            'sonata_nav' => array($this, 'block_sonata_nav'),
            'sonata_breadcrumb' => array($this, 'block_sonata_breadcrumb'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'sonata_wrapper' => array($this, 'block_sonata_wrapper'),
            'sonata_page_content' => array($this, 'block_sonata_page_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        // line 12
        return $this->loadTemplate($this->getAttribute(($context["admin_pool"] ?? $this->getContext($context, "admin_pool")), "getTemplate", array(0 => "layout"), "method"), "SonataAdminBundle::empty_layout.html.twig", 12);
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1f0ab06ce9dbaf068b11c909dcbcc0ec1a47a6a612c7a55a14f51eacb2bff013 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1f0ab06ce9dbaf068b11c909dcbcc0ec1a47a6a612c7a55a14f51eacb2bff013->enter($__internal_1f0ab06ce9dbaf068b11c909dcbcc0ec1a47a6a612c7a55a14f51eacb2bff013_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataAdminBundle::empty_layout.html.twig"));

        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_1f0ab06ce9dbaf068b11c909dcbcc0ec1a47a6a612c7a55a14f51eacb2bff013->leave($__internal_1f0ab06ce9dbaf068b11c909dcbcc0ec1a47a6a612c7a55a14f51eacb2bff013_prof);

    }

    // line 14
    public function block_sonata_header($context, array $blocks = array())
    {
        $__internal_8bff75ef07135a88bad322cd1a834d2e404f5e240d1e4d1cec1303324b06b98c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8bff75ef07135a88bad322cd1a834d2e404f5e240d1e4d1cec1303324b06b98c->enter($__internal_8bff75ef07135a88bad322cd1a834d2e404f5e240d1e4d1cec1303324b06b98c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_header"));

        
        $__internal_8bff75ef07135a88bad322cd1a834d2e404f5e240d1e4d1cec1303324b06b98c->leave($__internal_8bff75ef07135a88bad322cd1a834d2e404f5e240d1e4d1cec1303324b06b98c_prof);

    }

    // line 15
    public function block_sonata_left_side($context, array $blocks = array())
    {
        $__internal_998e3a63898ce94e52d3e2fb15b08913774eee9bfdac276303fb6887523682ee = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_998e3a63898ce94e52d3e2fb15b08913774eee9bfdac276303fb6887523682ee->enter($__internal_998e3a63898ce94e52d3e2fb15b08913774eee9bfdac276303fb6887523682ee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_left_side"));

        
        $__internal_998e3a63898ce94e52d3e2fb15b08913774eee9bfdac276303fb6887523682ee->leave($__internal_998e3a63898ce94e52d3e2fb15b08913774eee9bfdac276303fb6887523682ee_prof);

    }

    // line 16
    public function block_sonata_nav($context, array $blocks = array())
    {
        $__internal_958d40ef63ee2f03dbbd70f9b9f653b8099e0cd2138f7e9780a32c26d83b5d98 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_958d40ef63ee2f03dbbd70f9b9f653b8099e0cd2138f7e9780a32c26d83b5d98->enter($__internal_958d40ef63ee2f03dbbd70f9b9f653b8099e0cd2138f7e9780a32c26d83b5d98_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_nav"));

        
        $__internal_958d40ef63ee2f03dbbd70f9b9f653b8099e0cd2138f7e9780a32c26d83b5d98->leave($__internal_958d40ef63ee2f03dbbd70f9b9f653b8099e0cd2138f7e9780a32c26d83b5d98_prof);

    }

    // line 17
    public function block_sonata_breadcrumb($context, array $blocks = array())
    {
        $__internal_2e176e2eb095c20ba0fc181a7eebe016428e06161d720e106a26c158bd5b6512 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2e176e2eb095c20ba0fc181a7eebe016428e06161d720e106a26c158bd5b6512->enter($__internal_2e176e2eb095c20ba0fc181a7eebe016428e06161d720e106a26c158bd5b6512_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_breadcrumb"));

        
        $__internal_2e176e2eb095c20ba0fc181a7eebe016428e06161d720e106a26c158bd5b6512->leave($__internal_2e176e2eb095c20ba0fc181a7eebe016428e06161d720e106a26c158bd5b6512_prof);

    }

    // line 19
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_e2c04cddcfc6106a6fbc7b88c9f24b901f5da1f98c5a27672084080b7f62f3fa = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e2c04cddcfc6106a6fbc7b88c9f24b901f5da1f98c5a27672084080b7f62f3fa->enter($__internal_e2c04cddcfc6106a6fbc7b88c9f24b901f5da1f98c5a27672084080b7f62f3fa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 20
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "

    <style>
        .content {
            margin: 0px;
            padding: 0px;
        }
    </style>
";
        
        $__internal_e2c04cddcfc6106a6fbc7b88c9f24b901f5da1f98c5a27672084080b7f62f3fa->leave($__internal_e2c04cddcfc6106a6fbc7b88c9f24b901f5da1f98c5a27672084080b7f62f3fa_prof);

    }

    // line 30
    public function block_sonata_wrapper($context, array $blocks = array())
    {
        $__internal_bd2eb8e7d72034f608b8e8f685763038715837f8730b83cc137b1ee8a5ff618f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bd2eb8e7d72034f608b8e8f685763038715837f8730b83cc137b1ee8a5ff618f->enter($__internal_bd2eb8e7d72034f608b8e8f685763038715837f8730b83cc137b1ee8a5ff618f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_wrapper"));

        // line 31
        echo "    ";
        $this->displayBlock('sonata_page_content', $context, $blocks);
        
        $__internal_bd2eb8e7d72034f608b8e8f685763038715837f8730b83cc137b1ee8a5ff618f->leave($__internal_bd2eb8e7d72034f608b8e8f685763038715837f8730b83cc137b1ee8a5ff618f_prof);

    }

    public function block_sonata_page_content($context, array $blocks = array())
    {
        $__internal_085f948fc40af4b7a43e62c7517ee7e1721d65930f03116c0a72f69c0dfcdba5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_085f948fc40af4b7a43e62c7517ee7e1721d65930f03116c0a72f69c0dfcdba5->enter($__internal_085f948fc40af4b7a43e62c7517ee7e1721d65930f03116c0a72f69c0dfcdba5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_page_content"));

        // line 32
        echo "        ";
        $this->displayParentBlock("sonata_page_content", $context, $blocks);
        echo "
    ";
        
        $__internal_085f948fc40af4b7a43e62c7517ee7e1721d65930f03116c0a72f69c0dfcdba5->leave($__internal_085f948fc40af4b7a43e62c7517ee7e1721d65930f03116c0a72f69c0dfcdba5_prof);

    }

    public function getTemplateName()
    {
        return "SonataAdminBundle::empty_layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  125 => 32,  112 => 31,  106 => 30,  89 => 20,  83 => 19,  72 => 17,  61 => 16,  50 => 15,  39 => 14,  24 => 12,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#

This file is part of the Sonata package.

(c) Thomas Rabaix <thomas.rabaix@sonata-project.org>

For the full copyright and license information, please view the LICENSE
file that was distributed with this source code.

#}

{% extends admin_pool.getTemplate('layout') %}

{% block sonata_header %}{% endblock %}
{% block sonata_left_side %}{% endblock %}
{% block sonata_nav %}{% endblock %}
{% block sonata_breadcrumb %}{% endblock %}

{% block stylesheets %}
    {{ parent() }}

    <style>
        .content {
            margin: 0px;
            padding: 0px;
        }
    </style>
{% endblock %}

{% block sonata_wrapper %}
    {% block sonata_page_content %}
        {{ parent() }}
    {% endblock %}
{% endblock %}
", "SonataAdminBundle::empty_layout.html.twig", "/home/ch/proyectos/php/obrasSociales/vendor/sonata-project/admin-bundle/src/Resources/views/empty_layout.html.twig");
    }
}

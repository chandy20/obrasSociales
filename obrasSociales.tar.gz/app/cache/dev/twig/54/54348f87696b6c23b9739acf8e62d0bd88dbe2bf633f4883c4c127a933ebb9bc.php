<?php

/* FOSUserBundle:Group:list.html.twig */
class __TwigTemplate_b05b91f0f67153f90fa20932a7025e75fda61d2ce6f9f357efcf2611ad7bde66 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Group:list.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_40da1a1b8493171ae7905ee944fc00d234b698bb3ecc3cc947d132eb4878fb06 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_40da1a1b8493171ae7905ee944fc00d234b698bb3ecc3cc947d132eb4878fb06->enter($__internal_40da1a1b8493171ae7905ee944fc00d234b698bb3ecc3cc947d132eb4878fb06_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:list.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_40da1a1b8493171ae7905ee944fc00d234b698bb3ecc3cc947d132eb4878fb06->leave($__internal_40da1a1b8493171ae7905ee944fc00d234b698bb3ecc3cc947d132eb4878fb06_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_585f9df562b26eb629625c4bc9ea542b20b3f0fc0e534ff9ccd1b38ab0af0777 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_585f9df562b26eb629625c4bc9ea542b20b3f0fc0e534ff9ccd1b38ab0af0777->enter($__internal_585f9df562b26eb629625c4bc9ea542b20b3f0fc0e534ff9ccd1b38ab0af0777_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Group:list_content.html.twig", "FOSUserBundle:Group:list.html.twig", 4)->display($context);
        
        $__internal_585f9df562b26eb629625c4bc9ea542b20b3f0fc0e534ff9ccd1b38ab0af0777->leave($__internal_585f9df562b26eb629625c4bc9ea542b20b3f0fc0e534ff9ccd1b38ab0af0777_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"FOSUserBundle::layout.html.twig\" %}

{% block fos_user_content %}
{% include \"FOSUserBundle:Group:list_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Group:list.html.twig", "/home/ch/proyectos/php/obrasSociales/vendor/friendsofsymfony/user-bundle/FOS/UserBundle/Resources/views/Group/list.html.twig");
    }
}

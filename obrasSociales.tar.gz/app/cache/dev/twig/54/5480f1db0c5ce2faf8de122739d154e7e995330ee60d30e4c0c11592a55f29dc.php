<?php

/* knp_menu_ordered.html.twig */
class __TwigTemplate_7c71d34f81e84f39cf1de72fedb24bfd3c51ae9405368700ecced3ce0ffad5d2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("knp_menu.html.twig", "knp_menu_ordered.html.twig", 1);
        $this->blocks = array(
            'list' => array($this, 'block_list'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "knp_menu.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ed4b984160b483772f04458bcdda5ddd63bf7ce180b627930d599ce45a469ced = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ed4b984160b483772f04458bcdda5ddd63bf7ce180b627930d599ce45a469ced->enter($__internal_ed4b984160b483772f04458bcdda5ddd63bf7ce180b627930d599ce45a469ced_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "knp_menu_ordered.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ed4b984160b483772f04458bcdda5ddd63bf7ce180b627930d599ce45a469ced->leave($__internal_ed4b984160b483772f04458bcdda5ddd63bf7ce180b627930d599ce45a469ced_prof);

    }

    // line 3
    public function block_list($context, array $blocks = array())
    {
        $__internal_3e3c3337e318b9c02a2e85525d1fe39fec62cca48bd3197f2a5c6bde92fff031 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3e3c3337e318b9c02a2e85525d1fe39fec62cca48bd3197f2a5c6bde92fff031->enter($__internal_3e3c3337e318b9c02a2e85525d1fe39fec62cca48bd3197f2a5c6bde92fff031_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "list"));

        // line 4
        $context["macros"] = $this->loadTemplate("knp_menu.html.twig", "knp_menu_ordered.html.twig", 4);
        // line 5
        echo "
";
        // line 6
        if ((($this->getAttribute(($context["item"] ?? $this->getContext($context, "item")), "hasChildren", array()) &&  !($this->getAttribute(($context["options"] ?? $this->getContext($context, "options")), "depth", array()) === 0)) && $this->getAttribute(($context["item"] ?? $this->getContext($context, "item")), "displayChildren", array()))) {
            // line 7
            echo "    <ol";
            echo $context["macros"]->getattributes(($context["listAttributes"] ?? $this->getContext($context, "listAttributes")));
            echo ">
        ";
            // line 8
            $this->displayBlock("children", $context, $blocks);
            echo "
    </ol>
";
        }
        
        $__internal_3e3c3337e318b9c02a2e85525d1fe39fec62cca48bd3197f2a5c6bde92fff031->leave($__internal_3e3c3337e318b9c02a2e85525d1fe39fec62cca48bd3197f2a5c6bde92fff031_prof);

    }

    public function getTemplateName()
    {
        return "knp_menu_ordered.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  52 => 8,  47 => 7,  45 => 6,  42 => 5,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'knp_menu.html.twig' %}

{% block list %}
{% import 'knp_menu.html.twig' as macros %}

{% if item.hasChildren and options.depth is not same as(0) and item.displayChildren %}
    <ol{{ macros.attributes(listAttributes) }}>
        {{ block('children') }}
    </ol>
{% endif %}
{% endblock %}
", "knp_menu_ordered.html.twig", "/home/ch/proyectos/php/obrasSociales/vendor/knplabs/knp-menu/src/Knp/Menu/Resources/views/knp_menu_ordered.html.twig");
    }
}

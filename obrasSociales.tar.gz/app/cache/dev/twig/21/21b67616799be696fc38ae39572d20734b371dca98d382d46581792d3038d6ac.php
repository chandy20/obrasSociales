<?php

/* SonataUserBundle:Admin/Security/Resetting:passwordAlreadyRequested.html.twig */
class __TwigTemplate_114a7052703bca1e58b367baeb1aaf70e0e008b0ea3ae27ebf3ff3cf56a8da03 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'sonata_nav' => array($this, 'block_sonata_nav'),
            'logo' => array($this, 'block_logo'),
            'sonata_left_side' => array($this, 'block_sonata_left_side'),
            'body_attributes' => array($this, 'block_body_attributes'),
            'sonata_wrapper' => array($this, 'block_sonata_wrapper'),
        );
    }

    protected function doGetParent(array $context)
    {
        // line 12
        return $this->loadTemplate(($context["base_template"] ?? $this->getContext($context, "base_template")), "SonataUserBundle:Admin/Security/Resetting:passwordAlreadyRequested.html.twig", 12);
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_846ea54a37b4c949dadb1711a6c61dd1cbb4d841a9d6008d9c154019ca44cedd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_846ea54a37b4c949dadb1711a6c61dd1cbb4d841a9d6008d9c154019ca44cedd->enter($__internal_846ea54a37b4c949dadb1711a6c61dd1cbb4d841a9d6008d9c154019ca44cedd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataUserBundle:Admin/Security/Resetting:passwordAlreadyRequested.html.twig"));

        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_846ea54a37b4c949dadb1711a6c61dd1cbb4d841a9d6008d9c154019ca44cedd->leave($__internal_846ea54a37b4c949dadb1711a6c61dd1cbb4d841a9d6008d9c154019ca44cedd_prof);

    }

    // line 14
    public function block_sonata_nav($context, array $blocks = array())
    {
        $__internal_487f34d58f4c56c9a62459556ca0a15a14cf88d5866656c08207f82672fb64dd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_487f34d58f4c56c9a62459556ca0a15a14cf88d5866656c08207f82672fb64dd->enter($__internal_487f34d58f4c56c9a62459556ca0a15a14cf88d5866656c08207f82672fb64dd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_nav"));

        
        $__internal_487f34d58f4c56c9a62459556ca0a15a14cf88d5866656c08207f82672fb64dd->leave($__internal_487f34d58f4c56c9a62459556ca0a15a14cf88d5866656c08207f82672fb64dd_prof);

    }

    // line 17
    public function block_logo($context, array $blocks = array())
    {
        $__internal_6665b09f3946369bbf97e0d662285846af0e86e4a78d30a3ab6cf9a4c078bdc4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6665b09f3946369bbf97e0d662285846af0e86e4a78d30a3ab6cf9a4c078bdc4->enter($__internal_6665b09f3946369bbf97e0d662285846af0e86e4a78d30a3ab6cf9a4c078bdc4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "logo"));

        
        $__internal_6665b09f3946369bbf97e0d662285846af0e86e4a78d30a3ab6cf9a4c078bdc4->leave($__internal_6665b09f3946369bbf97e0d662285846af0e86e4a78d30a3ab6cf9a4c078bdc4_prof);

    }

    // line 20
    public function block_sonata_left_side($context, array $blocks = array())
    {
        $__internal_8e673c7580c280769273a12923314ba761fbf9ea817e3116ae0c4e78479c77d4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8e673c7580c280769273a12923314ba761fbf9ea817e3116ae0c4e78479c77d4->enter($__internal_8e673c7580c280769273a12923314ba761fbf9ea817e3116ae0c4e78479c77d4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_left_side"));

        
        $__internal_8e673c7580c280769273a12923314ba761fbf9ea817e3116ae0c4e78479c77d4->leave($__internal_8e673c7580c280769273a12923314ba761fbf9ea817e3116ae0c4e78479c77d4_prof);

    }

    // line 23
    public function block_body_attributes($context, array $blocks = array())
    {
        $__internal_06625c4dbcc4365ef2081e891c59bc152ba6d55bf58222b2fbff0d8dadaca45c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_06625c4dbcc4365ef2081e891c59bc152ba6d55bf58222b2fbff0d8dadaca45c->enter($__internal_06625c4dbcc4365ef2081e891c59bc152ba6d55bf58222b2fbff0d8dadaca45c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_attributes"));

        echo "class=\"sonata-bc login-page\"";
        
        $__internal_06625c4dbcc4365ef2081e891c59bc152ba6d55bf58222b2fbff0d8dadaca45c->leave($__internal_06625c4dbcc4365ef2081e891c59bc152ba6d55bf58222b2fbff0d8dadaca45c_prof);

    }

    // line 25
    public function block_sonata_wrapper($context, array $blocks = array())
    {
        $__internal_5332f4323ff05e99ebd7064845ad940759b7470296899e0e50398c655195ee05 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5332f4323ff05e99ebd7064845ad940759b7470296899e0e50398c655195ee05->enter($__internal_5332f4323ff05e99ebd7064845ad940759b7470296899e0e50398c655195ee05_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_wrapper"));

        // line 26
        echo "
    <div class=\"login-box\">
        <div class=\"login-logo\">
            <a href=\"";
        // line 29
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("sonata_admin_dashboard");
        echo "\">
                ";
        // line 30
        if ((("single_text" == $this->getAttribute(($context["admin_pool"] ?? $this->getContext($context, "admin_pool")), "getOption", array(0 => "title_mode"), "method")) || ("both" == $this->getAttribute(($context["admin_pool"] ?? $this->getContext($context, "admin_pool")), "getOption", array(0 => "title_mode"), "method")))) {
            // line 31
            echo "                    <span>";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["admin_pool"] ?? $this->getContext($context, "admin_pool")), "title", array()), "html", null, true);
            echo "</span>
                ";
        }
        // line 33
        echo "            </a>
        </div>
        <div class=\"login-box-body\">
            <p>";
        // line 36
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("resetting.password_already_requested", array(), "FOSUserBundle"), "html", null, true);
        echo "</p>
            <a href=\"";
        // line 37
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("sonata_user_admin_security_login");
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("title_user_authentication", array(), "SonataUserBundle"), "html", null, true);
        echo "</a>
        </div>
    </div>

";
        
        $__internal_5332f4323ff05e99ebd7064845ad940759b7470296899e0e50398c655195ee05->leave($__internal_5332f4323ff05e99ebd7064845ad940759b7470296899e0e50398c655195ee05_prof);

    }

    public function getTemplateName()
    {
        return "SonataUserBundle:Admin/Security/Resetting:passwordAlreadyRequested.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  114 => 37,  110 => 36,  105 => 33,  99 => 31,  97 => 30,  93 => 29,  88 => 26,  82 => 25,  70 => 23,  59 => 20,  48 => 17,  37 => 14,  22 => 12,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#

This file is part of the Sonata package.

(c) Thomas Rabaix <thomas.rabaix@sonata-project.org>

For the full copyright and license information, please view the LICENSE
file that was distributed with this source code.

#}

{% extends base_template %}

{% block sonata_nav %}
{% endblock sonata_nav %}

{% block logo %}
{% endblock logo %}

{% block sonata_left_side %}
{% endblock sonata_left_side %}

{% block body_attributes %}class=\"sonata-bc login-page\"{% endblock %}

{% block sonata_wrapper %}

    <div class=\"login-box\">
        <div class=\"login-logo\">
            <a href=\"{{ path('sonata_admin_dashboard') }}\">
                {% if 'single_text' == admin_pool.getOption('title_mode') or 'both' == admin_pool.getOption('title_mode') %}
                    <span>{{ admin_pool.title }}</span>
                {% endif %}
            </a>
        </div>
        <div class=\"login-box-body\">
            <p>{{ 'resetting.password_already_requested'|trans({}, 'FOSUserBundle') }}</p>
            <a href=\"{{ path('sonata_user_admin_security_login') }}\">{{ 'title_user_authentication'|trans({}, 'SonataUserBundle') }}</a>
        </div>
    </div>

{% endblock sonata_wrapper %}
", "SonataUserBundle:Admin/Security/Resetting:passwordAlreadyRequested.html.twig", "/home/ch/proyectos/php/obrasSociales/vendor/sonata-project/user-bundle/src/Resources/views/Admin/Security/Resetting/passwordAlreadyRequested.html.twig");
    }
}

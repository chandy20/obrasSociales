<?php

/* FOSUserBundle::layout.html.twig */
class __TwigTemplate_dc6de874ffa7585f13631a7433fac6a61528ce15b06275720326a40b3e6f504e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1522916970620095ca6ee848196fbdfd76e31b0030f66f801831c4e37de8ac2c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1522916970620095ca6ee848196fbdfd76e31b0030f66f801831c4e37de8ac2c->enter($__internal_1522916970620095ca6ee848196fbdfd76e31b0030f66f801831c4e37de8ac2c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle::layout.html.twig"));

        // line 11
        echo "
<div>
    ";
        // line 13
        $this->displayBlock('fos_user_content', $context, $blocks);
        // line 15
        echo "</div>
";
        
        $__internal_1522916970620095ca6ee848196fbdfd76e31b0030f66f801831c4e37de8ac2c->leave($__internal_1522916970620095ca6ee848196fbdfd76e31b0030f66f801831c4e37de8ac2c_prof);

    }

    // line 13
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_f0889eb9b806f6bb6c518bb6d19df489f211e99a48e3918db153a4168b5bc840 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f0889eb9b806f6bb6c518bb6d19df489f211e99a48e3918db153a4168b5bc840->enter($__internal_f0889eb9b806f6bb6c518bb6d19df489f211e99a48e3918db153a4168b5bc840_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 14
        echo "    ";
        
        $__internal_f0889eb9b806f6bb6c518bb6d19df489f211e99a48e3918db153a4168b5bc840->leave($__internal_f0889eb9b806f6bb6c518bb6d19df489f211e99a48e3918db153a4168b5bc840_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle::layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  43 => 14,  37 => 13,  29 => 15,  27 => 13,  23 => 11,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#

This file is part of the Sonata package.

(c) Thomas Rabaix <thomas.rabaix@sonata-project.org>

For the full copyright and license information, please view the LICENSE
file that was distributed with this source code.

#}

<div>
    {% block fos_user_content %}
    {% endblock fos_user_content %}
</div>
", "FOSUserBundle::layout.html.twig", "/home/ch/proyectos/php/obrasSociales/vendor/sonata-project/user-bundle/src/Resources/views/layout.html.twig");
    }
}

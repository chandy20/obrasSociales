<?php

/* @Framework/Form/search_widget.html.php */
class __TwigTemplate_6256cdcdb71e8eb1562244c19b4a07bead1c6cb6637754dfc7a9faed2b971262 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_75f4023d7be1db12e2feb0d39966e28bfcaeaa64a5db55f9733fcfdc9f78a9ef = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_75f4023d7be1db12e2feb0d39966e28bfcaeaa64a5db55f9733fcfdc9f78a9ef->enter($__internal_75f4023d7be1db12e2feb0d39966e28bfcaeaa64a5db55f9733fcfdc9f78a9ef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/search_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'search')) ?>
";
        
        $__internal_75f4023d7be1db12e2feb0d39966e28bfcaeaa64a5db55f9733fcfdc9f78a9ef->leave($__internal_75f4023d7be1db12e2feb0d39966e28bfcaeaa64a5db55f9733fcfdc9f78a9ef_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/search_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'search')) ?>
", "@Framework/Form/search_widget.html.php", "/home/ch/proyectos/php/obrasSociales/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/search_widget.html.php");
    }
}

<?php

/* @Framework/Form/form_end.html.php */
class __TwigTemplate_c52c5798088924ff23e1574b3bf7dd1cd68f4409a491fd8fb7557d76c00ff898 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_29cd1e22830aeab9defa56d44481e985e1e40c8486fb6ca8f6999cc617bc7b31 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_29cd1e22830aeab9defa56d44481e985e1e40c8486fb6ca8f6999cc617bc7b31->enter($__internal_29cd1e22830aeab9defa56d44481e985e1e40c8486fb6ca8f6999cc617bc7b31_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_end.html.php"));

        // line 1
        echo "<?php if (!isset(\$render_rest) || \$render_rest): ?>
<?php echo \$view['form']->rest(\$form) ?>
<?php endif ?>
</form>
";
        
        $__internal_29cd1e22830aeab9defa56d44481e985e1e40c8486fb6ca8f6999cc617bc7b31->leave($__internal_29cd1e22830aeab9defa56d44481e985e1e40c8486fb6ca8f6999cc617bc7b31_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_end.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (!isset(\$render_rest) || \$render_rest): ?>
<?php echo \$view['form']->rest(\$form) ?>
<?php endif ?>
</form>
", "@Framework/Form/form_end.html.php", "/home/ch/proyectos/php/obrasSociales/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_end.html.php");
    }
}

<?php

/* FrontendBundle:Solicitudes:edit.html.twig */
class __TwigTemplate_811f3c0bb432fda60132c1399ebe01758210a05eaf6ed80730e80126fdc536c1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "FrontendBundle:Solicitudes:edit.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_06c5765052f4071c36a068405837168bec5beb5e1e7f5682af26590a10c38c14 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_06c5765052f4071c36a068405837168bec5beb5e1e7f5682af26590a10c38c14->enter($__internal_06c5765052f4071c36a068405837168bec5beb5e1e7f5682af26590a10c38c14_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FrontendBundle:Solicitudes:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_06c5765052f4071c36a068405837168bec5beb5e1e7f5682af26590a10c38c14->leave($__internal_06c5765052f4071c36a068405837168bec5beb5e1e7f5682af26590a10c38c14_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_0d393b8ea8bdc1852af635ec654c118a91bc7239cdfdbf39f123fdce1d353239 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0d393b8ea8bdc1852af635ec654c118a91bc7239cdfdbf39f123fdce1d353239->enter($__internal_0d393b8ea8bdc1852af635ec654c118a91bc7239cdfdbf39f123fdce1d353239_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "<div class=\"top-content\">
    <div class=\"container\" style=\"width: 90% !important\">
        <div class=\"row\">
            <div class=\"col-sm-8 col-sm-offset-2 text\">
                <h1>Edición  a <strong> de Solicitudes </strong> AOS </h1>
                <div class=\"description\">
                    <p>
                        Retorno a la Pagina Principal de Obras Sociales. 
                        ingresa en <a href=\"http://obrassocialespolicia.org/obras/\"><strong>Obras Sociales</strong></a>, Bienvenido Al Portal Obras Sociales!
                    </p>
                </div>
            </div>
        </div>
         </div>
                    
                  ";
        // line 19
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock(($context["edit_form"] ?? $this->getContext($context, "edit_form")), 'form');
        echo "
            </div>
      ";
        // line 21
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock(($context["edit_form"] ?? $this->getContext($context, "edit_form")), 'form_start');
        echo "
        <div class=\"row\">
            <div class=\"f1 col-md-20 form-box\">
                <h3><font color=\"#054e96\"> Formulario de Solicitudes</font></h3>
                
                <div align=\"float:center\"><img src=\"..\\bundles\\frontend\\images\\logo.png\" height=\"150\" width=\"180\"></div>
                <p><font color=\"#054e96\">Asociación Obras Sociales en Beneficio de la Policia Nacional</p>
                <hr style=\"border-color:grey;\">
               
               
                <div class=\"col-md-12\">
               
                        <div class=\"col-md-6\" >
                            ";
        // line 34
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "solicitudfecha", array()), 'label');
        echo "
                            ";
        // line 35
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "solicitudfecha", array()), 'errors');
        echo "
                            ";
        // line 36
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "solicitudfecha", array()), 'widget');
        echo "
                        </div>
                        <div class=\"col-md-6\"> 
                            ";
        // line 39
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "idseccional", array()), 'label');
        echo "
                            ";
        // line 40
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "idseccional", array()), 'errors');
        echo "
                            ";
        // line 41
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "idseccional", array()), 'widget');
        echo "
                        </div>
                        <div class=\"col-md-6\">
                            ";
        // line 44
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "idtiposolicitud", array()), 'label');
        echo "
                            ";
        // line 45
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "idtiposolicitud", array()), 'errors');
        echo "
                            ";
        // line 46
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "idtiposolicitud", array()), 'widget');
        echo "
                        </div>
                        
                        <div class=\"col-md-6\">
                            ";
        // line 50
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "solicitudcedulasolicita", array()), 'label');
        echo "
                            ";
        // line 51
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "solicitudcedulasolicita", array()), 'errors');
        echo "
                            ";
        // line 52
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "solicitudcedulasolicita", array()), 'widget');
        echo "
                        </div>
                        <div class=\"col-md-6\">
                            ";
        // line 55
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "idparentesco", array()), 'label');
        echo "
                            ";
        // line 56
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "idparentesco", array()), 'errors');
        echo "
                            ";
        // line 57
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "idparentesco", array()), 'widget');
        echo "
                        </div>
                        <div class=\"col-md-6\">
                            ";
        // line 60
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "solicitudnombresolicita", array()), 'label');
        echo "
                            ";
        // line 61
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "solicitudnombresolicita", array()), 'errors');
        echo "
                            ";
        // line 62
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "solicitudnombresolicita", array()), 'widget');
        echo "
                        </div>
                </div>
               <div class=\"col-md-12\">
                        <hr style=\"border-color:white;\">
                        <hr style=\"border-color:white;\">
                        <hr style=\"border-color:white;\">
                        <h4>INFORMACION FUNCIONARIO POLICIAL</h4>
                        <hr style=\"border-color:white\"></div>

                <div class=\"col-md-12\">
                        <div class=\"col-md-6\" >
                            ";
        // line 74
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "solicitudcedulafuncionario", array()), 'label');
        echo "
                            ";
        // line 75
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "solicitudcedulafuncionario", array()), 'errors');
        echo "
                            ";
        // line 76
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "solicitudcedulafuncionario", array()), 'widget');
        echo "
                        </div>
                        <div class=\"col-md-6\">
                            ";
        // line 79
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "idgrado", array()), 'label');
        echo "
                            ";
        // line 80
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "idgrado", array()), 'errors');
        echo "
                            ";
        // line 81
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "idgrado", array()), 'widget');
        echo "
                        </div>
                        <div class=\"col-md-12\">
                            ";
        // line 84
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "solicitudnombrefuncionario", array()), 'label');
        echo "
                            ";
        // line 85
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "solicitudnombrefuncionario", array()), 'errors');
        echo "
                            ";
        // line 86
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "solicitudnombrefuncionario", array()), 'widget');
        echo "
                        </div>
                        <div class=\"col-md-6\">
                            ";
        // line 89
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "solicituddireccionfuncionario", array()), 'label');
        echo "
                            ";
        // line 90
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "solicituddireccionfuncionario", array()), 'errors');
        echo "
                            ";
        // line 91
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "solicituddireccionfuncionario", array()), 'widget');
        echo "
                        </div>
                        <div class=\"col-md-6\">
                            ";
        // line 94
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "solicitudtelefonosfuncionario", array()), 'label');
        echo "
                            ";
        // line 95
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "solicitudtelefonosfuncionario", array()), 'errors');
        echo "
                            ";
        // line 96
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "solicitudtelefonosfuncionario", array()), 'widget');
        echo "
                        </div>    
                </div>

                <div class=\"col-md-12\">   
                        <div class=\"col-md-12\">  
                        <hr style=\"border-color:white;\">
                        <hr style=\"border-color:white;\">
                        <hr style=\"border-color:white;\">         
                        <h4>DESCRIPCION DE LA SOLICITUD</h4></div>

                        <div class=\"col-md-6\">
                            ";
        // line 108
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "idprogramas", array()), 'label');
        echo "
                            ";
        // line 109
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "idprogramas", array()), 'errors');
        echo "
                            ";
        // line 110
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "idprogramas", array()), 'widget');
        echo "
                        </div>
                        
                        <div class=\"col-md-6\">
                            ";
        // line 114
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "solicituddescripcion", array()), 'label');
        echo "
                            ";
        // line 115
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "solicituddescripcion", array()), 'errors');
        echo "
                            ";
        // line 116
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "solicituddescripcion", array()), 'widget');
        echo "
                        </div>

                        <div class=\"col-md-12\">
                         <div class=\"prueba1\">
                         <hr style=\"border-color:white;\">
                         <hr style=\"border-color:white;\">
                        <h4>INFORMACION FAMILIAR Y PERSONAL</h4></div></div>
                
                        <div class=\"col-md-6 prueba1\">
                            ";
        // line 126
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "idestadocivil", array()), 'label');
        echo "
                            ";
        // line 127
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "idestadocivil", array()), 'errors');
        echo "
                            ";
        // line 128
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "idestadocivil", array()), 'widget');
        echo "
                        </div>
                        <div class=\"col-md-6 prueba1\">
                            ";
        // line 131
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "idingreso", array()), 'label');
        echo "
                            ";
        // line 132
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "idingreso", array()), 'errors');
        echo "
                            ";
        // line 133
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "idingreso", array()), 'widget');
        echo "
                        </div>
                        <div class=\"col-md-6 prueba1\">
                            ";
        // line 136
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "idpersonacargo", array()), 'label');
        echo "
                            ";
        // line 137
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "idpersonacargo", array()), 'errors');
        echo "
                            ";
        // line 138
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "idpersonacargo", array()), 'widget');
        echo "
                        </div>
                        <div class=\"col-md-6 prueba1\">
                            ";
        // line 141
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "idsituacionvivienda", array()), 'label');
        echo "
                            ";
        // line 142
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "idsituacionvivienda", array()), 'errors');
        echo "
                            ";
        // line 143
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "idsituacionvivienda", array()), 'widget');
        echo "
                        </div>
                        <div class=\"col-md-6 prueba1\">
                            ";
        // line 146
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "idmotivodeuda", array()), 'label');
        echo "
                            ";
        // line 147
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "idmotivodeuda", array()), 'errors');
        echo "
                            ";
        // line 148
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "idmotivodeuda", array()), 'widget');
        echo "
                        </div>
                        <div class=\"col-md-6 prueba1\">
                            ";
        // line 151
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "cantidadesbeneficio", array()), 'label');
        echo "
                            ";
        // line 152
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "cantidadesbeneficio", array()), 'errors');
        echo "
                            ";
        // line 153
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "cantidadesbeneficio", array()), 'widget');
        echo "
                        </div>
                        <div class=\"col-md-6 prueba1\">
                            ";
        // line 156
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "idconceptovisita", array()), 'label');
        echo "
                            ";
        // line 157
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "idconceptovisita", array()), 'errors');
        echo "
                            ";
        // line 158
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "idconceptovisita", array()), 'widget');
        echo "
                        </div>
                        <div class=\"col-md-6 prueba1\">
                            ";
        // line 161
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "idafiliadodibie", array()), 'label');
        echo "
                            ";
        // line 162
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "idafiliadodibie", array()), 'errors');
        echo "
                            ";
        // line 163
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "idafiliadodibie", array()), 'widget');
        echo "
                        </div>

                        <div class=\"col-md-12\">
                        <div class=\"prueba\">
                        <hr style=\"border-color:white;\">
                        <hr style=\"border-color:white;\">
                        <h4>INFORMACION INSTITUCIONAL</h4></div></div>
             
                        <div class=\"col-md-6 prueba\">
                            ";
        // line 173
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "idpoblacionbeneficia", array()), 'label');
        echo "
                            ";
        // line 174
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "idpoblacionbeneficia", array()), 'errors');
        echo "
                            ";
        // line 175
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "idpoblacionbeneficia", array()), 'widget');
        echo "
                        </div>
                        <div class=\"col-md-6 prueba\">
                            ";
        // line 178
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "idviabilidadplaneacion", array()), 'label');
        echo "
                            ";
        // line 179
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "idviabilidadplaneacion", array()), 'errors');
        echo "
                            ";
        // line 180
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "idviabilidadplaneacion", array()), 'widget');
        echo "
                        </div>
                        <div class=\"col-md-6 prueba\">
                            ";
        // line 183
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "idzonaubicacion", array()), 'label');
        echo "
                            ";
        // line 184
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "idzonaubicacion", array()), 'errors');
        echo "
                            ";
        // line 185
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "idzonaubicacion", array()), 'widget');
        echo "
                        </div>
                        <div class=\"col-md-6 prueba\">
                            ";
        // line 188
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "idcantidadesbeneficioinst", array()), 'label');
        echo "
                            ";
        // line 189
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "idcantidadesbeneficioinst", array()), 'errors');
        echo "
                            ";
        // line 190
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["edit_form"] ?? $this->getContext($context, "edit_form")), "idcantidadesbeneficioinst", array()), 'widget');
        echo "
                            <hr style=\"border-color:white;\">
                        </div>
               
        </div>
        ";
        // line 195
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock(($context["edit_form"] ?? $this->getContext($context, "edit_form")), 'form_end');
        echo "
    </div>
    <ul class=\"record_actions\">
       
    </ul>
</div>
";
        
        $__internal_0d393b8ea8bdc1852af635ec654c118a91bc7239cdfdbf39f123fdce1d353239->leave($__internal_0d393b8ea8bdc1852af635ec654c118a91bc7239cdfdbf39f123fdce1d353239_prof);

    }

    public function getTemplateName()
    {
        return "FrontendBundle:Solicitudes:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  464 => 195,  456 => 190,  452 => 189,  448 => 188,  442 => 185,  438 => 184,  434 => 183,  428 => 180,  424 => 179,  420 => 178,  414 => 175,  410 => 174,  406 => 173,  393 => 163,  389 => 162,  385 => 161,  379 => 158,  375 => 157,  371 => 156,  365 => 153,  361 => 152,  357 => 151,  351 => 148,  347 => 147,  343 => 146,  337 => 143,  333 => 142,  329 => 141,  323 => 138,  319 => 137,  315 => 136,  309 => 133,  305 => 132,  301 => 131,  295 => 128,  291 => 127,  287 => 126,  274 => 116,  270 => 115,  266 => 114,  259 => 110,  255 => 109,  251 => 108,  236 => 96,  232 => 95,  228 => 94,  222 => 91,  218 => 90,  214 => 89,  208 => 86,  204 => 85,  200 => 84,  194 => 81,  190 => 80,  186 => 79,  180 => 76,  176 => 75,  172 => 74,  157 => 62,  153 => 61,  149 => 60,  143 => 57,  139 => 56,  135 => 55,  129 => 52,  125 => 51,  121 => 50,  114 => 46,  110 => 45,  106 => 44,  100 => 41,  96 => 40,  92 => 39,  86 => 36,  82 => 35,  78 => 34,  62 => 21,  57 => 19,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '::base.html.twig' %}

{% block body -%}
<div class=\"top-content\">
    <div class=\"container\" style=\"width: 90% !important\">
        <div class=\"row\">
            <div class=\"col-sm-8 col-sm-offset-2 text\">
                <h1>Edición  a <strong> de Solicitudes </strong> AOS </h1>
                <div class=\"description\">
                    <p>
                        Retorno a la Pagina Principal de Obras Sociales. 
                        ingresa en <a href=\"http://obrassocialespolicia.org/obras/\"><strong>Obras Sociales</strong></a>, Bienvenido Al Portal Obras Sociales!
                    </p>
                </div>
            </div>
        </div>
         </div>
                    
                  {{ form(edit_form) }}
            </div>
      {{ form_start(edit_form) }}
        <div class=\"row\">
            <div class=\"f1 col-md-20 form-box\">
                <h3><font color=\"#054e96\"> Formulario de Solicitudes</font></h3>
                
                <div align=\"float:center\"><img src=\"..\\bundles\\frontend\\images\\logo.png\" height=\"150\" width=\"180\"></div>
                <p><font color=\"#054e96\">Asociación Obras Sociales en Beneficio de la Policia Nacional</p>
                <hr style=\"border-color:grey;\">
               
               
                <div class=\"col-md-12\">
               
                        <div class=\"col-md-6\" >
                            {{ form_label(edit_form.solicitudfecha) }}
                            {{ form_errors(edit_form.solicitudfecha) }}
                            {{ form_widget(edit_form.solicitudfecha) }}
                        </div>
                        <div class=\"col-md-6\"> 
                            {{ form_label(edit_form.idseccional) }}
                            {{ form_errors(edit_form.idseccional) }}
                            {{ form_widget(edit_form.idseccional) }}
                        </div>
                        <div class=\"col-md-6\">
                            {{ form_label(edit_form.idtiposolicitud) }}
                            {{ form_errors(edit_form.idtiposolicitud) }}
                            {{ form_widget(edit_form.idtiposolicitud) }}
                        </div>
                        
                        <div class=\"col-md-6\">
                            {{ form_label(edit_form.solicitudcedulasolicita) }}
                            {{ form_errors(edit_form.solicitudcedulasolicita) }}
                            {{ form_widget(edit_form.solicitudcedulasolicita) }}
                        </div>
                        <div class=\"col-md-6\">
                            {{ form_label(edit_form.idparentesco) }}
                            {{ form_errors(edit_form.idparentesco) }}
                            {{ form_widget(edit_form.idparentesco) }}
                        </div>
                        <div class=\"col-md-6\">
                            {{ form_label(edit_form.solicitudnombresolicita) }}
                            {{ form_errors(edit_form.solicitudnombresolicita) }}
                            {{ form_widget(edit_form.solicitudnombresolicita) }}
                        </div>
                </div>
               <div class=\"col-md-12\">
                        <hr style=\"border-color:white;\">
                        <hr style=\"border-color:white;\">
                        <hr style=\"border-color:white;\">
                        <h4>INFORMACION FUNCIONARIO POLICIAL</h4>
                        <hr style=\"border-color:white\"></div>

                <div class=\"col-md-12\">
                        <div class=\"col-md-6\" >
                            {{ form_label(edit_form.solicitudcedulafuncionario) }}
                            {{ form_errors(edit_form.solicitudcedulafuncionario) }}
                            {{ form_widget(edit_form.solicitudcedulafuncionario) }}
                        </div>
                        <div class=\"col-md-6\">
                            {{ form_label(edit_form.idgrado) }}
                            {{ form_errors(edit_form.idgrado) }}
                            {{ form_widget(edit_form.idgrado) }}
                        </div>
                        <div class=\"col-md-12\">
                            {{ form_label(edit_form.solicitudnombrefuncionario) }}
                            {{ form_errors(edit_form.solicitudnombrefuncionario) }}
                            {{ form_widget(edit_form.solicitudnombrefuncionario) }}
                        </div>
                        <div class=\"col-md-6\">
                            {{ form_label(edit_form.solicituddireccionfuncionario) }}
                            {{ form_errors(edit_form.solicituddireccionfuncionario) }}
                            {{ form_widget(edit_form.solicituddireccionfuncionario) }}
                        </div>
                        <div class=\"col-md-6\">
                            {{ form_label(edit_form.solicitudtelefonosfuncionario) }}
                            {{ form_errors(edit_form.solicitudtelefonosfuncionario) }}
                            {{ form_widget(edit_form.solicitudtelefonosfuncionario) }}
                        </div>    
                </div>

                <div class=\"col-md-12\">   
                        <div class=\"col-md-12\">  
                        <hr style=\"border-color:white;\">
                        <hr style=\"border-color:white;\">
                        <hr style=\"border-color:white;\">         
                        <h4>DESCRIPCION DE LA SOLICITUD</h4></div>

                        <div class=\"col-md-6\">
                            {{ form_label(edit_form.idprogramas) }}
                            {{ form_errors(edit_form.idprogramas) }}
                            {{ form_widget(edit_form.idprogramas) }}
                        </div>
                        
                        <div class=\"col-md-6\">
                            {{ form_label(edit_form.solicituddescripcion) }}
                            {{ form_errors(edit_form.solicituddescripcion) }}
                            {{ form_widget(edit_form.solicituddescripcion) }}
                        </div>

                        <div class=\"col-md-12\">
                         <div class=\"prueba1\">
                         <hr style=\"border-color:white;\">
                         <hr style=\"border-color:white;\">
                        <h4>INFORMACION FAMILIAR Y PERSONAL</h4></div></div>
                
                        <div class=\"col-md-6 prueba1\">
                            {{ form_label(edit_form.idestadocivil) }}
                            {{ form_errors(edit_form.idestadocivil) }}
                            {{ form_widget(edit_form.idestadocivil) }}
                        </div>
                        <div class=\"col-md-6 prueba1\">
                            {{ form_label(edit_form.idingreso) }}
                            {{ form_errors(edit_form.idingreso) }}
                            {{ form_widget(edit_form.idingreso) }}
                        </div>
                        <div class=\"col-md-6 prueba1\">
                            {{ form_label(edit_form.idpersonacargo) }}
                            {{ form_errors(edit_form.idpersonacargo) }}
                            {{ form_widget(edit_form.idpersonacargo) }}
                        </div>
                        <div class=\"col-md-6 prueba1\">
                            {{ form_label(edit_form.idsituacionvivienda) }}
                            {{ form_errors(edit_form.idsituacionvivienda) }}
                            {{ form_widget(edit_form.idsituacionvivienda) }}
                        </div>
                        <div class=\"col-md-6 prueba1\">
                            {{ form_label(edit_form.idmotivodeuda) }}
                            {{ form_errors(edit_form.idmotivodeuda) }}
                            {{ form_widget(edit_form.idmotivodeuda) }}
                        </div>
                        <div class=\"col-md-6 prueba1\">
                            {{ form_label(edit_form.cantidadesbeneficio) }}
                            {{ form_errors(edit_form.cantidadesbeneficio) }}
                            {{ form_widget(edit_form.cantidadesbeneficio) }}
                        </div>
                        <div class=\"col-md-6 prueba1\">
                            {{ form_label(edit_form.idconceptovisita) }}
                            {{ form_errors(edit_form.idconceptovisita) }}
                            {{ form_widget(edit_form.idconceptovisita) }}
                        </div>
                        <div class=\"col-md-6 prueba1\">
                            {{ form_label(edit_form.idafiliadodibie) }}
                            {{ form_errors(edit_form.idafiliadodibie) }}
                            {{ form_widget(edit_form.idafiliadodibie) }}
                        </div>

                        <div class=\"col-md-12\">
                        <div class=\"prueba\">
                        <hr style=\"border-color:white;\">
                        <hr style=\"border-color:white;\">
                        <h4>INFORMACION INSTITUCIONAL</h4></div></div>
             
                        <div class=\"col-md-6 prueba\">
                            {{ form_label(edit_form.idpoblacionbeneficia) }}
                            {{ form_errors(edit_form.idpoblacionbeneficia) }}
                            {{ form_widget(edit_form.idpoblacionbeneficia) }}
                        </div>
                        <div class=\"col-md-6 prueba\">
                            {{ form_label(edit_form.idviabilidadplaneacion) }}
                            {{ form_errors(edit_form.idviabilidadplaneacion) }}
                            {{ form_widget(edit_form.idviabilidadplaneacion) }}
                        </div>
                        <div class=\"col-md-6 prueba\">
                            {{ form_label(edit_form.idzonaubicacion) }}
                            {{ form_errors(edit_form.idzonaubicacion) }}
                            {{ form_widget(edit_form.idzonaubicacion) }}
                        </div>
                        <div class=\"col-md-6 prueba\">
                            {{ form_label(edit_form.idcantidadesbeneficioinst) }}
                            {{ form_errors(edit_form.idcantidadesbeneficioinst) }}
                            {{ form_widget(edit_form.idcantidadesbeneficioinst) }}
                            <hr style=\"border-color:white;\">
                        </div>
               
        </div>
        {{ form_end(edit_form) }}
    </div>
    <ul class=\"record_actions\">
       
    </ul>
</div>
{% endblock %}
", "FrontendBundle:Solicitudes:edit.html.twig", "/home/ch/proyectos/php/obrasSociales/src/FrontendBundle/Resources/views/Solicitudes/edit.html.twig");
    }
}

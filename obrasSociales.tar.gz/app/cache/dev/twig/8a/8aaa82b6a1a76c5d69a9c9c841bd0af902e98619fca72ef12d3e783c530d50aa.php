<?php

/* FOSUserBundle:Group:show.html.twig */
class __TwigTemplate_8e775b664acf2e5bb03f9f73d5ef7cd988c1242ce953c4083168d5cba89e9993 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Group:show.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0afcfe71b7c852595e0a604a9b81030a94c6d205324d332b26dd292af74dcdad = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0afcfe71b7c852595e0a604a9b81030a94c6d205324d332b26dd292af74dcdad->enter($__internal_0afcfe71b7c852595e0a604a9b81030a94c6d205324d332b26dd292af74dcdad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_0afcfe71b7c852595e0a604a9b81030a94c6d205324d332b26dd292af74dcdad->leave($__internal_0afcfe71b7c852595e0a604a9b81030a94c6d205324d332b26dd292af74dcdad_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_f46547680bb24827fe3d6f25349fb1f0d322c10a86fb2a839cd90253f463cc3e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f46547680bb24827fe3d6f25349fb1f0d322c10a86fb2a839cd90253f463cc3e->enter($__internal_f46547680bb24827fe3d6f25349fb1f0d322c10a86fb2a839cd90253f463cc3e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Group:show_content.html.twig", "FOSUserBundle:Group:show.html.twig", 4)->display($context);
        
        $__internal_f46547680bb24827fe3d6f25349fb1f0d322c10a86fb2a839cd90253f463cc3e->leave($__internal_f46547680bb24827fe3d6f25349fb1f0d322c10a86fb2a839cd90253f463cc3e_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"FOSUserBundle::layout.html.twig\" %}

{% block fos_user_content %}
{% include \"FOSUserBundle:Group:show_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Group:show.html.twig", "/home/ch/proyectos/php/obrasSociales/vendor/friendsofsymfony/user-bundle/FOS/UserBundle/Resources/views/Group/show.html.twig");
    }
}

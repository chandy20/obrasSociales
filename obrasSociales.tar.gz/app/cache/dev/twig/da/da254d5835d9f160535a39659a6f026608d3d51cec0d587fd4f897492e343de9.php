<?php

/* @SonataAdmin/CRUD/base_edit.html.twig */
class __TwigTemplate_83d2b787488c39aaf540663674a32b36170334263ac827883141cd79405b3840 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $_trait_0 = $this->loadTemplate("@SonataAdmin/CRUD/base_edit_form.html.twig", "@SonataAdmin/CRUD/base_edit.html.twig", 33);
        // line 33
        if (!$_trait_0->isTraitable()) {
            throw new Twig_Error_Runtime('Template "'."@SonataAdmin/CRUD/base_edit_form.html.twig".'" cannot be used as a trait.');
        }
        $_trait_0_blocks = $_trait_0->getBlocks();

        if (!isset($_trait_0_blocks["form"])) {
            throw new Twig_Error_Runtime(sprintf('Block "form" is not defined in trait "@SonataAdmin/CRUD/base_edit_form.html.twig".'));
        }

        $_trait_0_blocks["parentForm"] = $_trait_0_blocks["form"]; unset($_trait_0_blocks["form"]);

        $this->traits = $_trait_0_blocks;

        $this->blocks = array_merge(
            $this->traits,
            array(
                'title' => array($this, 'block_title'),
                'navbar_title' => array($this, 'block_navbar_title'),
                'actions' => array($this, 'block_actions'),
                'tab_menu' => array($this, 'block_tab_menu'),
                'form' => array($this, 'block_form'),
            )
        );
    }

    protected function doGetParent(array $context)
    {
        // line 12
        return $this->loadTemplate(($context["base_template"] ?? $this->getContext($context, "base_template")), "@SonataAdmin/CRUD/base_edit.html.twig", 12);
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bce9bb3769e363ce263ce8f950affdaf8c6c1c6025d0d8fc94d7c8fbd2652bbd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bce9bb3769e363ce263ce8f950affdaf8c6c1c6025d0d8fc94d7c8fbd2652bbd->enter($__internal_bce9bb3769e363ce263ce8f950affdaf8c6c1c6025d0d8fc94d7c8fbd2652bbd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@SonataAdmin/CRUD/base_edit.html.twig"));

        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_bce9bb3769e363ce263ce8f950affdaf8c6c1c6025d0d8fc94d7c8fbd2652bbd->leave($__internal_bce9bb3769e363ce263ce8f950affdaf8c6c1c6025d0d8fc94d7c8fbd2652bbd_prof);

    }

    // line 14
    public function block_title($context, array $blocks = array())
    {
        $__internal_5c580f3b2699873605a31dcd385337994007db3aa5145cb171d073e03eb99156 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5c580f3b2699873605a31dcd385337994007db3aa5145cb171d073e03eb99156->enter($__internal_5c580f3b2699873605a31dcd385337994007db3aa5145cb171d073e03eb99156_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 15
        echo "    ";
        // line 16
        echo "    ";
        if ( !(null === ((array_key_exists("objectId", $context)) ? (_twig_default_filter(($context["objectId"] ?? $this->getContext($context, "objectId")), $this->getAttribute(($context["admin"] ?? $this->getContext($context, "admin")), "id", array(0 => ($context["object"] ?? $this->getContext($context, "object"))), "method"))) : ($this->getAttribute(($context["admin"] ?? $this->getContext($context, "admin")), "id", array(0 => ($context["object"] ?? $this->getContext($context, "object"))), "method"))))) {
            // line 17
            echo "        ";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("title_edit", array("%name%" => twig_truncate_filter($this->env, $this->getAttribute(($context["admin"] ?? $this->getContext($context, "admin")), "toString", array(0 => ($context["object"] ?? $this->getContext($context, "object"))), "method"), 15)), "SonataAdminBundle"), "html", null, true);
            echo "
    ";
        } else {
            // line 19
            echo "        ";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("title_create", array(), "SonataAdminBundle"), "html", null, true);
            echo "
    ";
        }
        
        $__internal_5c580f3b2699873605a31dcd385337994007db3aa5145cb171d073e03eb99156->leave($__internal_5c580f3b2699873605a31dcd385337994007db3aa5145cb171d073e03eb99156_prof);

    }

    // line 23
    public function block_navbar_title($context, array $blocks = array())
    {
        $__internal_05abde1a84641c00edb5fd36c5a18ae59e0bc5a7176ecc714f596e5b208f2e4b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_05abde1a84641c00edb5fd36c5a18ae59e0bc5a7176ecc714f596e5b208f2e4b->enter($__internal_05abde1a84641c00edb5fd36c5a18ae59e0bc5a7176ecc714f596e5b208f2e4b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "navbar_title"));

        // line 24
        echo "    ";
        $this->displayBlock("title", $context, $blocks);
        echo "
";
        
        $__internal_05abde1a84641c00edb5fd36c5a18ae59e0bc5a7176ecc714f596e5b208f2e4b->leave($__internal_05abde1a84641c00edb5fd36c5a18ae59e0bc5a7176ecc714f596e5b208f2e4b_prof);

    }

    // line 27
    public function block_actions($context, array $blocks = array())
    {
        $__internal_884311c8de78f7499392535ccb0df9495b8daa22db6c62d4ca2694e200aa0c47 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_884311c8de78f7499392535ccb0df9495b8daa22db6c62d4ca2694e200aa0c47->enter($__internal_884311c8de78f7499392535ccb0df9495b8daa22db6c62d4ca2694e200aa0c47_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "actions"));

        // line 28
        $this->loadTemplate("@SonataAdmin/CRUD/action_buttons.html.twig", "@SonataAdmin/CRUD/base_edit.html.twig", 28)->display($context);
        
        $__internal_884311c8de78f7499392535ccb0df9495b8daa22db6c62d4ca2694e200aa0c47->leave($__internal_884311c8de78f7499392535ccb0df9495b8daa22db6c62d4ca2694e200aa0c47_prof);

    }

    // line 31
    public function block_tab_menu($context, array $blocks = array())
    {
        $__internal_407f1b5a006803acc5e91b9a1c367af440ec8a5ca97c552d0b6b851100ea22b1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_407f1b5a006803acc5e91b9a1c367af440ec8a5ca97c552d0b6b851100ea22b1->enter($__internal_407f1b5a006803acc5e91b9a1c367af440ec8a5ca97c552d0b6b851100ea22b1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "tab_menu"));

        echo $this->env->getExtension('Knp\Menu\Twig\MenuExtension')->render($this->getAttribute(($context["admin"] ?? $this->getContext($context, "admin")), "sidemenu", array(0 => ($context["action"] ?? $this->getContext($context, "action"))), "method"), array("currentClass" => "active", "template" => $this->getAttribute($this->getAttribute(($context["sonata_admin"] ?? $this->getContext($context, "sonata_admin")), "adminPool", array()), "getTemplate", array(0 => "tab_menu_template"), "method")), "twig");
        
        $__internal_407f1b5a006803acc5e91b9a1c367af440ec8a5ca97c552d0b6b851100ea22b1->leave($__internal_407f1b5a006803acc5e91b9a1c367af440ec8a5ca97c552d0b6b851100ea22b1_prof);

    }

    // line 35
    public function block_form($context, array $blocks = array())
    {
        $__internal_f67c552ed8f930d9d77d069f8d33cc85c7647b7d0132adcec77e76e23ddfa998 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f67c552ed8f930d9d77d069f8d33cc85c7647b7d0132adcec77e76e23ddfa998->enter($__internal_f67c552ed8f930d9d77d069f8d33cc85c7647b7d0132adcec77e76e23ddfa998_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form"));

        // line 36
        echo "    ";
        $this->displayBlock("parentForm", $context, $blocks);
        echo "
";
        
        $__internal_f67c552ed8f930d9d77d069f8d33cc85c7647b7d0132adcec77e76e23ddfa998->leave($__internal_f67c552ed8f930d9d77d069f8d33cc85c7647b7d0132adcec77e76e23ddfa998_prof);

    }

    public function getTemplateName()
    {
        return "@SonataAdmin/CRUD/base_edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  130 => 36,  124 => 35,  112 => 31,  105 => 28,  99 => 27,  89 => 24,  83 => 23,  72 => 19,  66 => 17,  63 => 16,  61 => 15,  55 => 14,  40 => 12,  12 => 33,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#

This file is part of the Sonata package.

(c) Thomas Rabaix <thomas.rabaix@sonata-project.org>

For the full copyright and license information, please view the LICENSE
file that was distributed with this source code.

#}

{% extends base_template %}

{% block title %}
    {# NEXT_MAJOR: remove default filter #}
    {% if objectId|default(admin.id(object)) is not null %}
        {{ \"title_edit\"|trans({'%name%': admin.toString(object)|truncate(15) }, 'SonataAdminBundle') }}
    {% else %}
        {{ \"title_create\"|trans({}, 'SonataAdminBundle') }}
    {% endif %}
{% endblock %}

{% block navbar_title %}
    {{ block('title') }}
{% endblock %}

{%- block actions -%}
    {% include '@SonataAdmin/CRUD/action_buttons.html.twig' %}
{%- endblock -%}

{% block tab_menu %}{{ knp_menu_render(admin.sidemenu(action), {'currentClass' : 'active', 'template': sonata_admin.adminPool.getTemplate('tab_menu_template')}, 'twig') }}{% endblock %}

{% use '@SonataAdmin/CRUD/base_edit_form.html.twig' with form as parentForm %}

{% block form %}
    {{ block('parentForm') }}
{% endblock %}
", "@SonataAdmin/CRUD/base_edit.html.twig", "/home/ch/proyectos/php/obrasSociales/vendor/sonata-project/admin-bundle/src/Resources/views/CRUD/base_edit.html.twig");
    }
}

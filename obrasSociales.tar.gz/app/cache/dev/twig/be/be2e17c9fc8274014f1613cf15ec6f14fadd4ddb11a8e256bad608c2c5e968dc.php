<?php

/* knp_menu_base.html.twig */
class __TwigTemplate_1ce888664aae8ec4c33075c2da56fca5f518e6fccccd7df0d1789a5e23c62ff0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2fd604832ae152fa4685a969f84de850e2cfbe654e1693cfeb0c489b16cc84d6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2fd604832ae152fa4685a969f84de850e2cfbe654e1693cfeb0c489b16cc84d6->enter($__internal_2fd604832ae152fa4685a969f84de850e2cfbe654e1693cfeb0c489b16cc84d6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "knp_menu_base.html.twig"));

        // line 1
        if ($this->getAttribute(($context["options"] ?? $this->getContext($context, "options")), "compressed", array())) {
            $this->displayBlock("compressed_root", $context, $blocks);
        } else {
            $this->displayBlock("root", $context, $blocks);
        }
        
        $__internal_2fd604832ae152fa4685a969f84de850e2cfbe654e1693cfeb0c489b16cc84d6->leave($__internal_2fd604832ae152fa4685a969f84de850e2cfbe654e1693cfeb0c489b16cc84d6_prof);

    }

    public function getTemplateName()
    {
        return "knp_menu_base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% if options.compressed %}{{ block('compressed_root') }}{% else %}{{ block('root') }}{% endif %}
", "knp_menu_base.html.twig", "/home/ch/proyectos/php/obrasSociales/vendor/knplabs/knp-menu/src/Knp/Menu/Resources/views/knp_menu_base.html.twig");
    }
}

<?php

/* SonataAdminBundle:CRUD:acl.html.twig */
class __TwigTemplate_4d9d2176e2a9110bd09d288c64ec4826ee2f2cc9840bb2d05b070f2e88cc4b79 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 12
        $this->parent = $this->loadTemplate("@SonataAdmin/CRUD/base_acl.html.twig", "SonataAdminBundle:CRUD:acl.html.twig", 12);
        $this->blocks = array(
        );
    }

    protected function doGetParent(array $context)
    {
        return "@SonataAdmin/CRUD/base_acl.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_240f57c1aa99d59932448102483dbafe1d43c69f8d511a46e8f29fb610efeccb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_240f57c1aa99d59932448102483dbafe1d43c69f8d511a46e8f29fb610efeccb->enter($__internal_240f57c1aa99d59932448102483dbafe1d43c69f8d511a46e8f29fb610efeccb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataAdminBundle:CRUD:acl.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_240f57c1aa99d59932448102483dbafe1d43c69f8d511a46e8f29fb610efeccb->leave($__internal_240f57c1aa99d59932448102483dbafe1d43c69f8d511a46e8f29fb610efeccb_prof);

    }

    public function getTemplateName()
    {
        return "SonataAdminBundle:CRUD:acl.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  11 => 12,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#

This file is part of the Sonata package.

(c) Thomas Rabaix <thomas.rabaix@sonata-project.org>

For the full copyright and license information, please view the LICENSE
file that was distributed with this source code.

#}

{% extends '@SonataAdmin/CRUD/base_acl.html.twig' %}
", "SonataAdminBundle:CRUD:acl.html.twig", "/home/ch/proyectos/php/obrasSociales/vendor/sonata-project/admin-bundle/src/Resources/views/CRUD/acl.html.twig");
    }
}

<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_2d8c7552c99cde8493cb1ab183f0300cd8d9360921dccaa61421ccfb37d0196d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3c2d026b696d11761b7398184e7b06f62dcb6f8a6ce247be0dddec1c2d870a60 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3c2d026b696d11761b7398184e7b06f62dcb6f8a6ce247be0dddec1c2d870a60->enter($__internal_3c2d026b696d11761b7398184e7b06f62dcb6f8a6ce247be0dddec1c2d870a60_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_3c2d026b696d11761b7398184e7b06f62dcb6f8a6ce247be0dddec1c2d870a60->leave($__internal_3c2d026b696d11761b7398184e7b06f62dcb6f8a6ce247be0dddec1c2d870a60_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_b0146eee3246bcfcec1a9253f0da3e76f0be2e9956a3efd3c82e2be5143b96b4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b0146eee3246bcfcec1a9253f0da3e76f0be2e9956a3efd3c82e2be5143b96b4->enter($__internal_b0146eee3246bcfcec1a9253f0da3e76f0be2e9956a3efd3c82e2be5143b96b4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_b0146eee3246bcfcec1a9253f0da3e76f0be2e9956a3efd3c82e2be5143b96b4->leave($__internal_b0146eee3246bcfcec1a9253f0da3e76f0be2e9956a3efd3c82e2be5143b96b4_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "WebProfilerBundle:Profiler:ajax_layout.html.twig", "/home/ch/proyectos/php/obrasSociales/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Profiler/ajax_layout.html.twig");
    }
}

<?php

/* SonataAdminBundle:CRUD:show_array.html.twig */
class __TwigTemplate_0ffaeb0eb7df44a7077976afe9113c68937602ece03d8241d4c364ca90c6acdc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 13
        $this->parent = $this->loadTemplate("@SonataAdmin/CRUD/base_show_field.html.twig", "SonataAdminBundle:CRUD:show_array.html.twig", 13);
        $this->blocks = array(
            'field' => array($this, 'block_field'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@SonataAdmin/CRUD/base_show_field.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e147cc0c9e4834c21f4089aeadc9ccbf3686f4463cc89f286face4715cece4b1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e147cc0c9e4834c21f4089aeadc9ccbf3686f4463cc89f286face4715cece4b1->enter($__internal_e147cc0c9e4834c21f4089aeadc9ccbf3686f4463cc89f286face4715cece4b1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataAdminBundle:CRUD:show_array.html.twig"));

        // line 11
        $context["show"] = $this->loadTemplate("@SonataAdmin/CRUD/base_array_macro.html.twig", "SonataAdminBundle:CRUD:show_array.html.twig", 11);
        // line 13
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e147cc0c9e4834c21f4089aeadc9ccbf3686f4463cc89f286face4715cece4b1->leave($__internal_e147cc0c9e4834c21f4089aeadc9ccbf3686f4463cc89f286face4715cece4b1_prof);

    }

    // line 15
    public function block_field($context, array $blocks = array())
    {
        $__internal_c91ee3188b6a56e183b141b84d27a735cc3f63e7188f4c5ab13c8f9ae6f8559d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c91ee3188b6a56e183b141b84d27a735cc3f63e7188f4c5ab13c8f9ae6f8559d->enter($__internal_c91ee3188b6a56e183b141b84d27a735cc3f63e7188f4c5ab13c8f9ae6f8559d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "field"));

        // line 16
        echo "    ";
        echo $context["show"]->getrender_array(($context["value"] ?? $this->getContext($context, "value")), (($this->getAttribute($this->getAttribute(($context["field_description"] ?? null), "options", array(), "any", false, true), "inline", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute($this->getAttribute(($context["field_description"] ?? null), "options", array(), "any", false, true), "inline", array()), false)) : (false)));
        echo "
";
        
        $__internal_c91ee3188b6a56e183b141b84d27a735cc3f63e7188f4c5ab13c8f9ae6f8559d->leave($__internal_c91ee3188b6a56e183b141b84d27a735cc3f63e7188f4c5ab13c8f9ae6f8559d_prof);

    }

    public function getTemplateName()
    {
        return "SonataAdminBundle:CRUD:show_array.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  43 => 16,  37 => 15,  30 => 13,  28 => 11,  11 => 13,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#

This file is part of the Sonata package.

(c) Thomas Rabaix <thomas.rabaix@sonata-project.org>

For the full copyright and license information, please view the LICENSE
file that was distributed with this source code.

#}
{% import '@SonataAdmin/CRUD/base_array_macro.html.twig' as show %}

{% extends '@SonataAdmin/CRUD/base_show_field.html.twig' %}

{% block field%}
    {{ show.render_array(value, field_description.options.inline|default(false)) }}
{% endblock %}
", "SonataAdminBundle:CRUD:show_array.html.twig", "/home/ch/proyectos/php/obrasSociales/vendor/sonata-project/admin-bundle/src/Resources/views/CRUD/show_array.html.twig");
    }
}

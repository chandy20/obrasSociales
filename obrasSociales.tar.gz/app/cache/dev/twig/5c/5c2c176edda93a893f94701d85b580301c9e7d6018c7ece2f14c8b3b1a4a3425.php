<?php

/* SonataAdminBundle:Core:create_button.html.twig */
class __TwigTemplate_df6d91e596105de17830c4d915fb38b3350cc9832e9e28ac7f14deaa42f94782 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 15
        $this->parent = $this->loadTemplate("@SonataAdmin/Button/create_button.html.twig", "SonataAdminBundle:Core:create_button.html.twig", 15);
        $this->blocks = array(
        );
    }

    protected function doGetParent(array $context)
    {
        return "@SonataAdmin/Button/create_button.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b8da8c6f2deca9173d5e3811abd2a50fd3cd8befc9e4cccc86781d5fa5ffb83f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b8da8c6f2deca9173d5e3811abd2a50fd3cd8befc9e4cccc86781d5fa5ffb83f->enter($__internal_b8da8c6f2deca9173d5e3811abd2a50fd3cd8befc9e4cccc86781d5fa5ffb83f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataAdminBundle:Core:create_button.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b8da8c6f2deca9173d5e3811abd2a50fd3cd8befc9e4cccc86781d5fa5ffb83f->leave($__internal_b8da8c6f2deca9173d5e3811abd2a50fd3cd8befc9e4cccc86781d5fa5ffb83f_prof);

    }

    public function getTemplateName()
    {
        return "SonataAdminBundle:Core:create_button.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  11 => 15,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#

This file is part of the Sonata package.

(c) Thomas Rabaix <thomas.rabaix@sonata-project.org>

For the full copyright and license information, please view the LICENSE
file that was distributed with this source code.

#}

{# DEPRECATED #}
{# This file is kept here for backward compatibility - Rather use @SonataAdmin/Button/create_button.html.twig #}

{% extends '@SonataAdmin/Button/create_button.html.twig' %}
", "SonataAdminBundle:Core:create_button.html.twig", "/home/ch/proyectos/php/obrasSociales/vendor/sonata-project/admin-bundle/src/Resources/views/Core/create_button.html.twig");
    }
}

<?php

/* SonataUserBundle:Admin/Security/Resetting:checkEmail.html.twig */
class __TwigTemplate_b914c1213dd8c0dffc6d810a0a4b2e95030558093caa2f95717ff855aaa5bce0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'sonata_nav' => array($this, 'block_sonata_nav'),
            'logo' => array($this, 'block_logo'),
            'sonata_left_side' => array($this, 'block_sonata_left_side'),
            'body_attributes' => array($this, 'block_body_attributes'),
            'sonata_wrapper' => array($this, 'block_sonata_wrapper'),
        );
    }

    protected function doGetParent(array $context)
    {
        // line 12
        return $this->loadTemplate(($context["base_template"] ?? $this->getContext($context, "base_template")), "SonataUserBundle:Admin/Security/Resetting:checkEmail.html.twig", 12);
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2d9d2981c7fd1d8cc936c034a192fe1a14a24e4b51480b4073270c5c666f78e8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2d9d2981c7fd1d8cc936c034a192fe1a14a24e4b51480b4073270c5c666f78e8->enter($__internal_2d9d2981c7fd1d8cc936c034a192fe1a14a24e4b51480b4073270c5c666f78e8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataUserBundle:Admin/Security/Resetting:checkEmail.html.twig"));

        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_2d9d2981c7fd1d8cc936c034a192fe1a14a24e4b51480b4073270c5c666f78e8->leave($__internal_2d9d2981c7fd1d8cc936c034a192fe1a14a24e4b51480b4073270c5c666f78e8_prof);

    }

    // line 14
    public function block_sonata_nav($context, array $blocks = array())
    {
        $__internal_94fb263013e0c792958a2db8420f117ca6b56e7c7a5e02f18f33418efce996c6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_94fb263013e0c792958a2db8420f117ca6b56e7c7a5e02f18f33418efce996c6->enter($__internal_94fb263013e0c792958a2db8420f117ca6b56e7c7a5e02f18f33418efce996c6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_nav"));

        
        $__internal_94fb263013e0c792958a2db8420f117ca6b56e7c7a5e02f18f33418efce996c6->leave($__internal_94fb263013e0c792958a2db8420f117ca6b56e7c7a5e02f18f33418efce996c6_prof);

    }

    // line 17
    public function block_logo($context, array $blocks = array())
    {
        $__internal_10162bf5ced3227992f1edecdf63583563a5ebf4ab563a577f99b4b8e794d0c5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_10162bf5ced3227992f1edecdf63583563a5ebf4ab563a577f99b4b8e794d0c5->enter($__internal_10162bf5ced3227992f1edecdf63583563a5ebf4ab563a577f99b4b8e794d0c5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "logo"));

        
        $__internal_10162bf5ced3227992f1edecdf63583563a5ebf4ab563a577f99b4b8e794d0c5->leave($__internal_10162bf5ced3227992f1edecdf63583563a5ebf4ab563a577f99b4b8e794d0c5_prof);

    }

    // line 20
    public function block_sonata_left_side($context, array $blocks = array())
    {
        $__internal_17253552bdc57aa3d77d987240035509bb435035a324dd8d4a67eaa4df0f2100 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_17253552bdc57aa3d77d987240035509bb435035a324dd8d4a67eaa4df0f2100->enter($__internal_17253552bdc57aa3d77d987240035509bb435035a324dd8d4a67eaa4df0f2100_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_left_side"));

        
        $__internal_17253552bdc57aa3d77d987240035509bb435035a324dd8d4a67eaa4df0f2100->leave($__internal_17253552bdc57aa3d77d987240035509bb435035a324dd8d4a67eaa4df0f2100_prof);

    }

    // line 23
    public function block_body_attributes($context, array $blocks = array())
    {
        $__internal_277accdbf1a833e4a7a3cc762b712234ee1428378f2e793bd674e103cff48bce = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_277accdbf1a833e4a7a3cc762b712234ee1428378f2e793bd674e103cff48bce->enter($__internal_277accdbf1a833e4a7a3cc762b712234ee1428378f2e793bd674e103cff48bce_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_attributes"));

        echo "class=\"sonata-bc login-page\"";
        
        $__internal_277accdbf1a833e4a7a3cc762b712234ee1428378f2e793bd674e103cff48bce->leave($__internal_277accdbf1a833e4a7a3cc762b712234ee1428378f2e793bd674e103cff48bce_prof);

    }

    // line 25
    public function block_sonata_wrapper($context, array $blocks = array())
    {
        $__internal_e062e5bc5d928dca452398f02b9ac64abd26c73e6beb3179184c8365dbbdcc33 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e062e5bc5d928dca452398f02b9ac64abd26c73e6beb3179184c8365dbbdcc33->enter($__internal_e062e5bc5d928dca452398f02b9ac64abd26c73e6beb3179184c8365dbbdcc33_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_wrapper"));

        // line 26
        echo "
    <div class=\"login-box\">
        <div class=\"login-logo\">
            <a href=\"";
        // line 29
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("sonata_admin_dashboard");
        echo "\">
                ";
        // line 30
        if ((("single_text" == $this->getAttribute(($context["admin_pool"] ?? $this->getContext($context, "admin_pool")), "getOption", array(0 => "title_mode"), "method")) || ("both" == $this->getAttribute(($context["admin_pool"] ?? $this->getContext($context, "admin_pool")), "getOption", array(0 => "title_mode"), "method")))) {
            // line 31
            echo "                    <span>";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["admin_pool"] ?? $this->getContext($context, "admin_pool")), "title", array()), "html", null, true);
            echo "</span>
                ";
        }
        // line 33
        echo "            </a>
        </div>
        <div class=\"login-box-body\">
            <p>";
        // line 36
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("resetting.check_email", array("%email%" => ($context["email"] ?? $this->getContext($context, "email"))), "FOSUserBundle"), "html", null, true);
        echo "</p>
            <a href=\"";
        // line 37
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("sonata_user_admin_security_login");
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("title_user_authentication", array(), "SonataUserBundle"), "html", null, true);
        echo "</a>
        </div>
    </div>

";
        
        $__internal_e062e5bc5d928dca452398f02b9ac64abd26c73e6beb3179184c8365dbbdcc33->leave($__internal_e062e5bc5d928dca452398f02b9ac64abd26c73e6beb3179184c8365dbbdcc33_prof);

    }

    public function getTemplateName()
    {
        return "SonataUserBundle:Admin/Security/Resetting:checkEmail.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  114 => 37,  110 => 36,  105 => 33,  99 => 31,  97 => 30,  93 => 29,  88 => 26,  82 => 25,  70 => 23,  59 => 20,  48 => 17,  37 => 14,  22 => 12,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#

This file is part of the Sonata package.

(c) Thomas Rabaix <thomas.rabaix@sonata-project.org>

For the full copyright and license information, please view the LICENSE
file that was distributed with this source code.

#}

{% extends base_template %}

{% block sonata_nav %}
{% endblock sonata_nav %}

{% block logo %}
{% endblock logo %}

{% block sonata_left_side %}
{% endblock sonata_left_side %}

{% block body_attributes %}class=\"sonata-bc login-page\"{% endblock %}

{% block sonata_wrapper %}

    <div class=\"login-box\">
        <div class=\"login-logo\">
            <a href=\"{{ path('sonata_admin_dashboard') }}\">
                {% if 'single_text' == admin_pool.getOption('title_mode') or 'both' == admin_pool.getOption('title_mode') %}
                    <span>{{ admin_pool.title }}</span>
                {% endif %}
            </a>
        </div>
        <div class=\"login-box-body\">
            <p>{{ 'resetting.check_email'|trans({'%email%': email}, 'FOSUserBundle') }}</p>
            <a href=\"{{ path('sonata_user_admin_security_login') }}\">{{ 'title_user_authentication'|trans({}, 'SonataUserBundle') }}</a>
        </div>
    </div>

{% endblock sonata_wrapper %}
", "SonataUserBundle:Admin/Security/Resetting:checkEmail.html.twig", "/home/ch/proyectos/php/obrasSociales/vendor/sonata-project/user-bundle/src/Resources/views/Admin/Security/Resetting/checkEmail.html.twig");
    }
}

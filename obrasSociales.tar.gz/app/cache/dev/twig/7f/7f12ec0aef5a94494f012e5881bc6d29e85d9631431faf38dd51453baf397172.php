<?php

/* SonataAdminBundle:Pager:results.html.twig */
class __TwigTemplate_05a9e03c90e10a75c43049b967810cf8aeb8c9fcbb719b0b37babb3f4bf98061 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 12
        $this->parent = $this->loadTemplate("@SonataAdmin/Pager/base_results.html.twig", "SonataAdminBundle:Pager:results.html.twig", 12);
        $this->blocks = array(
        );
    }

    protected function doGetParent(array $context)
    {
        return "@SonataAdmin/Pager/base_results.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b3664ab1f5ff1faec59c80479632b8a685251e2dc9d6361484390f3729f9022f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b3664ab1f5ff1faec59c80479632b8a685251e2dc9d6361484390f3729f9022f->enter($__internal_b3664ab1f5ff1faec59c80479632b8a685251e2dc9d6361484390f3729f9022f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataAdminBundle:Pager:results.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b3664ab1f5ff1faec59c80479632b8a685251e2dc9d6361484390f3729f9022f->leave($__internal_b3664ab1f5ff1faec59c80479632b8a685251e2dc9d6361484390f3729f9022f_prof);

    }

    public function getTemplateName()
    {
        return "SonataAdminBundle:Pager:results.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  11 => 12,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#

This file is part of the Sonata package.

(c) Thomas Rabaix <thomas.rabaix@sonata-project.org>

For the full copyright and license information, please view the LICENSE
file that was distributed with this source code.

#}

{% extends '@SonataAdmin/Pager/base_results.html.twig' %}
", "SonataAdminBundle:Pager:results.html.twig", "/home/ch/proyectos/php/obrasSociales/vendor/sonata-project/admin-bundle/src/Resources/views/Pager/results.html.twig");
    }
}

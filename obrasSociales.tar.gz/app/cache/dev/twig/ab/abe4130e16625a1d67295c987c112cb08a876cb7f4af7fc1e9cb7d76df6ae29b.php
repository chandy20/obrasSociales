<?php

/* SonataBlockBundle:Block:block_base.html.twig */
class __TwigTemplate_ed2f883e4d4aed912325b65eb7a8e6365f209086cd519c7b2cd0d078ecaa211d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'block' => array($this, 'block_block'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_223dfba2ef23995764f89fb89683c8fdba15acc05430fc3a748d231ae44b986a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_223dfba2ef23995764f89fb89683c8fdba15acc05430fc3a748d231ae44b986a->enter($__internal_223dfba2ef23995764f89fb89683c8fdba15acc05430fc3a748d231ae44b986a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataBlockBundle:Block:block_base.html.twig"));

        // line 11
        echo "<div id=\"cms-block-";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["block"] ?? $this->getContext($context, "block")), "id", array()), "html", null, true);
        echo "\" class=\"cms-block cms-block-element\">
    ";
        // line 12
        $this->displayBlock('block', $context, $blocks);
        // line 13
        echo "</div>
";
        
        $__internal_223dfba2ef23995764f89fb89683c8fdba15acc05430fc3a748d231ae44b986a->leave($__internal_223dfba2ef23995764f89fb89683c8fdba15acc05430fc3a748d231ae44b986a_prof);

    }

    // line 12
    public function block_block($context, array $blocks = array())
    {
        $__internal_eada39265101b46817172dc971ab4edc859ae01346c6d3d05802a70c08c0cdc6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_eada39265101b46817172dc971ab4edc859ae01346c6d3d05802a70c08c0cdc6->enter($__internal_eada39265101b46817172dc971ab4edc859ae01346c6d3d05802a70c08c0cdc6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "block"));

        echo "EMPTY CONTENT";
        
        $__internal_eada39265101b46817172dc971ab4edc859ae01346c6d3d05802a70c08c0cdc6->leave($__internal_eada39265101b46817172dc971ab4edc859ae01346c6d3d05802a70c08c0cdc6_prof);

    }

    public function getTemplateName()
    {
        return "SonataBlockBundle:Block:block_base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  38 => 12,  30 => 13,  28 => 12,  23 => 11,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#

This file is part of the Sonata package.

(c) Thomas Rabaix <thomas.rabaix@sonata-project.org>

For the full copyright and license information, please view the LICENSE
file that was distributed with this source code.

#}
<div id=\"cms-block-{{ block.id }}\" class=\"cms-block cms-block-element\">
    {% block block %}EMPTY CONTENT{% endblock %}
</div>
", "SonataBlockBundle:Block:block_base.html.twig", "/home/ch/proyectos/php/obrasSociales/vendor/sonata-project/block-bundle/src/Resources/views/Block/block_base.html.twig");
    }
}

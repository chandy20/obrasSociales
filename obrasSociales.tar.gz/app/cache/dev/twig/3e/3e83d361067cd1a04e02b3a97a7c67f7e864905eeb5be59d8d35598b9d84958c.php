<?php

/* FOSUserBundle:Group:edit.html.twig */
class __TwigTemplate_dc87418646d77e3c75002d137e04138dd273d466fd96e5c755096dbe497bb485 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Group:edit.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7c56dddab9aee54e653ddf7da1b6f234165f30876f97439681bebf64e304e740 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7c56dddab9aee54e653ddf7da1b6f234165f30876f97439681bebf64e304e740->enter($__internal_7c56dddab9aee54e653ddf7da1b6f234165f30876f97439681bebf64e304e740_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_7c56dddab9aee54e653ddf7da1b6f234165f30876f97439681bebf64e304e740->leave($__internal_7c56dddab9aee54e653ddf7da1b6f234165f30876f97439681bebf64e304e740_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_bc8991267e1a3548d923904329b603fc1a81de81c2a3136dc5803b6e5dd20596 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bc8991267e1a3548d923904329b603fc1a81de81c2a3136dc5803b6e5dd20596->enter($__internal_bc8991267e1a3548d923904329b603fc1a81de81c2a3136dc5803b6e5dd20596_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Group:edit_content.html.twig", "FOSUserBundle:Group:edit.html.twig", 4)->display($context);
        
        $__internal_bc8991267e1a3548d923904329b603fc1a81de81c2a3136dc5803b6e5dd20596->leave($__internal_bc8991267e1a3548d923904329b603fc1a81de81c2a3136dc5803b6e5dd20596_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"FOSUserBundle::layout.html.twig\" %}

{% block fos_user_content %}
{% include \"FOSUserBundle:Group:edit_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Group:edit.html.twig", "/home/ch/proyectos/php/obrasSociales/vendor/friendsofsymfony/user-bundle/FOS/UserBundle/Resources/views/Group/edit.html.twig");
    }
}

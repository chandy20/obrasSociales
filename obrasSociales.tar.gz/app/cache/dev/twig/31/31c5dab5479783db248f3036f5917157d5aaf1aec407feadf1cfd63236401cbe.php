<?php

/* FOSUserBundle:Profile:edit.html.twig */
class __TwigTemplate_805b66fcf4d56de68d8b7e1722671f25e660a1e78c2c59f6374ae3a99c256b5d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Profile:edit.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_51750c04859d613dc8924760b616f16b7528b9198a4c660845573389d96d9448 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_51750c04859d613dc8924760b616f16b7528b9198a4c660845573389d96d9448->enter($__internal_51750c04859d613dc8924760b616f16b7528b9198a4c660845573389d96d9448_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Profile:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_51750c04859d613dc8924760b616f16b7528b9198a4c660845573389d96d9448->leave($__internal_51750c04859d613dc8924760b616f16b7528b9198a4c660845573389d96d9448_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_8cab47d6c7208c625c67b92c50dd0cff1fca7e24e1926a5f1796c6cfa8fa9df2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8cab47d6c7208c625c67b92c50dd0cff1fca7e24e1926a5f1796c6cfa8fa9df2->enter($__internal_8cab47d6c7208c625c67b92c50dd0cff1fca7e24e1926a5f1796c6cfa8fa9df2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Profile:edit_content.html.twig", "FOSUserBundle:Profile:edit.html.twig", 4)->display($context);
        
        $__internal_8cab47d6c7208c625c67b92c50dd0cff1fca7e24e1926a5f1796c6cfa8fa9df2->leave($__internal_8cab47d6c7208c625c67b92c50dd0cff1fca7e24e1926a5f1796c6cfa8fa9df2_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Profile:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"FOSUserBundle::layout.html.twig\" %}

{% block fos_user_content %}
{% include \"FOSUserBundle:Profile:edit_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Profile:edit.html.twig", "/home/ch/proyectos/php/obrasSociales/vendor/friendsofsymfony/user-bundle/FOS/UserBundle/Resources/views/Profile/edit.html.twig");
    }
}

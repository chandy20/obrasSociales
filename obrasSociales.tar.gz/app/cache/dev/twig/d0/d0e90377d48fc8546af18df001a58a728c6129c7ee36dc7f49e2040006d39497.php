<?php

/* SonataAdminBundle:CRUD:show_email.html.twig */
class __TwigTemplate_f7f8e92fe6b8c74348d851d02794b032438bb963a8cc650910ef1cb18188e377 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@SonataAdmin/CRUD/base_show_field.html.twig", "SonataAdminBundle:CRUD:show_email.html.twig", 1);
        $this->blocks = array(
            'field' => array($this, 'block_field'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@SonataAdmin/CRUD/base_show_field.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f2ecd19e97c6dcf99782f4ca830d8d065f1a97360b8724bab6b553cba293f0cd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f2ecd19e97c6dcf99782f4ca830d8d065f1a97360b8724bab6b553cba293f0cd->enter($__internal_f2ecd19e97c6dcf99782f4ca830d8d065f1a97360b8724bab6b553cba293f0cd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataAdminBundle:CRUD:show_email.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f2ecd19e97c6dcf99782f4ca830d8d065f1a97360b8724bab6b553cba293f0cd->leave($__internal_f2ecd19e97c6dcf99782f4ca830d8d065f1a97360b8724bab6b553cba293f0cd_prof);

    }

    // line 3
    public function block_field($context, array $blocks = array())
    {
        $__internal_4aa7de01ef3f156441957ceddf659e9367f277ee0dc4c9bc5b89383060fa2904 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4aa7de01ef3f156441957ceddf659e9367f277ee0dc4c9bc5b89383060fa2904->enter($__internal_4aa7de01ef3f156441957ceddf659e9367f277ee0dc4c9bc5b89383060fa2904_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "field"));

        // line 4
        echo "    ";
        $this->loadTemplate("@SonataAdmin/CRUD/_email_link.html.twig", "SonataAdminBundle:CRUD:show_email.html.twig", 4)->display($context);
        
        $__internal_4aa7de01ef3f156441957ceddf659e9367f277ee0dc4c9bc5b89383060fa2904->leave($__internal_4aa7de01ef3f156441957ceddf659e9367f277ee0dc4c9bc5b89383060fa2904_prof);

    }

    public function getTemplateName()
    {
        return "SonataAdminBundle:CRUD:show_email.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@SonataAdmin/CRUD/base_show_field.html.twig' %}

{% block field %}
    {% include '@SonataAdmin/CRUD/_email_link.html.twig' %}
{% endblock %}
", "SonataAdminBundle:CRUD:show_email.html.twig", "/home/ch/proyectos/php/obrasSociales/vendor/sonata-project/admin-bundle/src/Resources/views/CRUD/show_email.html.twig");
    }
}

<?php

/* FrontendBundle:Solicitudes:index.html.twig */
class __TwigTemplate_6f86476cfc8ecffd01837800ca7d53a181db627f4955ca6ebe1e1ce1b7fe7892 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "FrontendBundle:Solicitudes:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9e0b5888a3dae03fe3bee1d37864357b63c7cca7d32f350516130c2f17bc6ca7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9e0b5888a3dae03fe3bee1d37864357b63c7cca7d32f350516130c2f17bc6ca7->enter($__internal_9e0b5888a3dae03fe3bee1d37864357b63c7cca7d32f350516130c2f17bc6ca7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FrontendBundle:Solicitudes:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9e0b5888a3dae03fe3bee1d37864357b63c7cca7d32f350516130c2f17bc6ca7->leave($__internal_9e0b5888a3dae03fe3bee1d37864357b63c7cca7d32f350516130c2f17bc6ca7_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_68297de25d533d55ee626d05eb6f0fd026d706c78a0e6b2cb824225909199f70 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_68297de25d533d55ee626d05eb6f0fd026d706c78a0e6b2cb824225909199f70->enter($__internal_68297de25d533d55ee626d05eb6f0fd026d706c78a0e6b2cb824225909199f70_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "<div class=\"top-content\">
    <div class=\"container\" style=\"width: 97% !important\">
        <div class=\"row\">
            <div class=\"col-sm-8 col-sm-offset-2 text\">
                <h1> * <strong> Solicitudes </strong> AOS </h1>
                <div class=\"description\">
                    <p>
                        Retorno a la Pagina Principal de Obras Sociales. 
                        ingresa en <a href=\"http://obrassocialespolicia.org/obras/\"><strong>Obras Sociales</strong></a>, Bienvenido Al Portal Obras Sociales!
                    </p>
                </div>
            </div>
        </div>
      
        <div class=\"row\">
            <div class=\"f1 col-md-20 form-box\">
                <h3><font color=\"#054e96\"> SOLICITUDES </font></h3>
                
                <div align=\"float:center\"><img src=\"\\web\\bundles\\frontend\\images\\logo@2x.png\" height=\"200\" width=\"200\"></div>
                <p><font color=\"#054e96\">Asociación Obras Sociales en Beneficio de la Policia Nacional</p>
                <hr style=\"border-color:grey;\">
    
    
    <table class= \"table\">
    <div class = \"w3-ul\">

    
        <thead>
           
            <tr>
                <th>id</th>
                           
                <th>Solicitante</th>
               
                <th>Identificacion Funcionario</th>
             
                <th>Direccion funcionario</th>
              
                <th>Solicitudtelefonosfuncionario</th>
           
                <th>Solicitudnombrefuncionario</th>
             
                

            </tr>
        </thead>
        <tbody>
        ";
        // line 51
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["entities"] ?? $this->getContext($context, "entities")));
        foreach ($context['_seq'] as $context["_key"] => $context["entity"]) {
            // line 52
            echo "            <tr>

        
                <td><a href=\"";
            // line 55
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("solicitudes_show", array("id" => $this->getAttribute($context["entity"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["entity"], "id", array()), "html", null, true);
            echo "</a></td>
             
                <td>";
            // line 57
            echo twig_escape_filter($this->env, $this->getAttribute($context["entity"], "solicitudnombresolicita", array()), "html", null, true);
            echo "</td>
                
                <td>";
            // line 59
            echo twig_escape_filter($this->env, $this->getAttribute($context["entity"], "solicitudcedulafuncionario", array()), "html", null, true);
            echo "</td>
               
                <td>";
            // line 61
            echo twig_escape_filter($this->env, $this->getAttribute($context["entity"], "solicituddireccionfuncionario", array()), "html", null, true);
            echo "</td>
               
                <td>";
            // line 63
            echo twig_escape_filter($this->env, $this->getAttribute($context["entity"], "solicitudtelefonosfuncionario", array()), "html", null, true);
            echo "</td>
          
                <td>";
            // line 65
            echo twig_escape_filter($this->env, $this->getAttribute($context["entity"], "solicitudnombrefuncionario", array()), "html", null, true);
            echo "</td>

                <td>

               

                </td>
            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['entity'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 75
        echo "
        </tbody>
    </table>
    </div>

       

    <script>
    \$(document).ready(function() {
        // configure the bootstrap datepicker
        \$('.js-datepicker').datepicker({
            format: 'yyyy-mm-dd'
        });
    });
</script>
    ";
        
        $__internal_68297de25d533d55ee626d05eb6f0fd026d706c78a0e6b2cb824225909199f70->leave($__internal_68297de25d533d55ee626d05eb6f0fd026d706c78a0e6b2cb824225909199f70_prof);

    }

    public function getTemplateName()
    {
        return "FrontendBundle:Solicitudes:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  140 => 75,  125 => 65,  120 => 63,  115 => 61,  110 => 59,  105 => 57,  98 => 55,  93 => 52,  89 => 51,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '::base.html.twig' %}

{% block body -%}
    <div class=\"top-content\">
    <div class=\"container\" style=\"width: 97% !important\">
        <div class=\"row\">
            <div class=\"col-sm-8 col-sm-offset-2 text\">
                <h1> * <strong> Solicitudes </strong> AOS </h1>
                <div class=\"description\">
                    <p>
                        Retorno a la Pagina Principal de Obras Sociales. 
                        ingresa en <a href=\"http://obrassocialespolicia.org/obras/\"><strong>Obras Sociales</strong></a>, Bienvenido Al Portal Obras Sociales!
                    </p>
                </div>
            </div>
        </div>
      
        <div class=\"row\">
            <div class=\"f1 col-md-20 form-box\">
                <h3><font color=\"#054e96\"> SOLICITUDES </font></h3>
                
                <div align=\"float:center\"><img src=\"\\web\\bundles\\frontend\\images\\logo@2x.png\" height=\"200\" width=\"200\"></div>
                <p><font color=\"#054e96\">Asociación Obras Sociales en Beneficio de la Policia Nacional</p>
                <hr style=\"border-color:grey;\">
    
    
    <table class= \"table\">
    <div class = \"w3-ul\">

    
        <thead>
           
            <tr>
                <th>id</th>
                           
                <th>Solicitante</th>
               
                <th>Identificacion Funcionario</th>
             
                <th>Direccion funcionario</th>
              
                <th>Solicitudtelefonosfuncionario</th>
           
                <th>Solicitudnombrefuncionario</th>
             
                

            </tr>
        </thead>
        <tbody>
        {% for entity in entities %}
            <tr>

        
                <td><a href=\"{{ path('solicitudes_show', { 'id': entity.id }) }}\">{{ entity.id }}</a></td>
             
                <td>{{ entity.solicitudnombresolicita }}</td>
                
                <td>{{ entity.solicitudcedulafuncionario }}</td>
               
                <td>{{ entity.solicituddireccionfuncionario }}</td>
               
                <td>{{ entity.solicitudtelefonosfuncionario }}</td>
          
                <td>{{ entity.solicitudnombrefuncionario }}</td>

                <td>

               

                </td>
            </tr>
        {% endfor
         %}

        </tbody>
    </table>
    </div>

       

    <script>
    \$(document).ready(function() {
        // configure the bootstrap datepicker
        \$('.js-datepicker').datepicker({
            format: 'yyyy-mm-dd'
        });
    });
</script>
    {% endblock %}
", "FrontendBundle:Solicitudes:index.html.twig", "/home/ch/proyectos/php/obrasSociales/src/FrontendBundle/Resources/views/Solicitudes/index.html.twig");
    }
}

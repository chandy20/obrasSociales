<?php

/* @Framework/Form/attributes.html.php */
class __TwigTemplate_0fedcf8502f96f0bd6e58998f214fbbfe38bb7c60e6f7fb55edf7474d9391ec3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2625ce2b01a9582e7700b94430727bb80a0f2850b97ece5352e456906a119c75 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2625ce2b01a9582e7700b94430727bb80a0f2850b97ece5352e456906a119c75->enter($__internal_2625ce2b01a9582e7700b94430727bb80a0f2850b97ece5352e456906a119c75_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
";
        
        $__internal_2625ce2b01a9582e7700b94430727bb80a0f2850b97ece5352e456906a119c75->leave($__internal_2625ce2b01a9582e7700b94430727bb80a0f2850b97ece5352e456906a119c75_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
", "@Framework/Form/attributes.html.php", "/home/ch/proyectos/php/obrasSociales/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/attributes.html.php");
    }
}

<?php

/* FOSUserBundle:Registration:checkEmail.html.twig */
class __TwigTemplate_8b06aa0420604a4ca2adcdc2ef222df8b83ef2036d1fcc27ac98d71c9992a079 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Registration:checkEmail.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_57e4046d57b12f3bb47d041ff7ec46eac47e44da3190a1a0ef609e301cb40ff3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_57e4046d57b12f3bb47d041ff7ec46eac47e44da3190a1a0ef609e301cb40ff3->enter($__internal_57e4046d57b12f3bb47d041ff7ec46eac47e44da3190a1a0ef609e301cb40ff3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:checkEmail.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_57e4046d57b12f3bb47d041ff7ec46eac47e44da3190a1a0ef609e301cb40ff3->leave($__internal_57e4046d57b12f3bb47d041ff7ec46eac47e44da3190a1a0ef609e301cb40ff3_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_664e2e40955113c76e3881fd8ba4f921826bb484c29b2d9f34401d541a2a13ff = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_664e2e40955113c76e3881fd8ba4f921826bb484c29b2d9f34401d541a2a13ff->enter($__internal_664e2e40955113c76e3881fd8ba4f921826bb484c29b2d9f34401d541a2a13ff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        echo "    <p>";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("registration.check_email", array("%email%" => $this->getAttribute(($context["user"] ?? $this->getContext($context, "user")), "email", array())), "FOSUserBundle"), "html", null, true);
        echo "</p>
";
        
        $__internal_664e2e40955113c76e3881fd8ba4f921826bb484c29b2d9f34401d541a2a13ff->leave($__internal_664e2e40955113c76e3881fd8ba4f921826bb484c29b2d9f34401d541a2a13ff_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Registration:checkEmail.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"FOSUserBundle::layout.html.twig\" %}

{% block fos_user_content %}
    <p>{{ 'registration.check_email'|trans({'%email%': user.email}, 'FOSUserBundle') }}</p>
{% endblock fos_user_content %}
", "FOSUserBundle:Registration:checkEmail.html.twig", "/home/ch/proyectos/php/obrasSociales/vendor/friendsofsymfony/user-bundle/FOS/UserBundle/Resources/views/Registration/checkEmail.html.twig");
    }
}

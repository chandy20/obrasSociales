<?php

/* SonataAdminBundle:CRUD:edit_integer.html.twig */
class __TwigTemplate_629d8462db123bd631a42de72dea28fc92668ee4caf5c84a7621280385a323d5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'field' => array($this, 'block_field'),
        );
    }

    protected function doGetParent(array $context)
    {
        // line 12
        return $this->loadTemplate(($context["base_template"] ?? $this->getContext($context, "base_template")), "SonataAdminBundle:CRUD:edit_integer.html.twig", 12);
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_307baadc0f258e45dc7d2c7b3fd5333808d362ccfbee941c46fefe9c799c8fd7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_307baadc0f258e45dc7d2c7b3fd5333808d362ccfbee941c46fefe9c799c8fd7->enter($__internal_307baadc0f258e45dc7d2c7b3fd5333808d362ccfbee941c46fefe9c799c8fd7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataAdminBundle:CRUD:edit_integer.html.twig"));

        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_307baadc0f258e45dc7d2c7b3fd5333808d362ccfbee941c46fefe9c799c8fd7->leave($__internal_307baadc0f258e45dc7d2c7b3fd5333808d362ccfbee941c46fefe9c799c8fd7_prof);

    }

    // line 14
    public function block_field($context, array $blocks = array())
    {
        $__internal_52b98f349427caf275437b011c3a76c43fe89d7dc05137217c1dbc3ff53c743e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_52b98f349427caf275437b011c3a76c43fe89d7dc05137217c1dbc3ff53c743e->enter($__internal_52b98f349427caf275437b011c3a76c43fe89d7dc05137217c1dbc3ff53c743e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "field"));

        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock(($context["field_element"] ?? $this->getContext($context, "field_element")), 'widget', array("attr" => array("class" => "title")));
        
        $__internal_52b98f349427caf275437b011c3a76c43fe89d7dc05137217c1dbc3ff53c743e->leave($__internal_52b98f349427caf275437b011c3a76c43fe89d7dc05137217c1dbc3ff53c743e_prof);

    }

    public function getTemplateName()
    {
        return "SonataAdminBundle:CRUD:edit_integer.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  33 => 14,  18 => 12,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#

This file is part of the Sonata package.

(c) Thomas Rabaix <thomas.rabaix@sonata-project.org>

For the full copyright and license information, please view the LICENSE
file that was distributed with this source code.

#}

{% extends base_template %}

{% block field %}{{ form_widget(field_element, {'attr': {'class' : 'title'}}) }}{% endblock %}
", "SonataAdminBundle:CRUD:edit_integer.html.twig", "/home/ch/proyectos/php/obrasSociales/vendor/sonata-project/admin-bundle/src/Resources/views/CRUD/edit_integer.html.twig");
    }
}

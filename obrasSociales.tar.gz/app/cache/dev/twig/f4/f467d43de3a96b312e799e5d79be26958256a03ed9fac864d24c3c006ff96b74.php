<?php

/* SonataAdminBundle:CRUD:edit_file.html.twig */
class __TwigTemplate_ceda432aee7f7b1fcb1846e2e65400ddfeb4b22c5da037b30430b4330ac900be extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'field' => array($this, 'block_field'),
        );
    }

    protected function doGetParent(array $context)
    {
        // line 12
        return $this->loadTemplate(($context["base_template"] ?? $this->getContext($context, "base_template")), "SonataAdminBundle:CRUD:edit_file.html.twig", 12);
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bb608906e69d81ff71a325c06056618cce8b160a402416e840d6cd72a7a65757 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bb608906e69d81ff71a325c06056618cce8b160a402416e840d6cd72a7a65757->enter($__internal_bb608906e69d81ff71a325c06056618cce8b160a402416e840d6cd72a7a65757_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataAdminBundle:CRUD:edit_file.html.twig"));

        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_bb608906e69d81ff71a325c06056618cce8b160a402416e840d6cd72a7a65757->leave($__internal_bb608906e69d81ff71a325c06056618cce8b160a402416e840d6cd72a7a65757_prof);

    }

    // line 14
    public function block_field($context, array $blocks = array())
    {
        $__internal_117a1464b544f064186157977aa1111cdab31b7f3d35a45025e985d711729989 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_117a1464b544f064186157977aa1111cdab31b7f3d35a45025e985d711729989->enter($__internal_117a1464b544f064186157977aa1111cdab31b7f3d35a45025e985d711729989_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "field"));

        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock(($context["field_element"] ?? $this->getContext($context, "field_element")), 'widget', array("attr" => array("class" => "title")));
        
        $__internal_117a1464b544f064186157977aa1111cdab31b7f3d35a45025e985d711729989->leave($__internal_117a1464b544f064186157977aa1111cdab31b7f3d35a45025e985d711729989_prof);

    }

    public function getTemplateName()
    {
        return "SonataAdminBundle:CRUD:edit_file.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  33 => 14,  18 => 12,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#

This file is part of the Sonata package.

(c) Thomas Rabaix <thomas.rabaix@sonata-project.org>

For the full copyright and license information, please view the LICENSE
file that was distributed with this source code.

#}

{% extends base_template %}

{% block field %}{{ form_widget(field_element, {'attr': {'class' : 'title'}}) }}{% endblock %}
", "SonataAdminBundle:CRUD:edit_file.html.twig", "/home/ch/proyectos/php/obrasSociales/vendor/sonata-project/admin-bundle/src/Resources/views/CRUD/edit_file.html.twig");
    }
}

<?php

/* @Framework/Form/form_enctype.html.php */
class __TwigTemplate_5abc2a04ba588594bd19a72479379218ebecd07d1280188184740cce4b2df815 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_04cf63bae627f4d4748a5c1af9db24dde7f3795321412c861941c116005b11df = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_04cf63bae627f4d4748a5c1af9db24dde7f3795321412c861941c116005b11df->enter($__internal_04cf63bae627f4d4748a5c1af9db24dde7f3795321412c861941c116005b11df_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        // line 1
        echo "<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
";
        
        $__internal_04cf63bae627f4d4748a5c1af9db24dde7f3795321412c861941c116005b11df->leave($__internal_04cf63bae627f4d4748a5c1af9db24dde7f3795321412c861941c116005b11df_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_enctype.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
", "@Framework/Form/form_enctype.html.php", "/home/ch/proyectos/php/obrasSociales/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/form_enctype.html.php");
    }
}

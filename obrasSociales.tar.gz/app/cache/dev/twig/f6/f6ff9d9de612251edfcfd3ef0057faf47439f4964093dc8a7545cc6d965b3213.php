<?php

/* SonataUserBundle:Admin/Security:login.html.twig */
class __TwigTemplate_ed4885723e46163193de975649bdaf238dba04d2c6a104e6f533ac0f91446455 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'sonata_nav' => array($this, 'block_sonata_nav'),
            'logo' => array($this, 'block_logo'),
            'sonata_left_side' => array($this, 'block_sonata_left_side'),
            'body_attributes' => array($this, 'block_body_attributes'),
            'sonata_wrapper' => array($this, 'block_sonata_wrapper'),
            'sonata_user_login_form' => array($this, 'block_sonata_user_login_form'),
            'sonata_user_login_error' => array($this, 'block_sonata_user_login_error'),
        );
    }

    protected function doGetParent(array $context)
    {
        // line 12
        return $this->loadTemplate(($context["base_template"] ?? $this->getContext($context, "base_template")), "SonataUserBundle:Admin/Security:login.html.twig", 12);
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7d4757eff4e2a2af2bdde141ce7c84cb13d7550df96b70890b1ef9cfc09770ec = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7d4757eff4e2a2af2bdde141ce7c84cb13d7550df96b70890b1ef9cfc09770ec->enter($__internal_7d4757eff4e2a2af2bdde141ce7c84cb13d7550df96b70890b1ef9cfc09770ec_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataUserBundle:Admin/Security:login.html.twig"));

        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_7d4757eff4e2a2af2bdde141ce7c84cb13d7550df96b70890b1ef9cfc09770ec->leave($__internal_7d4757eff4e2a2af2bdde141ce7c84cb13d7550df96b70890b1ef9cfc09770ec_prof);

    }

    // line 14
    public function block_sonata_nav($context, array $blocks = array())
    {
        $__internal_83786b12014b11228a3c3ffc7e709068c1ee0ce23983a6b01bad1afeb190f6fa = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_83786b12014b11228a3c3ffc7e709068c1ee0ce23983a6b01bad1afeb190f6fa->enter($__internal_83786b12014b11228a3c3ffc7e709068c1ee0ce23983a6b01bad1afeb190f6fa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_nav"));

        
        $__internal_83786b12014b11228a3c3ffc7e709068c1ee0ce23983a6b01bad1afeb190f6fa->leave($__internal_83786b12014b11228a3c3ffc7e709068c1ee0ce23983a6b01bad1afeb190f6fa_prof);

    }

    // line 17
    public function block_logo($context, array $blocks = array())
    {
        $__internal_76d62c330cd2b1d0e2910b5520fe7bed5333b7b11680bd231e076c7338c5cb8f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_76d62c330cd2b1d0e2910b5520fe7bed5333b7b11680bd231e076c7338c5cb8f->enter($__internal_76d62c330cd2b1d0e2910b5520fe7bed5333b7b11680bd231e076c7338c5cb8f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "logo"));

        
        $__internal_76d62c330cd2b1d0e2910b5520fe7bed5333b7b11680bd231e076c7338c5cb8f->leave($__internal_76d62c330cd2b1d0e2910b5520fe7bed5333b7b11680bd231e076c7338c5cb8f_prof);

    }

    // line 20
    public function block_sonata_left_side($context, array $blocks = array())
    {
        $__internal_b47522eb20904363042f4c9263a562c7be8612a2429f8e7a4170e0a2939b3717 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b47522eb20904363042f4c9263a562c7be8612a2429f8e7a4170e0a2939b3717->enter($__internal_b47522eb20904363042f4c9263a562c7be8612a2429f8e7a4170e0a2939b3717_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_left_side"));

        
        $__internal_b47522eb20904363042f4c9263a562c7be8612a2429f8e7a4170e0a2939b3717->leave($__internal_b47522eb20904363042f4c9263a562c7be8612a2429f8e7a4170e0a2939b3717_prof);

    }

    // line 23
    public function block_body_attributes($context, array $blocks = array())
    {
        $__internal_79acf2d85663cff8309ceb65458f7cbe4a4f1f2f70987780e3144ebf5dedcb14 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_79acf2d85663cff8309ceb65458f7cbe4a4f1f2f70987780e3144ebf5dedcb14->enter($__internal_79acf2d85663cff8309ceb65458f7cbe4a4f1f2f70987780e3144ebf5dedcb14_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_attributes"));

        echo "class=\"sonata-bc login-page\"";
        
        $__internal_79acf2d85663cff8309ceb65458f7cbe4a4f1f2f70987780e3144ebf5dedcb14->leave($__internal_79acf2d85663cff8309ceb65458f7cbe4a4f1f2f70987780e3144ebf5dedcb14_prof);

    }

    // line 25
    public function block_sonata_wrapper($context, array $blocks = array())
    {
        $__internal_4b3d4b496b48591b8d5e9686d4fe968c6a54463ed67b0b6c3c7b33d3a1dd60b5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4b3d4b496b48591b8d5e9686d4fe968c6a54463ed67b0b6c3c7b33d3a1dd60b5->enter($__internal_4b3d4b496b48591b8d5e9686d4fe968c6a54463ed67b0b6c3c7b33d3a1dd60b5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_wrapper"));

        // line 26
        echo "
    <div class=\"login-box\">
        <div class=\"login-logo\">
            <a href=\"";
        // line 29
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("sonata_admin_dashboard");
        echo "\">
                ";
        // line 30
        if ((("single_image" == $this->getAttribute($this->getAttribute(($context["sonata_admin"] ?? $this->getContext($context, "sonata_admin")), "adminPool", array()), "getOption", array(0 => "title_mode"), "method")) || ("both" == $this->getAttribute($this->getAttribute(($context["sonata_admin"] ?? $this->getContext($context, "sonata_admin")), "adminPool", array()), "getOption", array(0 => "title_mode"), "method")))) {
            // line 31
            echo "                    <div>
                        <img style=\"width:64px;\" src=\"";
            // line 32
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl($this->getAttribute($this->getAttribute(($context["sonata_admin"] ?? $this->getContext($context, "sonata_admin")), "adminPool", array()), "titlelogo", array())), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["sonata_admin"] ?? $this->getContext($context, "sonata_admin")), "adminPool", array()), "title", array()), "html", null, true);
            echo "\">
                    </div>
                ";
        }
        // line 35
        echo "                ";
        if ((("single_text" == $this->getAttribute($this->getAttribute(($context["sonata_admin"] ?? $this->getContext($context, "sonata_admin")), "adminPool", array()), "getOption", array(0 => "title_mode"), "method")) || ("both" == $this->getAttribute($this->getAttribute(($context["sonata_admin"] ?? $this->getContext($context, "sonata_admin")), "adminPool", array()), "getOption", array(0 => "title_mode"), "method")))) {
            // line 36
            echo "                    <span>";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["sonata_admin"] ?? $this->getContext($context, "sonata_admin")), "adminPool", array()), "title", array()), "html", null, true);
            echo "</span>
                ";
        }
        // line 38
        echo "            </a>
        </div>
        <div class=\"login-box-body\">
            ";
        // line 41
        $this->displayBlock('sonata_user_login_form', $context, $blocks);
        // line 81
        echo "        </div>
    </div>

";
        
        $__internal_4b3d4b496b48591b8d5e9686d4fe968c6a54463ed67b0b6c3c7b33d3a1dd60b5->leave($__internal_4b3d4b496b48591b8d5e9686d4fe968c6a54463ed67b0b6c3c7b33d3a1dd60b5_prof);

    }

    // line 41
    public function block_sonata_user_login_form($context, array $blocks = array())
    {
        $__internal_6d5abb59617667a0653c997b41dbe5b8b497772c364240a431e3e3be76d5ff79 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6d5abb59617667a0653c997b41dbe5b8b497772c364240a431e3e3be76d5ff79->enter($__internal_6d5abb59617667a0653c997b41dbe5b8b497772c364240a431e3e3be76d5ff79_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_user_login_form"));

        // line 42
        echo "                ";
        $this->displayBlock('sonata_user_login_error', $context, $blocks);
        // line 49
        echo "                <p class=\"login-box-msg\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("title_user_authentication", array(), "SonataUserBundle"), "html", null, true);
        echo "</p>
                <form action=\"";
        // line 50
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("sonata_user_admin_security_check");
        echo "\" method=\"post\" role=\"form\">
                    <input type=\"hidden\" name=\"_csrf_token\" value=\"";
        // line 51
        echo twig_escape_filter($this->env, ($context["csrf_token"] ?? $this->getContext($context, "csrf_token")), "html", null, true);
        echo "\"/>

                    <div class=\"form-group has-feedback\">
                        <input type=\"text\" class=\"form-control\" id=\"username\"  name=\"_username\" value=\"";
        // line 54
        echo twig_escape_filter($this->env, ($context["last_username"] ?? $this->getContext($context, "last_username")), "html", null, true);
        echo "\" required=\"required\" placeholder=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("security.login.username", array(), "SonataUserBundle"), "html", null, true);
        echo "\"/>
                        <span class=\"glyphicon glyphicon-user form-control-feedback\"></span>
                    </div>

                    <div class=\"form-group has-feedback\">
                        <input type=\"password\" class=\"form-control\" id=\"password\" name=\"_password\" required=\"required\" placeholder=\"";
        // line 59
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("security.login.password", array(), "SonataUserBundle"), "html", null, true);
        echo "\"/>
                        <span class=\"glyphicon glyphicon-lock form-control-feedback\"></span>
                    </div>

                    <div class=\"row\">
                        <div class=\"col-xs-8\">
                            <div class=\"checkbox\">
                                <label>
                                    <input type=\"checkbox\" id=\"remember_me\" name=\"_remember_me\" value=\"on\"/>
                                    ";
        // line 68
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("security.login.remember_me", array(), "FOSUserBundle"), "html", null, true);
        echo "
                                </label>
                            </div>
                        </div>
                        <div class=\"col-xs-4\">
                            <button type=\"submit\" class=\"btn btn-primary btn-block btn-flat\">";
        // line 73
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("security.login.submit", array(), "FOSUserBundle"), "html", null, true);
        echo "</button>
                        </div>
                    </div>
                </form>

                ";
        // line 79
        echo "                <a href=\"";
        echo twig_escape_filter($this->env, ($context["reset_route"] ?? $this->getContext($context, "reset_route")), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("forgotten_password", array(), "SonataUserBundle"), "html", null, true);
        echo "</a>
            ";
        
        $__internal_6d5abb59617667a0653c997b41dbe5b8b497772c364240a431e3e3be76d5ff79->leave($__internal_6d5abb59617667a0653c997b41dbe5b8b497772c364240a431e3e3be76d5ff79_prof);

    }

    // line 42
    public function block_sonata_user_login_error($context, array $blocks = array())
    {
        $__internal_ba73780292fc46bec49945735088f59de04b0dc2a2dbd0e3b7ebd1b4a3f92d24 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ba73780292fc46bec49945735088f59de04b0dc2a2dbd0e3b7ebd1b4a3f92d24->enter($__internal_ba73780292fc46bec49945735088f59de04b0dc2a2dbd0e3b7ebd1b4a3f92d24_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_user_login_error"));

        // line 43
        echo "                    ";
        if (($context["error"] ?? $this->getContext($context, "error"))) {
            // line 44
            echo "                        <div class=\"alert alert-danger alert-error\">
                            ";
            // line 45
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans($this->getAttribute(($context["error"] ?? $this->getContext($context, "error")), "messageKey", array()), $this->getAttribute(($context["error"] ?? $this->getContext($context, "error")), "messageData", array()), "security"), "html", null, true);
            echo "
                        </div>
                    ";
        }
        // line 48
        echo "                ";
        
        $__internal_ba73780292fc46bec49945735088f59de04b0dc2a2dbd0e3b7ebd1b4a3f92d24->leave($__internal_ba73780292fc46bec49945735088f59de04b0dc2a2dbd0e3b7ebd1b4a3f92d24_prof);

    }

    public function getTemplateName()
    {
        return "SonataUserBundle:Admin/Security:login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  230 => 48,  224 => 45,  221 => 44,  218 => 43,  212 => 42,  200 => 79,  192 => 73,  184 => 68,  172 => 59,  162 => 54,  156 => 51,  152 => 50,  147 => 49,  144 => 42,  138 => 41,  128 => 81,  126 => 41,  121 => 38,  115 => 36,  112 => 35,  104 => 32,  101 => 31,  99 => 30,  95 => 29,  90 => 26,  84 => 25,  72 => 23,  61 => 20,  50 => 17,  39 => 14,  24 => 12,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#

This file is part of the Sonata package.

(c) Thomas Rabaix <thomas.rabaix@sonata-project.org>

For the full copyright and license information, please view the LICENSE
file that was distributed with this source code.

#}

{% extends base_template %}

{% block sonata_nav %}
{% endblock sonata_nav %}

{% block logo %}
{% endblock logo %}

{% block sonata_left_side %}
{% endblock sonata_left_side %}

{% block body_attributes %}class=\"sonata-bc login-page\"{% endblock %}

{% block sonata_wrapper %}

    <div class=\"login-box\">
        <div class=\"login-logo\">
            <a href=\"{{ path('sonata_admin_dashboard') }}\">
                {% if 'single_image' == sonata_admin.adminPool.getOption('title_mode') or 'both' == sonata_admin.adminPool.getOption('title_mode') %}
                    <div>
                        <img style=\"width:64px;\" src=\"{{ asset(sonata_admin.adminPool.titlelogo) }}\" alt=\"{{ sonata_admin.adminPool.title }}\">
                    </div>
                {% endif %}
                {% if 'single_text' == sonata_admin.adminPool.getOption('title_mode') or 'both' == sonata_admin.adminPool.getOption('title_mode') %}
                    <span>{{ sonata_admin.adminPool.title }}</span>
                {% endif %}
            </a>
        </div>
        <div class=\"login-box-body\">
            {% block sonata_user_login_form %}
                {% block sonata_user_login_error %}
                    {% if error %}
                        <div class=\"alert alert-danger alert-error\">
                            {{ error.messageKey|trans(error.messageData, 'security') }}
                        </div>
                    {% endif %}
                {% endblock %}
                <p class=\"login-box-msg\">{{ 'title_user_authentication'|trans({}, 'SonataUserBundle') }}</p>
                <form action=\"{{ path(\"sonata_user_admin_security_check\") }}\" method=\"post\" role=\"form\">
                    <input type=\"hidden\" name=\"_csrf_token\" value=\"{{ csrf_token }}\"/>

                    <div class=\"form-group has-feedback\">
                        <input type=\"text\" class=\"form-control\" id=\"username\"  name=\"_username\" value=\"{{ last_username }}\" required=\"required\" placeholder=\"{{ 'security.login.username'|trans({}, 'SonataUserBundle') }}\"/>
                        <span class=\"glyphicon glyphicon-user form-control-feedback\"></span>
                    </div>

                    <div class=\"form-group has-feedback\">
                        <input type=\"password\" class=\"form-control\" id=\"password\" name=\"_password\" required=\"required\" placeholder=\"{{ 'security.login.password'|trans({}, 'SonataUserBundle') }}\"/>
                        <span class=\"glyphicon glyphicon-lock form-control-feedback\"></span>
                    </div>

                    <div class=\"row\">
                        <div class=\"col-xs-8\">
                            <div class=\"checkbox\">
                                <label>
                                    <input type=\"checkbox\" id=\"remember_me\" name=\"_remember_me\" value=\"on\"/>
                                    {{ 'security.login.remember_me'|trans({}, 'FOSUserBundle') }}
                                </label>
                            </div>
                        </div>
                        <div class=\"col-xs-4\">
                            <button type=\"submit\" class=\"btn btn-primary btn-block btn-flat\">{{ 'security.login.submit'|trans({}, 'FOSUserBundle') }}</button>
                        </div>
                    </div>
                </form>

                {#<a href=\"{{ path('sonata_user_admin_resetting_request') }}\">{{ 'forgotten_password'|trans({}, 'SonataUserBundle') }}</a>#}
                <a href=\"{{ reset_route }}\">{{ 'forgotten_password'|trans({}, 'SonataUserBundle') }}</a>
            {% endblock %}
        </div>
    </div>

{% endblock sonata_wrapper %}
", "SonataUserBundle:Admin/Security:login.html.twig", "/home/ch/proyectos/php/obrasSociales/vendor/sonata-project/user-bundle/src/Resources/views/Admin/Security/login.html.twig");
    }
}

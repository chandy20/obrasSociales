<?php

/* SonataAdminBundle:CRUD:edit_boolean.html.twig */
class __TwigTemplate_41220ea6c829f5f5698b54d0e65e7993b5f51a555805c4deb97d85a412fafc5c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'field' => array($this, 'block_field'),
            'label' => array($this, 'block_label'),
            'errors' => array($this, 'block_errors'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8552005916e97fd54b7954c3241ae64b74371dc45adebdacb83d86b019570b49 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8552005916e97fd54b7954c3241ae64b74371dc45adebdacb83d86b019570b49->enter($__internal_8552005916e97fd54b7954c3241ae64b74371dc45adebdacb83d86b019570b49_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataAdminBundle:CRUD:edit_boolean.html.twig"));

        // line 11
        echo "
<div>
    <div class=\"sonata-ba-field ";
        // line 13
        if ((twig_length_filter($this->env, $this->getAttribute($this->getAttribute(($context["field_element"] ?? $this->getContext($context, "field_element")), "vars", array()), "errors", array())) > 0)) {
            echo "sonata-ba-field-error";
        }
        echo "\">
        ";
        // line 14
        $this->displayBlock('field', $context, $blocks);
        // line 15
        echo "        ";
        $this->displayBlock('label', $context, $blocks);
        // line 23
        echo "
        <div class=\"sonata-ba-field-error-messages\">
            ";
        // line 25
        $this->displayBlock('errors', $context, $blocks);
        // line 26
        echo "        </div>

    </div>
</div>
";
        
        $__internal_8552005916e97fd54b7954c3241ae64b74371dc45adebdacb83d86b019570b49->leave($__internal_8552005916e97fd54b7954c3241ae64b74371dc45adebdacb83d86b019570b49_prof);

    }

    // line 14
    public function block_field($context, array $blocks = array())
    {
        $__internal_8f32505a3c7c2ce6b4706da866a4d3a507fc53ee35e425f210710406fd8a01b1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8f32505a3c7c2ce6b4706da866a4d3a507fc53ee35e425f210710406fd8a01b1->enter($__internal_8f32505a3c7c2ce6b4706da866a4d3a507fc53ee35e425f210710406fd8a01b1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "field"));

        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock(($context["field_element"] ?? $this->getContext($context, "field_element")), 'widget');
        
        $__internal_8f32505a3c7c2ce6b4706da866a4d3a507fc53ee35e425f210710406fd8a01b1->leave($__internal_8f32505a3c7c2ce6b4706da866a4d3a507fc53ee35e425f210710406fd8a01b1_prof);

    }

    // line 15
    public function block_label($context, array $blocks = array())
    {
        $__internal_d48022f802e660c96f8edbaf4cbfd83fabcf0f99e38f9f0c3ddd5116824f93ad = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d48022f802e660c96f8edbaf4cbfd83fabcf0f99e38f9f0c3ddd5116824f93ad->enter($__internal_d48022f802e660c96f8edbaf4cbfd83fabcf0f99e38f9f0c3ddd5116824f93ad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "label"));

        // line 16
        echo "            ";
        if ($this->getAttribute($this->getAttribute(($context["field_description"] ?? null), "options", array(), "any", false, true), "name", array(), "any", true, true)) {
            // line 17
            echo "                ";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock(($context["field_element"] ?? $this->getContext($context, "field_element")), 'label', (twig_test_empty($_label_ = $this->getAttribute($this->getAttribute(($context["field_description"] ?? $this->getContext($context, "field_description")), "options", array()), "name", array())) ? array() : array("label" => $_label_)));
            echo "
            ";
        } else {
            // line 19
            echo "                ";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock(($context["field_element"] ?? $this->getContext($context, "field_element")), 'label');
            echo "
            ";
        }
        // line 21
        echo "            <br>
        ";
        
        $__internal_d48022f802e660c96f8edbaf4cbfd83fabcf0f99e38f9f0c3ddd5116824f93ad->leave($__internal_d48022f802e660c96f8edbaf4cbfd83fabcf0f99e38f9f0c3ddd5116824f93ad_prof);

    }

    // line 25
    public function block_errors($context, array $blocks = array())
    {
        $__internal_60eeb8ab3afca6452df91a609d2b693e4bc3c951e641d436cb5ac8dee469d849 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_60eeb8ab3afca6452df91a609d2b693e4bc3c951e641d436cb5ac8dee469d849->enter($__internal_60eeb8ab3afca6452df91a609d2b693e4bc3c951e641d436cb5ac8dee469d849_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "errors"));

        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock(($context["field_element"] ?? $this->getContext($context, "field_element")), 'errors');
        
        $__internal_60eeb8ab3afca6452df91a609d2b693e4bc3c951e641d436cb5ac8dee469d849->leave($__internal_60eeb8ab3afca6452df91a609d2b693e4bc3c951e641d436cb5ac8dee469d849_prof);

    }

    public function getTemplateName()
    {
        return "SonataAdminBundle:CRUD:edit_boolean.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  98 => 25,  90 => 21,  84 => 19,  78 => 17,  75 => 16,  69 => 15,  57 => 14,  46 => 26,  44 => 25,  40 => 23,  37 => 15,  35 => 14,  29 => 13,  25 => 11,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#

This file is part of the Sonata package.

(c) Thomas Rabaix <thomas.rabaix@sonata-project.org>

For the full copyright and license information, please view the LICENSE
file that was distributed with this source code.

#}

<div>
    <div class=\"sonata-ba-field {% if field_element.vars.errors|length > 0 %}sonata-ba-field-error{% endif %}\">
        {% block field %}{{ form_widget(field_element) }}{% endblock %}
        {% block label %}
            {% if field_description.options.name is defined %}
                {{ form_label(field_element, field_description.options.name) }}
            {% else %}
                {{ form_label(field_element) }}
            {% endif %}
            <br>
        {% endblock %}

        <div class=\"sonata-ba-field-error-messages\">
            {% block errors %}{{ form_errors(field_element) }}{% endblock %}
        </div>

    </div>
</div>
", "SonataAdminBundle:CRUD:edit_boolean.html.twig", "/home/ch/proyectos/php/obrasSociales/vendor/sonata-project/admin-bundle/src/Resources/views/CRUD/edit_boolean.html.twig");
    }
}

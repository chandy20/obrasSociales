<?php

/* @Framework/Form/range_widget.html.php */
class __TwigTemplate_ec97a01c0f40d88dacf3c50b8d1cc0191007a0af4fa0ae0600b0c1f617bc3953 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b40c9a896aa32ac26d973cc5af74412b29b46f67abab1f4b37bb81b21b8e327f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b40c9a896aa32ac26d973cc5af74412b29b46f67abab1f4b37bb81b21b8e327f->enter($__internal_b40c9a896aa32ac26d973cc5af74412b29b46f67abab1f4b37bb81b21b8e327f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/range_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'range'));
";
        
        $__internal_b40c9a896aa32ac26d973cc5af74412b29b46f67abab1f4b37bb81b21b8e327f->leave($__internal_b40c9a896aa32ac26d973cc5af74412b29b46f67abab1f4b37bb81b21b8e327f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/range_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'range'));
", "@Framework/Form/range_widget.html.php", "/home/ch/proyectos/php/obrasSociales/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/range_widget.html.php");
    }
}

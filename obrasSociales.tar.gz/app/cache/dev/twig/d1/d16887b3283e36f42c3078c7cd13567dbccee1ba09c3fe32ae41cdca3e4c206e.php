<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_8a1641c9b4d93861a5329af1aac33471c6c4845f7bec51a798cae4cd71e10655 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6791af39801eb2e489e019840fb01d43149087a5842698515b3e5bcb9aefc0cc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6791af39801eb2e489e019840fb01d43149087a5842698515b3e5bcb9aefc0cc->enter($__internal_6791af39801eb2e489e019840fb01d43149087a5842698515b3e5bcb9aefc0cc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_6791af39801eb2e489e019840fb01d43149087a5842698515b3e5bcb9aefc0cc->leave($__internal_6791af39801eb2e489e019840fb01d43149087a5842698515b3e5bcb9aefc0cc_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "@Framework/Form/button_label.html.php", "/home/ch/proyectos/php/obrasSociales/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/button_label.html.php");
    }
}

<?php

/* SonataUserBundle:Admin/Security/Resetting:reset.html.twig */
class __TwigTemplate_4e6a25cb4bd41dd74f0d97030dfe04881eaf3437c2d183d61ad61216b2074771 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'sonata_nav' => array($this, 'block_sonata_nav'),
            'logo' => array($this, 'block_logo'),
            'sonata_left_side' => array($this, 'block_sonata_left_side'),
            'body_attributes' => array($this, 'block_body_attributes'),
            'sonata_wrapper' => array($this, 'block_sonata_wrapper'),
            'sonata_user_reset_form' => array($this, 'block_sonata_user_reset_form'),
        );
    }

    protected function doGetParent(array $context)
    {
        // line 12
        return $this->loadTemplate(($context["base_template"] ?? $this->getContext($context, "base_template")), "SonataUserBundle:Admin/Security/Resetting:reset.html.twig", 12);
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ca05460d1bf5327e0ff32e97a949c08d001c997d1324b7c14ae23e50ae476e1f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ca05460d1bf5327e0ff32e97a949c08d001c997d1324b7c14ae23e50ae476e1f->enter($__internal_ca05460d1bf5327e0ff32e97a949c08d001c997d1324b7c14ae23e50ae476e1f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataUserBundle:Admin/Security/Resetting:reset.html.twig"));

        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ca05460d1bf5327e0ff32e97a949c08d001c997d1324b7c14ae23e50ae476e1f->leave($__internal_ca05460d1bf5327e0ff32e97a949c08d001c997d1324b7c14ae23e50ae476e1f_prof);

    }

    // line 14
    public function block_sonata_nav($context, array $blocks = array())
    {
        $__internal_cfcfc944bc5a9f076eed5f201950fe1fa3b194356c00e2162c9d73990c654900 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cfcfc944bc5a9f076eed5f201950fe1fa3b194356c00e2162c9d73990c654900->enter($__internal_cfcfc944bc5a9f076eed5f201950fe1fa3b194356c00e2162c9d73990c654900_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_nav"));

        
        $__internal_cfcfc944bc5a9f076eed5f201950fe1fa3b194356c00e2162c9d73990c654900->leave($__internal_cfcfc944bc5a9f076eed5f201950fe1fa3b194356c00e2162c9d73990c654900_prof);

    }

    // line 17
    public function block_logo($context, array $blocks = array())
    {
        $__internal_fb0b33a3013cfae4a1f9d576af6372584ab381899481523ea59beadd45945813 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fb0b33a3013cfae4a1f9d576af6372584ab381899481523ea59beadd45945813->enter($__internal_fb0b33a3013cfae4a1f9d576af6372584ab381899481523ea59beadd45945813_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "logo"));

        
        $__internal_fb0b33a3013cfae4a1f9d576af6372584ab381899481523ea59beadd45945813->leave($__internal_fb0b33a3013cfae4a1f9d576af6372584ab381899481523ea59beadd45945813_prof);

    }

    // line 20
    public function block_sonata_left_side($context, array $blocks = array())
    {
        $__internal_e125c5aad9b2f283d531558d4f79dd2c178bbf760073bd3c4ab41ffddbb9b65d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e125c5aad9b2f283d531558d4f79dd2c178bbf760073bd3c4ab41ffddbb9b65d->enter($__internal_e125c5aad9b2f283d531558d4f79dd2c178bbf760073bd3c4ab41ffddbb9b65d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_left_side"));

        
        $__internal_e125c5aad9b2f283d531558d4f79dd2c178bbf760073bd3c4ab41ffddbb9b65d->leave($__internal_e125c5aad9b2f283d531558d4f79dd2c178bbf760073bd3c4ab41ffddbb9b65d_prof);

    }

    // line 23
    public function block_body_attributes($context, array $blocks = array())
    {
        $__internal_d2489b258e1fcf8c6160eab5ded0cb32b0b04221ca32180b70032ac65d8b49c5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d2489b258e1fcf8c6160eab5ded0cb32b0b04221ca32180b70032ac65d8b49c5->enter($__internal_d2489b258e1fcf8c6160eab5ded0cb32b0b04221ca32180b70032ac65d8b49c5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_attributes"));

        echo "class=\"sonata-bc login-page\"";
        
        $__internal_d2489b258e1fcf8c6160eab5ded0cb32b0b04221ca32180b70032ac65d8b49c5->leave($__internal_d2489b258e1fcf8c6160eab5ded0cb32b0b04221ca32180b70032ac65d8b49c5_prof);

    }

    // line 25
    public function block_sonata_wrapper($context, array $blocks = array())
    {
        $__internal_f40971222cbb7eb9eb6de707a13108b9dffffe92a64e712e7602c0f710588c8f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f40971222cbb7eb9eb6de707a13108b9dffffe92a64e712e7602c0f710588c8f->enter($__internal_f40971222cbb7eb9eb6de707a13108b9dffffe92a64e712e7602c0f710588c8f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_wrapper"));

        // line 26
        echo "
    <div class=\"login-box\">
        <div class=\"login-logo\">
            <a href=\"";
        // line 29
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("sonata_admin_dashboard");
        echo "\">
                ";
        // line 30
        if ((("single_text" == $this->getAttribute(($context["admin_pool"] ?? $this->getContext($context, "admin_pool")), "getOption", array(0 => "title_mode"), "method")) || ("both" == $this->getAttribute(($context["admin_pool"] ?? $this->getContext($context, "admin_pool")), "getOption", array(0 => "title_mode"), "method")))) {
            // line 31
            echo "                    <span>";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["admin_pool"] ?? $this->getContext($context, "admin_pool")), "title", array()), "html", null, true);
            echo "</span>
                ";
        }
        // line 33
        echo "            </a>
        </div>
        <div class=\"login-box-body\">
            ";
        // line 36
        $this->displayBlock('sonata_user_reset_form', $context, $blocks);
        // line 54
        echo "        </div>
    </div>

";
        
        $__internal_f40971222cbb7eb9eb6de707a13108b9dffffe92a64e712e7602c0f710588c8f->leave($__internal_f40971222cbb7eb9eb6de707a13108b9dffffe92a64e712e7602c0f710588c8f_prof);

    }

    // line 36
    public function block_sonata_user_reset_form($context, array $blocks = array())
    {
        $__internal_9391d31a83e95b6e6af2f9271c817fb27c55869cb0b3dd4b3a7c8e627d197e82 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9391d31a83e95b6e6af2f9271c817fb27c55869cb0b3dd4b3a7c8e627d197e82->enter($__internal_9391d31a83e95b6e6af2f9271c817fb27c55869cb0b3dd4b3a7c8e627d197e82_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sonata_user_reset_form"));

        // line 37
        echo "                <p class=\"login-box-msg\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("resetting.reset.submit", array(), "FOSUserBundle"), "html", null, true);
        echo "</p>
                <form action=\"";
        // line 38
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("sonata_user_admin_resetting_reset", array("token" => ($context["token"] ?? $this->getContext($context, "token")))), "html", null, true);
        echo "\" method=\"post\" role=\"form\">
                    <div class=\"form-group\">
                        <input type=\"password\" class=\"form-control\" id=\"fos_user_resetting_form_new_first\"  name=\"fos_user_resetting_form[new][first]\" required=\"required\" placeholder=\"";
        // line 40
        echo twig_escape_filter($this->env, twig_replace_filter($this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("form.new_password", array(), "FOSUserBundle"), array(":" => "")), "html", null, true);
        echo "\"/>
                    </div>
                    <div class=\"form-group\">
                        <input type=\"password\" class=\"form-control\" id=\"fos_user_resetting_form_new_second\"  name=\"fos_user_resetting_form[new][second]\" required=\"required\" placeholder=\"";
        // line 43
        echo twig_escape_filter($this->env, twig_replace_filter($this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("form.new_password_confirmation", array(), "FOSUserBundle"), array(":" => "")), "html", null, true);
        echo "\"/>
                    </div>
                    ";
        // line 45
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "_token", array()), 'widget');
        echo "

                    <div class=\"row\">
                        <div class=\"col-xs-12\">
                            <button type=\"submit\" class=\"btn btn-primary btn-block btn-flat\">";
        // line 49
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("resetting.reset.submit", array(), "FOSUserBundle"), "html", null, true);
        echo "</button>
                        </div>
                    </div>
                </form>
            ";
        
        $__internal_9391d31a83e95b6e6af2f9271c817fb27c55869cb0b3dd4b3a7c8e627d197e82->leave($__internal_9391d31a83e95b6e6af2f9271c817fb27c55869cb0b3dd4b3a7c8e627d197e82_prof);

    }

    public function getTemplateName()
    {
        return "SonataUserBundle:Admin/Security/Resetting:reset.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  157 => 49,  150 => 45,  145 => 43,  139 => 40,  134 => 38,  129 => 37,  123 => 36,  113 => 54,  111 => 36,  106 => 33,  100 => 31,  98 => 30,  94 => 29,  89 => 26,  83 => 25,  71 => 23,  60 => 20,  49 => 17,  38 => 14,  23 => 12,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#

This file is part of the Sonata package.

(c) Thomas Rabaix <thomas.rabaix@sonata-project.org>

For the full copyright and license information, please view the LICENSE
file that was distributed with this source code.

#}

{% extends base_template %}

{% block sonata_nav %}
{% endblock sonata_nav %}

{% block logo %}
{% endblock logo %}

{% block sonata_left_side %}
{% endblock sonata_left_side %}

{% block body_attributes %}class=\"sonata-bc login-page\"{% endblock %}

{% block sonata_wrapper %}

    <div class=\"login-box\">
        <div class=\"login-logo\">
            <a href=\"{{ path('sonata_admin_dashboard') }}\">
                {% if 'single_text' == admin_pool.getOption('title_mode') or 'both' == admin_pool.getOption('title_mode') %}
                    <span>{{ admin_pool.title }}</span>
                {% endif %}
            </a>
        </div>
        <div class=\"login-box-body\">
            {% block sonata_user_reset_form %}
                <p class=\"login-box-msg\">{{ 'resetting.reset.submit'|trans({}, 'FOSUserBundle') }}</p>
                <form action=\"{{ path('sonata_user_admin_resetting_reset', {'token': token}) }}\" method=\"post\" role=\"form\">
                    <div class=\"form-group\">
                        <input type=\"password\" class=\"form-control\" id=\"fos_user_resetting_form_new_first\"  name=\"fos_user_resetting_form[new][first]\" required=\"required\" placeholder=\"{{ 'form.new_password'|trans({}, 'FOSUserBundle')|replace({':': ''}) }}\"/>
                    </div>
                    <div class=\"form-group\">
                        <input type=\"password\" class=\"form-control\" id=\"fos_user_resetting_form_new_second\"  name=\"fos_user_resetting_form[new][second]\" required=\"required\" placeholder=\"{{ 'form.new_password_confirmation'|trans({}, 'FOSUserBundle')|replace({':': ''}) }}\"/>
                    </div>
                    {{ form_widget(form._token) }}

                    <div class=\"row\">
                        <div class=\"col-xs-12\">
                            <button type=\"submit\" class=\"btn btn-primary btn-block btn-flat\">{{ 'resetting.reset.submit'|trans({}, 'FOSUserBundle') }}</button>
                        </div>
                    </div>
                </form>
            {% endblock %}
        </div>
    </div>

{% endblock sonata_wrapper %}
", "SonataUserBundle:Admin/Security/Resetting:reset.html.twig", "/home/ch/proyectos/php/obrasSociales/vendor/sonata-project/user-bundle/src/Resources/views/Admin/Security/Resetting/reset.html.twig");
    }
}

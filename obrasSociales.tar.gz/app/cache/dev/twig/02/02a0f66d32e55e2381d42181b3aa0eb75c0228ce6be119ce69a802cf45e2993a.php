<?php

/* WebProfilerBundle:Profiler:toolbar_redirect.html.twig */
class __TwigTemplate_0bd046dd32a51807543e4e652b6d77df7f8b4db3c6e1e6bb11e83164d8120644 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_66c16069bc5f1f6fc9110c43d17c5de552f4c76429c522f892a1038a77ea81a8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_66c16069bc5f1f6fc9110c43d17c5de552f4c76429c522f892a1038a77ea81a8->enter($__internal_66c16069bc5f1f6fc9110c43d17c5de552f4c76429c522f892a1038a77ea81a8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_66c16069bc5f1f6fc9110c43d17c5de552f4c76429c522f892a1038a77ea81a8->leave($__internal_66c16069bc5f1f6fc9110c43d17c5de552f4c76429c522f892a1038a77ea81a8_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_80f61cb39bd45ab07857ffd3e3eda39732ad385124133879ef01bbf12bb08029 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_80f61cb39bd45ab07857ffd3e3eda39732ad385124133879ef01bbf12bb08029->enter($__internal_80f61cb39bd45ab07857ffd3e3eda39732ad385124133879ef01bbf12bb08029_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Redirection Intercepted";
        
        $__internal_80f61cb39bd45ab07857ffd3e3eda39732ad385124133879ef01bbf12bb08029->leave($__internal_80f61cb39bd45ab07857ffd3e3eda39732ad385124133879ef01bbf12bb08029_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_db68b3fa6d6346e1b6b240537b6017f2d04e4641f2e28eeba53ad47e70c82fba = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_db68b3fa6d6346e1b6b240537b6017f2d04e4641f2e28eeba53ad47e70c82fba->enter($__internal_db68b3fa6d6346e1b6b240537b6017f2d04e4641f2e28eeba53ad47e70c82fba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"";
        // line 8
        echo twig_escape_filter($this->env, ($context["location"] ?? $this->getContext($context, "location")), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, ($context["location"] ?? $this->getContext($context, "location")), "html", null, true);
        echo "</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
";
        
        $__internal_db68b3fa6d6346e1b6b240537b6017f2d04e4641f2e28eeba53ad47e70c82fba->leave($__internal_db68b3fa6d6346e1b6b240537b6017f2d04e4641f2e28eeba53ad47e70c82fba_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:toolbar_redirect.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  57 => 8,  53 => 6,  47 => 5,  35 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block title 'Redirection Intercepted' %}

{% block body %}
    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"{{ location }}\">{{ location }}</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
{% endblock %}
", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", "/home/ch/proyectos/php/obrasSociales/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Profiler/toolbar_redirect.html.twig");
    }
}

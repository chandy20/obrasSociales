<?php

/* @Framework/Form/email_widget.html.php */
class __TwigTemplate_20723e34093818b84e90f0493c52ac1e5c153d36c410a7f5e2d8130a0ac34328 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0dd0a9028b3744f5ddbcedd824118bd7449e5ead074744bb1a01ed9d77c09126 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0dd0a9028b3744f5ddbcedd824118bd7449e5ead074744bb1a01ed9d77c09126->enter($__internal_0dd0a9028b3744f5ddbcedd824118bd7449e5ead074744bb1a01ed9d77c09126_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/email_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'email')) ?>
";
        
        $__internal_0dd0a9028b3744f5ddbcedd824118bd7449e5ead074744bb1a01ed9d77c09126->leave($__internal_0dd0a9028b3744f5ddbcedd824118bd7449e5ead074744bb1a01ed9d77c09126_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/email_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'email')) ?>
", "@Framework/Form/email_widget.html.php", "/home/ch/proyectos/php/obrasSociales/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/email_widget.html.php");
    }
}

<?php

/* SonataAdminBundle:CRUD:show_boolean.html.twig */
class __TwigTemplate_ca7a31f11145eee9a5f1a8ed6b48a9a6356fcc7b6b322f88f6c98ca56d5f0f81 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 12
        $this->parent = $this->loadTemplate("@SonataAdmin/CRUD/base_show_field.html.twig", "SonataAdminBundle:CRUD:show_boolean.html.twig", 12);
        $this->blocks = array(
            'field' => array($this, 'block_field'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@SonataAdmin/CRUD/base_show_field.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_155be65e6f3c41a64d7ce1e1965a50789579e78609ee70e2f3974bc8562a3ae9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_155be65e6f3c41a64d7ce1e1965a50789579e78609ee70e2f3974bc8562a3ae9->enter($__internal_155be65e6f3c41a64d7ce1e1965a50789579e78609ee70e2f3974bc8562a3ae9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataAdminBundle:CRUD:show_boolean.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_155be65e6f3c41a64d7ce1e1965a50789579e78609ee70e2f3974bc8562a3ae9->leave($__internal_155be65e6f3c41a64d7ce1e1965a50789579e78609ee70e2f3974bc8562a3ae9_prof);

    }

    // line 14
    public function block_field($context, array $blocks = array())
    {
        $__internal_1cc6770cca55cfad1ce1e2bb4f75b9b9dcbd065e86ec1020a03d14fc666b96db = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1cc6770cca55cfad1ce1e2bb4f75b9b9dcbd065e86ec1020a03d14fc666b96db->enter($__internal_1cc6770cca55cfad1ce1e2bb4f75b9b9dcbd065e86ec1020a03d14fc666b96db_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "field"));

        // line 15
        $this->loadTemplate("@SonataAdmin/CRUD/display_boolean.html.twig", "SonataAdminBundle:CRUD:show_boolean.html.twig", 15)->display($context);
        
        $__internal_1cc6770cca55cfad1ce1e2bb4f75b9b9dcbd065e86ec1020a03d14fc666b96db->leave($__internal_1cc6770cca55cfad1ce1e2bb4f75b9b9dcbd065e86ec1020a03d14fc666b96db_prof);

    }

    public function getTemplateName()
    {
        return "SonataAdminBundle:CRUD:show_boolean.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 15,  34 => 14,  11 => 12,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#

This file is part of the Sonata package.

(c) Thomas Rabaix <thomas.rabaix@sonata-project.org>

For the full copyright and license information, please view the LICENSE
file that was distributed with this source code.

#}

{% extends '@SonataAdmin/CRUD/base_show_field.html.twig' %}

{% block field %}
    {%- include '@SonataAdmin/CRUD/display_boolean.html.twig' -%}
{% endblock %}
", "SonataAdminBundle:CRUD:show_boolean.html.twig", "/home/ch/proyectos/php/obrasSociales/vendor/sonata-project/admin-bundle/src/Resources/views/CRUD/show_boolean.html.twig");
    }
}

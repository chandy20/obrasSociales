<?php

/* SonataAdminBundle:CRUD:edit_array.html.twig */
class __TwigTemplate_e3f4b70f101e4e9f2ed4cc83eba05c2e71f011148194943a85c03d30bd6cc017 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'field' => array($this, 'block_field'),
        );
    }

    protected function doGetParent(array $context)
    {
        // line 12
        return $this->loadTemplate(($context["base_template"] ?? $this->getContext($context, "base_template")), "SonataAdminBundle:CRUD:edit_array.html.twig", 12);
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bcec2f16bd51158fb089983f5666fd868a0cd4899b339a28c118ea31331c52e9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bcec2f16bd51158fb089983f5666fd868a0cd4899b339a28c118ea31331c52e9->enter($__internal_bcec2f16bd51158fb089983f5666fd868a0cd4899b339a28c118ea31331c52e9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataAdminBundle:CRUD:edit_array.html.twig"));

        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_bcec2f16bd51158fb089983f5666fd868a0cd4899b339a28c118ea31331c52e9->leave($__internal_bcec2f16bd51158fb089983f5666fd868a0cd4899b339a28c118ea31331c52e9_prof);

    }

    // line 14
    public function block_field($context, array $blocks = array())
    {
        $__internal_4c73f515957cfd37b4e078ad589204d665144358542d19db06099d2ce37bd0a0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4c73f515957cfd37b4e078ad589204d665144358542d19db06099d2ce37bd0a0->enter($__internal_4c73f515957cfd37b4e078ad589204d665144358542d19db06099d2ce37bd0a0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "field"));

        // line 15
        echo "    <span class=\"edit\">
        ";
        // line 16
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock(($context["field_element"] ?? $this->getContext($context, "field_element")), 'widget', array("attr" => array("class" => "title")));
        echo "
    </span>
";
        
        $__internal_4c73f515957cfd37b4e078ad589204d665144358542d19db06099d2ce37bd0a0->leave($__internal_4c73f515957cfd37b4e078ad589204d665144358542d19db06099d2ce37bd0a0_prof);

    }

    public function getTemplateName()
    {
        return "SonataAdminBundle:CRUD:edit_array.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  42 => 16,  39 => 15,  33 => 14,  18 => 12,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#

This file is part of the Sonata package.

(c) Thomas Rabaix <thomas.rabaix@sonata-project.org>

For the full copyright and license information, please view the LICENSE
file that was distributed with this source code.

#}

{% extends base_template %}

{% block field %}
    <span class=\"edit\">
        {{ form_widget(field_element, {'attr': {'class' : 'title'}}) }}
    </span>
{% endblock %}
", "SonataAdminBundle:CRUD:edit_array.html.twig", "/home/ch/proyectos/php/obrasSociales/vendor/sonata-project/admin-bundle/src/Resources/views/CRUD/edit_array.html.twig");
    }
}

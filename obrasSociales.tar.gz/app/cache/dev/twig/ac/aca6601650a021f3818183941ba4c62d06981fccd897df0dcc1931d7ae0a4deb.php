<?php

/* SonataAdminBundle:CRUD:edit_text.html.twig */
class __TwigTemplate_e3d4cfbbd201a7eba0f96441e506a2a4dff0e756e0a9633a9a1c29f1950b2368 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'field' => array($this, 'block_field'),
        );
    }

    protected function doGetParent(array $context)
    {
        // line 12
        return $this->loadTemplate(($context["base_template"] ?? $this->getContext($context, "base_template")), "SonataAdminBundle:CRUD:edit_text.html.twig", 12);
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3127aa4a7da4e657a89f9b074af0297d579f3c5f535788aaec386d4cc26f12fe = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3127aa4a7da4e657a89f9b074af0297d579f3c5f535788aaec386d4cc26f12fe->enter($__internal_3127aa4a7da4e657a89f9b074af0297d579f3c5f535788aaec386d4cc26f12fe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataAdminBundle:CRUD:edit_text.html.twig"));

        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3127aa4a7da4e657a89f9b074af0297d579f3c5f535788aaec386d4cc26f12fe->leave($__internal_3127aa4a7da4e657a89f9b074af0297d579f3c5f535788aaec386d4cc26f12fe_prof);

    }

    // line 14
    public function block_field($context, array $blocks = array())
    {
        $__internal_210d509bae5081c5c002e7a39c0fb9dbd2c5ccab98b9a3b9cbd6a56c12edd4b6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_210d509bae5081c5c002e7a39c0fb9dbd2c5ccab98b9a3b9cbd6a56c12edd4b6->enter($__internal_210d509bae5081c5c002e7a39c0fb9dbd2c5ccab98b9a3b9cbd6a56c12edd4b6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "field"));

        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock(($context["field_element"] ?? $this->getContext($context, "field_element")), 'widget', array("attr" => array("class" => "title")));
        
        $__internal_210d509bae5081c5c002e7a39c0fb9dbd2c5ccab98b9a3b9cbd6a56c12edd4b6->leave($__internal_210d509bae5081c5c002e7a39c0fb9dbd2c5ccab98b9a3b9cbd6a56c12edd4b6_prof);

    }

    public function getTemplateName()
    {
        return "SonataAdminBundle:CRUD:edit_text.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  33 => 14,  18 => 12,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#

This file is part of the Sonata package.

(c) Thomas Rabaix <thomas.rabaix@sonata-project.org>

For the full copyright and license information, please view the LICENSE
file that was distributed with this source code.

#}

{% extends base_template %}

{% block field %}{{ form_widget(field_element, {'attr': {'class' : 'title'}}) }}{% endblock %}
", "SonataAdminBundle:CRUD:edit_text.html.twig", "/home/ch/proyectos/php/obrasSociales/vendor/sonata-project/admin-bundle/src/Resources/views/CRUD/edit_text.html.twig");
    }
}

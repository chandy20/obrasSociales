<?php

/* FOSUserBundle:Resetting:checkEmail.html.twig */
class __TwigTemplate_29de91a430df8e4457b45d00a68343c78583fd82fb8266d9a6c358abd400e9bf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Resetting:checkEmail.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2302d1de763fa2fe1de9079ea3bfb381ac1f55cb0d9481c1d30f5ee288b52339 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2302d1de763fa2fe1de9079ea3bfb381ac1f55cb0d9481c1d30f5ee288b52339->enter($__internal_2302d1de763fa2fe1de9079ea3bfb381ac1f55cb0d9481c1d30f5ee288b52339_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:checkEmail.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_2302d1de763fa2fe1de9079ea3bfb381ac1f55cb0d9481c1d30f5ee288b52339->leave($__internal_2302d1de763fa2fe1de9079ea3bfb381ac1f55cb0d9481c1d30f5ee288b52339_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_1c3b8982fc2f4cd5a79badd882a4695d2acf0c2a2d3af6af727f1f5032f19796 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1c3b8982fc2f4cd5a79badd882a4695d2acf0c2a2d3af6af727f1f5032f19796->enter($__internal_1c3b8982fc2f4cd5a79badd882a4695d2acf0c2a2d3af6af727f1f5032f19796_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        echo "<p>
";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("resetting.check_email", array("%email%" => ($context["email"] ?? $this->getContext($context, "email"))), "FOSUserBundle"), "html", null, true);
        echo "
</p>
";
        
        $__internal_1c3b8982fc2f4cd5a79badd882a4695d2acf0c2a2d3af6af727f1f5032f19796->leave($__internal_1c3b8982fc2f4cd5a79badd882a4695d2acf0c2a2d3af6af727f1f5032f19796_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:checkEmail.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  43 => 5,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"FOSUserBundle::layout.html.twig\" %}

{% block fos_user_content %}
<p>
{{ 'resetting.check_email'|trans({'%email%': email}, 'FOSUserBundle') }}
</p>
{% endblock %}
", "FOSUserBundle:Resetting:checkEmail.html.twig", "/home/ch/proyectos/php/obrasSociales/vendor/friendsofsymfony/user-bundle/FOS/UserBundle/Resources/views/Resetting/checkEmail.html.twig");
    }
}

<?php

/* @Framework/Form/choice_options.html.php */
class __TwigTemplate_ce9d0f5c0e5981777b5e0a94e1a2288ef9820f3a8f14e86609a860584188c2ee extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fe0288c3c8e2e757753102cf3f2aad2c3214e09cf232048687ef247139d9f0fa = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fe0288c3c8e2e757753102cf3f2aad2c3214e09cf232048687ef247139d9f0fa->enter($__internal_fe0288c3c8e2e757753102cf3f2aad2c3214e09cf232048687ef247139d9f0fa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
";
        
        $__internal_fe0288c3c8e2e757753102cf3f2aad2c3214e09cf232048687ef247139d9f0fa->leave($__internal_fe0288c3c8e2e757753102cf3f2aad2c3214e09cf232048687ef247139d9f0fa_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_options.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
", "@Framework/Form/choice_options.html.php", "/home/ch/proyectos/php/obrasSociales/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/choice_options.html.php");
    }
}

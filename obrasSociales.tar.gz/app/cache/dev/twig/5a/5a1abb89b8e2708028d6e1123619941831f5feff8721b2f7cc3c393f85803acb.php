<?php

/* FrontendBundle:Solicitudes:new.html.twig */
class __TwigTemplate_9fab54c4197ae9f1e916bec619c1cd778cb735001e55334be63571031fc9775c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "FrontendBundle:Solicitudes:new.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_af6f8ac8cbbc3779927dfc18a45a3f0cc9f7c87a10e007aa5a07c5ab39e9acb6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_af6f8ac8cbbc3779927dfc18a45a3f0cc9f7c87a10e007aa5a07c5ab39e9acb6->enter($__internal_af6f8ac8cbbc3779927dfc18a45a3f0cc9f7c87a10e007aa5a07c5ab39e9acb6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FrontendBundle:Solicitudes:new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_af6f8ac8cbbc3779927dfc18a45a3f0cc9f7c87a10e007aa5a07c5ab39e9acb6->leave($__internal_af6f8ac8cbbc3779927dfc18a45a3f0cc9f7c87a10e007aa5a07c5ab39e9acb6_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_9953b8954fff53c727aa72597d1e3bb47b8b4869351ca0cc15c8faf7811070ce = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9953b8954fff53c727aa72597d1e3bb47b8b4869351ca0cc15c8faf7811070ce->enter($__internal_9953b8954fff53c727aa72597d1e3bb47b8b4869351ca0cc15c8faf7811070ce_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "<div class=\"top-content\">
    <div class=\"container\" style=\"width: 90% !important\">
        <div class=\"row\">
            <div class=\"col-sm-8 col-sm-offset-2 text\">
                <h1>Bienvenido a <strong>Formulario de Solicitudes </strong> AOS </h1>
                <div class=\"description\">
               \t    <p>
                        Retorno a la Pagina Principal de Obras Sociales. 
                        ingresa en <a href=\"http://obrassocialespolicia.org/obras/\"><strong>Obras Sociales</strong></a>, Bienvenido Al Portal Obras Sociales!
                    </p>
                </div>
            </div>
        </div>
      ";
        // line 17
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_start');
        echo "
\t\t<div class=\"row\">
            <div class=\"f1 col-md-20 form-box\">
                <h3><font color=\"#054e96\"> Formulario de Solicitudes</font></h3>
                
                <div align=\"float:center\"><img src=\"\\web\\bundles\\frontend\\images\\logo.png\" height=\"160\" width=\"200\"></div>
        \t\t<p><font color=\"#054e96\"><b>Asociación Obras Sociales en Beneficio de la Policia Nacional</b></p>
                <hr style=\"border-color:grey;\">
               
               
        \t\t<div class=\"col-md-12\">
               
    \t\t\t\t\t<div class=\"col-md-2\" ><b>
       \t\t\t\t\t\t";
        // line 30
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "solicitudfecha", array()), 'label');
        echo "
\t\t\t\t\t\t\t";
        // line 31
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "solicitudfecha", array()), 'errors');
        echo "
\t\t\t\t\t\t\t";
        // line 32
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "solicitudfecha", array()), 'widget');
        echo "
\t\t\t\t\t\t</div></b>
                        <div class=\"col-md-5\"> <b>
                            ";
        // line 35
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "idseccional", array()), 'label');
        echo "
                            ";
        // line 36
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "idseccional", array()), 'errors');
        echo "
                            ";
        // line 37
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "idseccional", array()), 'widget');
        echo "
                        </div></b>
                        <div class=\"col-md-5\"><b>
                            ";
        // line 40
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "idtiposolicitud", array()), 'label');
        echo "
                            ";
        // line 41
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "idtiposolicitud", array()), 'errors');
        echo "
                            ";
        // line 42
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "idtiposolicitud", array()), 'widget');
        echo "
                        </div></b>
                        
                        <div class=\"col-md-6\"><b>
                            ";
        // line 46
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "solicitudcedulasolicita", array()), 'label');
        echo "
                            ";
        // line 47
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "solicitudcedulasolicita", array()), 'errors');
        echo "
                            ";
        // line 48
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "solicitudcedulasolicita", array()), 'widget');
        echo "
                        </div></b>
                        <div class=\"col-md-6\"><b>
                            ";
        // line 51
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "idparentesco", array()), 'label');
        echo "
                            ";
        // line 52
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "idparentesco", array()), 'errors');
        echo "
                            ";
        // line 53
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "idparentesco", array()), 'widget');
        echo "
                        </div></b>
                        <div class=\"col-md-12\"><b>
                            ";
        // line 56
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "solicitudnombresolicita", array()), 'label');
        echo "
                            ";
        // line 57
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "solicitudnombresolicita", array()), 'errors');
        echo "
                            ";
        // line 58
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "solicitudnombresolicita", array()), 'widget');
        echo "
                        </div></b>
                </div>
               <div class=\"col-md-12\">
                        <hr style=\"border-color:white;\">
                        <hr style=\"border-color:white;\">
                        <hr style=\"border-color:white;\">
                        <h4><b>INFORMACION FUNCIONARIO POLICIAL</b></h4>
                        <hr style=\"border-color:white\"></div>

                <div class=\"col-md-12\"><b>
                        <div class=\"col-md-4\" ><b>
                            ";
        // line 70
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "solicitudcedulafuncionario", array()), 'label');
        echo "
                            ";
        // line 71
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "solicitudcedulafuncionario", array()), 'errors');
        echo "
                            ";
        // line 72
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "solicitudcedulafuncionario", array()), 'widget');
        echo "
                        </div></b>
                        <div class=\"col-md-4\">
                            ";
        // line 75
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "idgrado", array()), 'label');
        echo "
                            ";
        // line 76
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "idgrado", array()), 'errors');
        echo "
                            ";
        // line 77
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "idgrado", array()), 'widget');
        echo "
                        </div>
                        <div class=\"col-md-4\">
                            ";
        // line 80
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "unidad", array()), 'label');
        echo "
                            ";
        // line 81
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "unidad", array()), 'errors');
        echo "
                            ";
        // line 82
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "unidad", array()), 'widget');
        echo "
                            <hr style=\"border-color:white;\">
                        </div>
                        <div class=\"col-md-12\">
                            ";
        // line 86
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "solicitudnombrefuncionario", array()), 'label');
        echo "
                            ";
        // line 87
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "solicitudnombrefuncionario", array()), 'errors');
        echo "
                            ";
        // line 88
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "solicitudnombrefuncionario", array()), 'widget');
        echo "
                            <hr style=\"border-color:white;\">
                        </div>
                        <div class=\"col-md-4\">
                            ";
        // line 92
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "solicituddireccionfuncionario", array()), 'label');
        echo "
                            ";
        // line 93
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "solicituddireccionfuncionario", array()), 'errors');
        echo "
                            ";
        // line 94
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "solicituddireccionfuncionario", array()), 'widget');
        echo "
                        </div>
                        <div class=\"col-md-4\">
                            ";
        // line 97
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "solicitudtelefonosfuncionario", array()), 'label');
        echo "
                            ";
        // line 98
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "solicitudtelefonosfuncionario", array()), 'errors');
        echo "
                            ";
        // line 99
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "solicitudtelefonosfuncionario", array()), 'widget');
        echo "
                        </div>    
                        <div class=\"col-md-4\">
                            ";
        // line 102
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "antiguedad", array()), 'label');
        echo "
                            ";
        // line 103
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "antiguedad", array()), 'errors');
        echo "
                            ";
        // line 104
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "antiguedad", array()), 'widget');
        echo "
                        </div>  
                </div></b>

                <div class=\"col-md-12\"><b>
                        <div class=\"col-md-12\">  
                        <hr style=\"border-color:white;\">
                        <hr style=\"border-color:white;\">
                        <hr style=\"border-color:white;\">         
                        <h4><b>DESCRIPCION DE LA SOLICITUD</b></h4></div>

                        <div class=\"col-md-4\">
                            ";
        // line 116
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "idprogramas", array()), 'label');
        echo "
                            ";
        // line 117
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "idprogramas", array()), 'errors');
        echo "
                            ";
        // line 118
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "idprogramas", array()), 'widget');
        echo "
                        </div>
                        
                        <div class=\"col-md-8\">
                            ";
        // line 122
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "solicituddescripcion", array()), 'label');
        echo "
                            ";
        // line 123
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "solicituddescripcion", array()), 'errors');
        echo "
                            ";
        // line 124
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "solicituddescripcion", array()), 'widget');
        echo "
                        </div></b>

                        <div class=\"col-md-12\"><b>
                         <div class=\"prueba1\">
                         <hr style=\"border-color:white;\">
                         <hr style=\"border-color:white;\">
                        <h4><b>INFORMACION FAMILIAR Y PERSONAL</b></h4></div></div>
                
                        <div class=\"col-md-4 prueba1\">
                            ";
        // line 134
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "idestadocivil", array()), 'label');
        echo "
                            ";
        // line 135
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "idestadocivil", array()), 'errors');
        echo "
                            ";
        // line 136
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "idestadocivil", array()), 'widget');
        echo "
                        </div>
                        <div class=\"col-md-4 prueba1\">
                            ";
        // line 139
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "idingreso", array()), 'label');
        echo "
                            ";
        // line 140
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "idingreso", array()), 'errors');
        echo "
                            ";
        // line 141
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "idingreso", array()), 'widget');
        echo "
                        </div>
                        <div class=\"col-md-4 prueba1\">
                            ";
        // line 144
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "idpersonacargo", array()), 'label');
        echo "
                            ";
        // line 145
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "idpersonacargo", array()), 'errors');
        echo "
                            ";
        // line 146
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "idpersonacargo", array()), 'widget');
        echo "
                        </div>
                        <div class=\"col-md-4 prueba1\">
                            ";
        // line 149
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "idsituacionvivienda", array()), 'label');
        echo "
                            ";
        // line 150
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "idsituacionvivienda", array()), 'errors');
        echo "
                            ";
        // line 151
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "idsituacionvivienda", array()), 'widget');
        echo "
                        </div>
                        <div class=\"col-md-4 prueba1\">
                            ";
        // line 154
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "idmotivodeuda", array()), 'label');
        echo "
                            ";
        // line 155
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "idmotivodeuda", array()), 'errors');
        echo "
                            ";
        // line 156
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "idmotivodeuda", array()), 'widget');
        echo "
                        </div>
                        <div class=\"col-md-4 prueba1\">
                            ";
        // line 159
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "cantidadesbeneficio", array()), 'label');
        echo "
                            ";
        // line 160
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "cantidadesbeneficio", array()), 'errors');
        echo "
                            ";
        // line 161
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "cantidadesbeneficio", array()), 'widget');
        echo "
                        </div>
                        <div class=\"col-md-6 prueba1\">
                            ";
        // line 164
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "idconceptovisita", array()), 'label');
        echo "
                            ";
        // line 165
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "idconceptovisita", array()), 'errors');
        echo "
                            ";
        // line 166
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "idconceptovisita", array()), 'widget');
        echo "
                        </div>
                        <div class=\"col-md-6 prueba1\">
                            ";
        // line 169
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "idafiliadodibie", array()), 'label');
        echo "
                            ";
        // line 170
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "idafiliadodibie", array()), 'errors');
        echo "
                            ";
        // line 171
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "idafiliadodibie", array()), 'widget');
        echo "
                        </div>

                        <div class=\"col-md-12\">
                        <div class=\"prueba\">
                        <hr style=\"border-color:white;\">
                        <hr style=\"border-color:blue;\">
                        <h4><b>INFORMACION INSTITUCIONAL</b></h4></div></div>
             
                        <div class=\"col-md-6 prueba\">
                            ";
        // line 181
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "idpoblacionbeneficia", array()), 'label');
        echo "
                            ";
        // line 182
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "idpoblacionbeneficia", array()), 'errors');
        echo "
                            ";
        // line 183
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "idpoblacionbeneficia", array()), 'widget');
        echo "
                        </div>
                        <div class=\"col-md-6 prueba\">
                            ";
        // line 186
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "idviabilidadplaneacion", array()), 'label');
        echo "
                            ";
        // line 187
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "idviabilidadplaneacion", array()), 'errors');
        echo "
                            ";
        // line 188
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "idviabilidadplaneacion", array()), 'widget');
        echo "
                        </div>
                        <div class=\"col-md-6 prueba\">
                            ";
        // line 191
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "idzonaubicacion", array()), 'label');
        echo "
                            ";
        // line 192
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "idzonaubicacion", array()), 'errors');
        echo "
                            ";
        // line 193
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "idzonaubicacion", array()), 'widget');
        echo "
                        </div>
                        <div class=\"col-md-6 prueba\">
                            ";
        // line 196
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "idcantidadesbeneficioinst", array()), 'label');
        echo "
                            ";
        // line 197
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "idcantidadesbeneficioinst", array()), 'errors');
        echo "
                            ";
        // line 198
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "idcantidadesbeneficioinst", array()), 'widget');
        echo "
                            <hr style=\"border-color:white;\">
                        </div>
                        
                </div></b>
                
                  ";
        // line 204
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form');
        echo "
\t\t\t</div>
        </div>
        ";
        // line 207
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_end');
        echo "
\t</div>
    <ul class=\"record_actions\">
\t   
\t</ul>
    
</div>
";
        
        $__internal_9953b8954fff53c727aa72597d1e3bb47b8b4869351ca0cc15c8faf7811070ce->leave($__internal_9953b8954fff53c727aa72597d1e3bb47b8b4869351ca0cc15c8faf7811070ce_prof);

    }

    public function getTemplateName()
    {
        return "FrontendBundle:Solicitudes:new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  494 => 207,  488 => 204,  479 => 198,  475 => 197,  471 => 196,  465 => 193,  461 => 192,  457 => 191,  451 => 188,  447 => 187,  443 => 186,  437 => 183,  433 => 182,  429 => 181,  416 => 171,  412 => 170,  408 => 169,  402 => 166,  398 => 165,  394 => 164,  388 => 161,  384 => 160,  380 => 159,  374 => 156,  370 => 155,  366 => 154,  360 => 151,  356 => 150,  352 => 149,  346 => 146,  342 => 145,  338 => 144,  332 => 141,  328 => 140,  324 => 139,  318 => 136,  314 => 135,  310 => 134,  297 => 124,  293 => 123,  289 => 122,  282 => 118,  278 => 117,  274 => 116,  259 => 104,  255 => 103,  251 => 102,  245 => 99,  241 => 98,  237 => 97,  231 => 94,  227 => 93,  223 => 92,  216 => 88,  212 => 87,  208 => 86,  201 => 82,  197 => 81,  193 => 80,  187 => 77,  183 => 76,  179 => 75,  173 => 72,  169 => 71,  165 => 70,  150 => 58,  146 => 57,  142 => 56,  136 => 53,  132 => 52,  128 => 51,  122 => 48,  118 => 47,  114 => 46,  107 => 42,  103 => 41,  99 => 40,  93 => 37,  89 => 36,  85 => 35,  79 => 32,  75 => 31,  71 => 30,  55 => 17,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '::base.html.twig' %}

{% block body -%}
<div class=\"top-content\">
    <div class=\"container\" style=\"width: 90% !important\">
        <div class=\"row\">
            <div class=\"col-sm-8 col-sm-offset-2 text\">
                <h1>Bienvenido a <strong>Formulario de Solicitudes </strong> AOS </h1>
                <div class=\"description\">
               \t    <p>
                        Retorno a la Pagina Principal de Obras Sociales. 
                        ingresa en <a href=\"http://obrassocialespolicia.org/obras/\"><strong>Obras Sociales</strong></a>, Bienvenido Al Portal Obras Sociales!
                    </p>
                </div>
            </div>
        </div>
      {{ form_start(form) }}
\t\t<div class=\"row\">
            <div class=\"f1 col-md-20 form-box\">
                <h3><font color=\"#054e96\"> Formulario de Solicitudes</font></h3>
                
                <div align=\"float:center\"><img src=\"\\web\\bundles\\frontend\\images\\logo.png\" height=\"160\" width=\"200\"></div>
        \t\t<p><font color=\"#054e96\"><b>Asociación Obras Sociales en Beneficio de la Policia Nacional</b></p>
                <hr style=\"border-color:grey;\">
               
               
        \t\t<div class=\"col-md-12\">
               
    \t\t\t\t\t<div class=\"col-md-2\" ><b>
       \t\t\t\t\t\t{{ form_label(form.solicitudfecha) }}
\t\t\t\t\t\t\t{{ form_errors(form.solicitudfecha) }}
\t\t\t\t\t\t\t{{ form_widget(form.solicitudfecha) }}
\t\t\t\t\t\t</div></b>
                        <div class=\"col-md-5\"> <b>
                            {{ form_label(form.idseccional) }}
                            {{ form_errors(form.idseccional) }}
                            {{ form_widget(form.idseccional) }}
                        </div></b>
                        <div class=\"col-md-5\"><b>
                            {{ form_label(form.idtiposolicitud) }}
                            {{ form_errors(form.idtiposolicitud) }}
                            {{ form_widget(form.idtiposolicitud) }}
                        </div></b>
                        
                        <div class=\"col-md-6\"><b>
                            {{ form_label(form.solicitudcedulasolicita) }}
                            {{ form_errors(form.solicitudcedulasolicita) }}
                            {{ form_widget(form.solicitudcedulasolicita) }}
                        </div></b>
                        <div class=\"col-md-6\"><b>
                            {{ form_label(form.idparentesco) }}
                            {{ form_errors(form.idparentesco) }}
                            {{ form_widget(form.idparentesco) }}
                        </div></b>
                        <div class=\"col-md-12\"><b>
                            {{ form_label(form.solicitudnombresolicita) }}
                            {{ form_errors(form.solicitudnombresolicita) }}
                            {{ form_widget(form.solicitudnombresolicita) }}
                        </div></b>
                </div>
               <div class=\"col-md-12\">
                        <hr style=\"border-color:white;\">
                        <hr style=\"border-color:white;\">
                        <hr style=\"border-color:white;\">
                        <h4><b>INFORMACION FUNCIONARIO POLICIAL</b></h4>
                        <hr style=\"border-color:white\"></div>

                <div class=\"col-md-12\"><b>
                        <div class=\"col-md-4\" ><b>
                            {{ form_label(form.solicitudcedulafuncionario) }}
                            {{ form_errors(form.solicitudcedulafuncionario) }}
                            {{ form_widget(form.solicitudcedulafuncionario) }}
                        </div></b>
                        <div class=\"col-md-4\">
                            {{ form_label(form.idgrado) }}
                            {{ form_errors(form.idgrado) }}
                            {{ form_widget(form.idgrado) }}
                        </div>
                        <div class=\"col-md-4\">
                            {{ form_label(form.unidad) }}
                            {{ form_errors(form.unidad) }}
                            {{ form_widget(form.unidad) }}
                            <hr style=\"border-color:white;\">
                        </div>
                        <div class=\"col-md-12\">
                            {{ form_label(form.solicitudnombrefuncionario) }}
                            {{ form_errors(form.solicitudnombrefuncionario) }}
                            {{ form_widget(form.solicitudnombrefuncionario) }}
                            <hr style=\"border-color:white;\">
                        </div>
                        <div class=\"col-md-4\">
                            {{ form_label(form.solicituddireccionfuncionario) }}
                            {{ form_errors(form.solicituddireccionfuncionario) }}
                            {{ form_widget(form.solicituddireccionfuncionario) }}
                        </div>
                        <div class=\"col-md-4\">
                            {{ form_label(form.solicitudtelefonosfuncionario) }}
                            {{ form_errors(form.solicitudtelefonosfuncionario) }}
                            {{ form_widget(form.solicitudtelefonosfuncionario) }}
                        </div>    
                        <div class=\"col-md-4\">
                            {{ form_label(form.antiguedad) }}
                            {{ form_errors(form.antiguedad) }}
                            {{ form_widget(form.antiguedad) }}
                        </div>  
                </div></b>

                <div class=\"col-md-12\"><b>
                        <div class=\"col-md-12\">  
                        <hr style=\"border-color:white;\">
                        <hr style=\"border-color:white;\">
                        <hr style=\"border-color:white;\">         
                        <h4><b>DESCRIPCION DE LA SOLICITUD</b></h4></div>

                        <div class=\"col-md-4\">
                            {{ form_label(form.idprogramas) }}
                            {{ form_errors(form.idprogramas) }}
                            {{ form_widget(form.idprogramas) }}
                        </div>
                        
                        <div class=\"col-md-8\">
                            {{ form_label(form.solicituddescripcion) }}
                            {{ form_errors(form.solicituddescripcion) }}
                            {{ form_widget(form.solicituddescripcion) }}
                        </div></b>

                        <div class=\"col-md-12\"><b>
                         <div class=\"prueba1\">
                         <hr style=\"border-color:white;\">
                         <hr style=\"border-color:white;\">
                        <h4><b>INFORMACION FAMILIAR Y PERSONAL</b></h4></div></div>
                
                        <div class=\"col-md-4 prueba1\">
                            {{ form_label(form.idestadocivil) }}
                            {{ form_errors(form.idestadocivil) }}
                            {{ form_widget(form.idestadocivil) }}
                        </div>
                        <div class=\"col-md-4 prueba1\">
                            {{ form_label(form.idingreso) }}
                            {{ form_errors(form.idingreso) }}
                            {{ form_widget(form.idingreso) }}
                        </div>
                        <div class=\"col-md-4 prueba1\">
                            {{ form_label(form.idpersonacargo) }}
                            {{ form_errors(form.idpersonacargo) }}
                            {{ form_widget(form.idpersonacargo) }}
                        </div>
                        <div class=\"col-md-4 prueba1\">
                            {{ form_label(form.idsituacionvivienda) }}
                            {{ form_errors(form.idsituacionvivienda) }}
                            {{ form_widget(form.idsituacionvivienda) }}
                        </div>
                        <div class=\"col-md-4 prueba1\">
                            {{ form_label(form.idmotivodeuda) }}
                            {{ form_errors(form.idmotivodeuda) }}
                            {{ form_widget(form.idmotivodeuda) }}
                        </div>
                        <div class=\"col-md-4 prueba1\">
                            {{ form_label(form.cantidadesbeneficio) }}
                            {{ form_errors(form.cantidadesbeneficio) }}
                            {{ form_widget(form.cantidadesbeneficio) }}
                        </div>
                        <div class=\"col-md-6 prueba1\">
                            {{ form_label(form.idconceptovisita) }}
                            {{ form_errors(form.idconceptovisita) }}
                            {{ form_widget(form.idconceptovisita) }}
                        </div>
                        <div class=\"col-md-6 prueba1\">
                            {{ form_label(form.idafiliadodibie) }}
                            {{ form_errors(form.idafiliadodibie) }}
                            {{ form_widget(form.idafiliadodibie) }}
                        </div>

                        <div class=\"col-md-12\">
                        <div class=\"prueba\">
                        <hr style=\"border-color:white;\">
                        <hr style=\"border-color:blue;\">
                        <h4><b>INFORMACION INSTITUCIONAL</b></h4></div></div>
             
                        <div class=\"col-md-6 prueba\">
                            {{ form_label(form.idpoblacionbeneficia) }}
                            {{ form_errors(form.idpoblacionbeneficia) }}
                            {{ form_widget(form.idpoblacionbeneficia) }}
                        </div>
                        <div class=\"col-md-6 prueba\">
                            {{ form_label(form.idviabilidadplaneacion) }}
                            {{ form_errors(form.idviabilidadplaneacion) }}
                            {{ form_widget(form.idviabilidadplaneacion) }}
                        </div>
                        <div class=\"col-md-6 prueba\">
                            {{ form_label(form.idzonaubicacion) }}
                            {{ form_errors(form.idzonaubicacion) }}
                            {{ form_widget(form.idzonaubicacion) }}
                        </div>
                        <div class=\"col-md-6 prueba\">
                            {{ form_label(form.idcantidadesbeneficioinst) }}
                            {{ form_errors(form.idcantidadesbeneficioinst) }}
                            {{ form_widget(form.idcantidadesbeneficioinst) }}
                            <hr style=\"border-color:white;\">
                        </div>
                        
                </div></b>
                
                  {{ form(form) }}
\t\t\t</div>
        </div>
        {{ form_end(form) }}
\t</div>
    <ul class=\"record_actions\">
\t   
\t</ul>
    
</div>
{% endblock %}
", "FrontendBundle:Solicitudes:new.html.twig", "/home/ch/proyectos/php/obrasSociales/src/FrontendBundle/Resources/views/Solicitudes/new.html.twig");
    }
}

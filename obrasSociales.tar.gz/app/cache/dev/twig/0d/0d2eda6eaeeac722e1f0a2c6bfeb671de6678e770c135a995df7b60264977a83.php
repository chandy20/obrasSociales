<?php

/* SonataBlockBundle:Block:block_core_text.html.twig */
class __TwigTemplate_60857640ba4923ab0164f978c50a0492a4c5477991591b8f18b9549b0abae0d5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'block' => array($this, 'block_block'),
        );
    }

    protected function doGetParent(array $context)
    {
        // line 12
        return $this->loadTemplate($this->getAttribute($this->getAttribute(($context["sonata_block"] ?? $this->getContext($context, "sonata_block")), "templates", array()), "block_base", array()), "SonataBlockBundle:Block:block_core_text.html.twig", 12);
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_88ec0911315d016eaf2a9e49cad13d05714c129711a4a551ffac459c85f27d61 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_88ec0911315d016eaf2a9e49cad13d05714c129711a4a551ffac459c85f27d61->enter($__internal_88ec0911315d016eaf2a9e49cad13d05714c129711a4a551ffac459c85f27d61_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataBlockBundle:Block:block_core_text.html.twig"));

        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_88ec0911315d016eaf2a9e49cad13d05714c129711a4a551ffac459c85f27d61->leave($__internal_88ec0911315d016eaf2a9e49cad13d05714c129711a4a551ffac459c85f27d61_prof);

    }

    // line 14
    public function block_block($context, array $blocks = array())
    {
        $__internal_3e692059ca1f82f5d1b14a2b0468a42fd6bbb967337db04c227426bb00d830fe = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3e692059ca1f82f5d1b14a2b0468a42fd6bbb967337db04c227426bb00d830fe->enter($__internal_3e692059ca1f82f5d1b14a2b0468a42fd6bbb967337db04c227426bb00d830fe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "block"));

        // line 15
        echo "    ";
        echo $this->getAttribute(($context["settings"] ?? $this->getContext($context, "settings")), "content", array());
        echo "
";
        
        $__internal_3e692059ca1f82f5d1b14a2b0468a42fd6bbb967337db04c227426bb00d830fe->leave($__internal_3e692059ca1f82f5d1b14a2b0468a42fd6bbb967337db04c227426bb00d830fe_prof);

    }

    public function getTemplateName()
    {
        return "SonataBlockBundle:Block:block_core_text.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  39 => 15,  33 => 14,  18 => 12,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#

This file is part of the Sonata package.

(c) Thomas Rabaix <thomas.rabaix@sonata-project.org>

For the full copyright and license information, please view the LICENSE
file that was distributed with this source code.

#}

{% extends sonata_block.templates.block_base %}

{% block block %}
    {{ settings.content|raw }}
{% endblock %}
", "SonataBlockBundle:Block:block_core_text.html.twig", "/home/ch/proyectos/php/obrasSociales/vendor/sonata-project/block-bundle/src/Resources/views/Block/block_core_text.html.twig");
    }
}

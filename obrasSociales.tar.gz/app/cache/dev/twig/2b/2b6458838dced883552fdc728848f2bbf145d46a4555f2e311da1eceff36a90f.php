<?php

/* FOSUserBundle:Registration:register.html.twig */
class __TwigTemplate_fafa2be20ea3470044756d5ed4450847b6e6b546eac96a57972495e93c653679 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Registration:register.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9897865256a33c102e0eacd7d728617daf71f66c4019cbae929edf43d9c86194 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9897865256a33c102e0eacd7d728617daf71f66c4019cbae929edf43d9c86194->enter($__internal_9897865256a33c102e0eacd7d728617daf71f66c4019cbae929edf43d9c86194_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:register.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9897865256a33c102e0eacd7d728617daf71f66c4019cbae929edf43d9c86194->leave($__internal_9897865256a33c102e0eacd7d728617daf71f66c4019cbae929edf43d9c86194_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_12d908454fe23fa479c4495a6539a1630f03a98643090598327d9e95d0b1a5b8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_12d908454fe23fa479c4495a6539a1630f03a98643090598327d9e95d0b1a5b8->enter($__internal_12d908454fe23fa479c4495a6539a1630f03a98643090598327d9e95d0b1a5b8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Registration:register_content.html.twig", "FOSUserBundle:Registration:register.html.twig", 4)->display($context);
        
        $__internal_12d908454fe23fa479c4495a6539a1630f03a98643090598327d9e95d0b1a5b8->leave($__internal_12d908454fe23fa479c4495a6539a1630f03a98643090598327d9e95d0b1a5b8_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Registration:register.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"FOSUserBundle::layout.html.twig\" %}

{% block fos_user_content %}
{% include \"FOSUserBundle:Registration:register_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Registration:register.html.twig", "/home/ch/proyectos/php/obrasSociales/vendor/friendsofsymfony/user-bundle/FOS/UserBundle/Resources/views/Registration/register.html.twig");
    }
}

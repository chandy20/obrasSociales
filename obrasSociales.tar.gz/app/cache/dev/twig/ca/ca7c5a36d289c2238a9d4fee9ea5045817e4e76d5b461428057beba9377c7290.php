<?php

/* SonataBlockBundle:Block:block_no_page_available.html.twig */
class __TwigTemplate_32d5c9f007d73b8ca64bd0417cb64716431ae73a288e7acf6c704223beab13ad extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f29a2b98b76e996285d2b12399125ce7d16f0029fe4e54db9f9e54e8339a695d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f29a2b98b76e996285d2b12399125ce7d16f0029fe4e54db9f9e54e8339a695d->enter($__internal_f29a2b98b76e996285d2b12399125ce7d16f0029fe4e54db9f9e54e8339a695d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SonataBlockBundle:Block:block_no_page_available.html.twig"));

        
        $__internal_f29a2b98b76e996285d2b12399125ce7d16f0029fe4e54db9f9e54e8339a695d->leave($__internal_f29a2b98b76e996285d2b12399125ce7d16f0029fe4e54db9f9e54e8339a695d_prof);

    }

    public function getTemplateName()
    {
        return "SonataBlockBundle:Block:block_no_page_available.html.twig";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#

This file is part of the Sonata package.

(c) Thomas Rabaix <thomas.rabaix@sonata-project.org>

For the full copyright and license information, please view the LICENSE
file that was distributed with this source code.

#}
", "SonataBlockBundle:Block:block_no_page_available.html.twig", "/home/ch/proyectos/php/obrasSociales/vendor/sonata-project/block-bundle/src/Resources/views/Block/block_no_page_available.html.twig");
    }
}

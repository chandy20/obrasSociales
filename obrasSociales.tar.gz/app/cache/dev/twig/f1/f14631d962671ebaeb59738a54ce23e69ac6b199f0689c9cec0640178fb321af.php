<?php

/* FOSUserBundle:Resetting:email.txt.twig */
class __TwigTemplate_b61fd1bfff071c1cf1dbe1f7a22f265e0c1958bf66e8e86c9d9193448afae578 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'subject' => array($this, 'block_subject'),
            'body_text' => array($this, 'block_body_text'),
            'body_html' => array($this, 'block_body_html'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d09cef6dceca9a2d32c8282c82bd070a427a203394db94a13cdf9c647c8ca472 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d09cef6dceca9a2d32c8282c82bd070a427a203394db94a13cdf9c647c8ca472->enter($__internal_d09cef6dceca9a2d32c8282c82bd070a427a203394db94a13cdf9c647c8ca472_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:email.txt.twig"));

        // line 1
        $this->displayBlock('subject', $context, $blocks);
        // line 6
        $this->displayBlock('body_text', $context, $blocks);
        // line 11
        $this->displayBlock('body_html', $context, $blocks);
        
        $__internal_d09cef6dceca9a2d32c8282c82bd070a427a203394db94a13cdf9c647c8ca472->leave($__internal_d09cef6dceca9a2d32c8282c82bd070a427a203394db94a13cdf9c647c8ca472_prof);

    }

    // line 1
    public function block_subject($context, array $blocks = array())
    {
        $__internal_7eb97bb8aeb4d08d842145e279452d451e513557767b3e9aedcce15f1d42bf56 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7eb97bb8aeb4d08d842145e279452d451e513557767b3e9aedcce15f1d42bf56->enter($__internal_7eb97bb8aeb4d08d842145e279452d451e513557767b3e9aedcce15f1d42bf56_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "subject"));

        // line 3
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("resetting.email.subject", array("%username%" => $this->getAttribute(($context["user"] ?? $this->getContext($context, "user")), "username", array()), "%confirmationUrl%" => ($context["confirmationUrl"] ?? $this->getContext($context, "confirmationUrl"))), "FOSUserBundle");
        echo "
";
        
        $__internal_7eb97bb8aeb4d08d842145e279452d451e513557767b3e9aedcce15f1d42bf56->leave($__internal_7eb97bb8aeb4d08d842145e279452d451e513557767b3e9aedcce15f1d42bf56_prof);

    }

    // line 6
    public function block_body_text($context, array $blocks = array())
    {
        $__internal_355e82ad4d48909e76adc0fb825b8961da3565988d229a7ccee52c6f3b75e02f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_355e82ad4d48909e76adc0fb825b8961da3565988d229a7ccee52c6f3b75e02f->enter($__internal_355e82ad4d48909e76adc0fb825b8961da3565988d229a7ccee52c6f3b75e02f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_text"));

        // line 8
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("resetting.email.message", array("%username%" => $this->getAttribute(($context["user"] ?? $this->getContext($context, "user")), "username", array()), "%confirmationUrl%" => ($context["confirmationUrl"] ?? $this->getContext($context, "confirmationUrl"))), "FOSUserBundle");
        echo "
";
        
        $__internal_355e82ad4d48909e76adc0fb825b8961da3565988d229a7ccee52c6f3b75e02f->leave($__internal_355e82ad4d48909e76adc0fb825b8961da3565988d229a7ccee52c6f3b75e02f_prof);

    }

    // line 11
    public function block_body_html($context, array $blocks = array())
    {
        $__internal_31014168cb0636a797576f4a198d6fdebc3f73d9d15e950ed35151a1cd8a9058 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_31014168cb0636a797576f4a198d6fdebc3f73d9d15e950ed35151a1cd8a9058->enter($__internal_31014168cb0636a797576f4a198d6fdebc3f73d9d15e950ed35151a1cd8a9058_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_html"));

        
        $__internal_31014168cb0636a797576f4a198d6fdebc3f73d9d15e950ed35151a1cd8a9058->leave($__internal_31014168cb0636a797576f4a198d6fdebc3f73d9d15e950ed35151a1cd8a9058_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:email.txt.twig";
    }

    public function getDebugInfo()
    {
        return array (  66 => 11,  57 => 8,  51 => 6,  42 => 3,  36 => 1,  29 => 11,  27 => 6,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block subject %}
{% autoescape false %}
{{ 'resetting.email.subject'|trans({'%username%': user.username, '%confirmationUrl%': confirmationUrl}, 'FOSUserBundle') }}
{% endautoescape %}
{% endblock %}
{% block body_text %}
{% autoescape false %}
{{ 'resetting.email.message'|trans({'%username%': user.username, '%confirmationUrl%': confirmationUrl}, 'FOSUserBundle') }}
{% endautoescape %}
{% endblock %}
{% block body_html %}{% endblock %}
", "FOSUserBundle:Resetting:email.txt.twig", "/home/ch/proyectos/php/obrasSociales/vendor/friendsofsymfony/user-bundle/FOS/UserBundle/Resources/views/Resetting/email.txt.twig");
    }
}

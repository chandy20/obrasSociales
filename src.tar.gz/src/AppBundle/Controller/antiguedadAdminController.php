<?php

namespace AppBundle\Controller;

use Sonata\AdminBundle\Controller\CRUDController;

class antiguedadAdminController extends CRUDController
{
}

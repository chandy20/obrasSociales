<?php

namespace AppBundle\Controller;

use Sonata\AdminBundle\Controller\CRUDController;

class PoblacionbeneficiaAdminController extends CRUDController
{
}
